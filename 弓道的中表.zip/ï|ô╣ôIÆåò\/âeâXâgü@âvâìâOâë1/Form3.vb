﻿Public Class Form3
    Dim Gokei(9), Shokei(45), Atari(180), Hyo(180), Tshokei(15), Hant, DGokei(3), r, d, k, g, h, hoz As Integer
    Dim TMcontrol(3) As Label
    Dim KNcontrol(3) As Label
    Dim Core(15) As Label
    Dim stFilePath As String = System.IO.Path.GetFullPath(".")

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim i As Integer

        For i = 1 To 15
            Core(i) = Controls("label" & i + 17)
        Next
    End Sub



    Private Sub Save_Click(sender As Object, e As EventArgs) Handles Save.Click
        Dim i As Integer
        hoz = hoz + 1
        Dim sw As New System.IO.StreamWriter(stFilePath & "\Data\3Dan\" &
                                             DateTimePicker1.Text & "データ" & hoz & ".txt")


        sw.WriteLine(TextBox1.Text.ToString())
        sw.WriteLine(TextBox2.Text.ToString())
        sw.WriteLine(TextBox3.Text.ToString())
        sw.WriteLine(TextBox4.Text.ToString())
        sw.WriteLine(TextBox5.Text.ToString())
        sw.WriteLine(TextBox6.Text.ToString())
        sw.WriteLine(TextBox7.Text.ToString())
        sw.WriteLine(TextBox8.Text.ToString())
        sw.WriteLine(TextBox9.Text.ToString())


        For i = 1 To 180
            sw.Write(Atari(i).ToString())
        Next i

        sw.Write(sw.NewLine)

        For i = 1 To 180
            sw.Write(Hyo(i).ToString())
        Next i

        sw.Write(sw.NewLine)

        For i = 1 To 45
            sw.Write(Shokei(i).ToString())
        Next i

        sw.Write(sw.NewLine)

        sw.WriteLine(No1_1.Text.ToString())
        sw.WriteLine(No1_2.Text.ToString())
        sw.WriteLine(No1_3.Text.ToString())
        sw.WriteLine(No1_4.Text.ToString())
        sw.WriteLine(No1_5.Text.ToString())
        sw.WriteLine(No2_1.Text.ToString())
        sw.WriteLine(No2_2.Text.ToString())
        sw.WriteLine(No2_3.Text.ToString())
        sw.WriteLine(No2_4.Text.ToString())
        sw.WriteLine(No2_5.Text.ToString())
        sw.WriteLine(No3_1.Text.ToString())
        sw.WriteLine(No3_2.Text.ToString())
        sw.WriteLine(No3_3.Text.ToString())
        sw.WriteLine(No3_4.Text.ToString())
        sw.WriteLine(No3_5.Text.ToString())

        sw.Close()


        MsgBox("保存しました")

    End Sub

    Private Sub DataHiraku_Click(sender As Object, e As EventArgs) Handles DataHiraku.Click


        'OpenFileDialogクラスのインスタンスを作成
        Dim ofd As New OpenFileDialog()

        'はじめのファイル名を指定する
        'はじめに「ファイル名」で表示される文字列を指定する
        ofd.FileName = "Default.txt"

        'はじめに表示されるフォルダを指定する
        '指定しない（空の文字列）の時は、現在のディレクトリが表示される
        ofd.InitialDirectory = (stFilePath & "\Data\3Dan")


        'ダイアログボックスを閉じる前に現在のディレクトリを復元するようにする


        'ダイアログを表示する
        If ofd.ShowDialog() = DialogResult.OK Then
            'OKボタンがクリックされたとき、選択されたファイル名を表示する
            Console.WriteLine(ofd.FileName)
        Else
            Exit Sub
        End If

        Dim sr As New System.IO.StreamReader(ofd.FileName)

        '選手名前読み込み
        TextBox1.Text = sr.ReadLine()
        TextBox2.Text = sr.ReadLine()
        TextBox3.Text = sr.ReadLine()
        TextBox4.Text = sr.ReadLine()
        TextBox5.Text = sr.ReadLine()
        TextBox6.Text = sr.ReadLine()
        TextBox7.Text = sr.ReadLine()
        TextBox8.Text = sr.ReadLine()
        TextBox9.Text = sr.ReadLine()


        For i = 1 To 180
            Atari(i) = Val(Convert.ToChar(sr.Read()))
        Next i

        sr.ReadLine()

        For i = 1 To 180
            Hyo(i) = Val(Convert.ToChar(sr.Read()))
        Next i

        sr.ReadLine()

        For i = 1 To 45
            Shokei(i) = Val(Convert.ToChar(sr.Read()))
        Next

        sr.ReadLine()

        No1_1.Text = sr.ReadLine()
        No1_2.Text = sr.ReadLine()
        No1_3.Text = sr.ReadLine()
        No1_4.Text = sr.ReadLine()
        No1_5.Text = sr.ReadLine()
        No2_1.Text = sr.ReadLine()
        No2_2.Text = sr.ReadLine()
        No2_3.Text = sr.ReadLine()
        No2_4.Text = sr.ReadLine()
        No2_5.Text = sr.ReadLine()
        No3_1.Text = sr.ReadLine()
        No3_2.Text = sr.ReadLine()
        No3_3.Text = sr.ReadLine()
        No3_4.Text = sr.ReadLine()
        No3_5.Text = sr.ReadLine()

        sr.Close()



        Call Keisan()
        Call AtariHyoji()
        Call Ghyoji()
        Call DGHyoji()



    End Sub



    Sub Keisan()
        Dim i, kk As Integer

        For i = 0 To 8
            Gokei(1 + i) = Shokei(1 + 5 * i) + Shokei(2 + 5 * i) + Shokei(3 + 5 * i) + Shokei(4 + 5 * i) + Shokei(5 * (i + 1))
        Next i


        For kk = 1 To 5
            Tshokei(kk) = Shokei(kk) + Shokei(kk + 5) + Shokei(kk + 10)
        Next

        For kk = 1 To 5
            Tshokei(kk + 5) = Shokei(kk + 15) + Shokei(kk + 20) + Shokei(kk + 25)
        Next

        For kk = 1 To 5
            Tshokei(kk + 10) = Shokei(kk + 30) + Shokei(kk + 35) + Shokei(kk + 40)
        Next

        DGokei(1) = Tshokei(1) + Tshokei(2) + Tshokei(3) + Tshokei(4) + Tshokei(5)
        DGokei(2) = Tshokei(6) + Tshokei(7) + Tshokei(8) + Tshokei(9) + Tshokei(10)
        DGokei(3) = Tshokei(11) + Tshokei(12) + Tshokei(13) + Tshokei(14) + Tshokei(15)




    End Sub

    Sub AtariHyoji()
        Dim m As Integer
        Dim Btncontrol As Button


        For m = 1 To 180
            Btncontrol = Controls("Button" & m)

            '入れ替えた表の表示？
            If Hyo(m) = 0 Then
                Btncontrol.Text = ""
            ElseIf Hyo(m) = 1 Then
                Btncontrol.Text = "〇"
            ElseIf Hyo(m) = 2 Then
                Btncontrol.Text = "×"
            End If
        Next m
    End Sub

    Sub Ghyoji()
        Label1.Text = Gokei(1)
        Label2.Text = Gokei(2)
        Label3.Text = Gokei(3)
        Label4.Text = Gokei(4)
        Label5.Text = Gokei(5)
        Label6.Text = Gokei(6)
        Label7.Text = Gokei(7)
        Label8.Text = Gokei(8)
        Label9.Text = Gokei(9)

    End Sub

    Sub DGHyoji()
        DGokei1.Text = ("計" & " " &
                DGokei(1) & " " & "中")
        DGokei2.Text = ("計" & " " &
                DGokei(2) & " " & "中")
        DGokei3.Text = ("計" & " " &
                DGokei(3) & " " & "中")
    End Sub

    Sub Keinohyoji()
        Dim k As Integer
        Dim g As Integer
        Dim h As Integer

        For k = 1 To 5
            KNcontrol(1) = Controls("KeiNo1_" & k)
            KNcontrol(1).Text = ("計" & " " &
                Shokei(k) + Shokei(k + 5) + Shokei(k + 10) & " " & "中")
        Next k

        For g = 1 To 5
            KNcontrol(2) = Controls("KeiNo2_" & g)
            KNcontrol(2).Text = ("計" & " " &
                Shokei(g + 15) + Shokei(g + 20) + Shokei(g + 25) & " " & "中")
        Next g

        For h = 1 To 5
            KNcontrol(3) = Controls("KeiNo3_" & h)
            KNcontrol(3).Text = ("計" & " " &
                Shokei(h + 30) + Shokei(h + 35) + Shokei(h + 40) & " " & "中")
        Next h

    End Sub


    Private Sub syuryoClick(sender As Object, e As EventArgs) Handles Syuryo.Click
        Me.Close()
    End Sub
    Private Sub Back_Click(sender As Object, e As EventArgs) Handles Back.Click
        Form1.Show()
        Me.Close()
    End Sub
    Private Sub Atri_reset_Click(sender As Object, e As EventArgs) Handles Atri_Clear.Click
        Dim a, b, c As Integer

        For a = 1 To 180
            Hyo(a) = 0
            Atari(a) = 0
        Next

        For b = 1 To 9
            Gokei(b) = 0
        Next
        For c = 1 To 45
            Shokei(c) = 0
        Next
        For c = 1 To 15
            Tshokei(c) = 0
        Next
        For c = 1 To 3
            DGokei(c) = 0
        Next


        Call AtariHyoji()
        Call DGHyoji()
        Call Ghyoji()
        Call Keinohyoji()



        Hant = 0
        r = 0
        d = 0
        k = 0
        g = 0
        h = 0
        For d = 1 To 5
            TMcontrol(1) = Controls("No1_" & d)
            TMcontrol(1).Text = "00:00"

            KNcontrol(1) = Controls("KeiNo1_" & d)
            KNcontrol(1).Text = ("計" & " " & 0 & " " & "中")


            TMcontrol(2) = Controls("No2_" & d)
            TMcontrol(2).Text = "00:00"

            KNcontrol(2) = Controls("KeiNo2_" & d)
            KNcontrol(2).Text = ("計" & " " & 0 & " " & "中")

            TMcontrol(3) = Controls("No3_" & d)
            TMcontrol(3).Text = "00:00"

            KNcontrol(3) = Controls("KeiNo3_" & d)
            KNcontrol(3).Text = ("計" & " " & 0 & " " & "中")
        Next d

        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        TextBox7.Text = ""
        TextBox8.Text = ""
        TextBox9.Text = ""

        Button201.Enabled = False
        Button202.Enabled = False
        Button203.Enabled = False

        For a = 1 To 15
            Core(a).Text = ""
        Next
        Core(1).Text = "●"
        Core(6).Text = "●"
        Core(11).Text = "●"

        Button181.Enabled = True
        Button182.Enabled = True
        Button183.Enabled = True
    End Sub
    Private Sub TClear_Click(sender As Object, e As EventArgs) Handles TClear.Click
        Dim a, b, c As Integer

        For a = 1 To 180
            Hyo(a) = 0
            Atari(a) = 0
        Next

        For b = 1 To 9
            Gokei(b) = 0
        Next
        For c = 1 To 45
            Shokei(c) = 0
        Next
        For c = 1 To 15
            Tshokei(c) = 0
        Next
        For c = 1 To 3
            DGokei(c) = 0
        Next


        Call AtariHyoji()
        Call DGHyoji()
        Call Ghyoji()
        Call Keinohyoji()



        Hant = 0
        r = 0
        d = 0
        k = 0
        g = 0
        h = 0
        For d = 1 To 5
            TMcontrol(1) = Controls("No1_" & d)
            TMcontrol(1).Text = "00:00"

            KNcontrol(1) = Controls("KeiNo1_" & d)
            KNcontrol(1).Text = ("計" & " " & 0 & " " & "中")


            TMcontrol(2) = Controls("No2_" & d)
            TMcontrol(2).Text = "00:00"

            KNcontrol(2) = Controls("KeiNo2_" & d)
            KNcontrol(2).Text = ("計" & " " & 0 & " " & "中")

            TMcontrol(3) = Controls("No3_" & d)
            TMcontrol(3).Text = "00:00"

            KNcontrol(3) = Controls("KeiNo3_" & d)
            KNcontrol(3).Text = ("計" & " " & 0 & " " & "中")
        Next d

        Button201.Enabled = False
        Button202.Enabled = False
        Button203.Enabled = False


        For a = 1 To 15
            Core(a).Text = ""
        Next
        Core(1).Text = "●"
        Core(6).Text = "●"
        Core(11).Text = "●"

        Button181.Enabled = True
        Button182.Enabled = True
        Button183.Enabled = True


    End Sub

    Private Sub Gokei_All_Click(sender As Object, e As EventArgs) Handles Gokei_All.Click
        Dim i As Integer
        Hant = 0

        For i = 0 To 8
            Gokei(1 + i) = Shokei(1 + 5 * i) + Shokei(2 + 5 * i) + Shokei(3 + 5 * i) + Shokei(4 + 5 * i) + Shokei(5 * (i + 1))
            Label1.Text = Gokei(1)
            Label2.Text = Gokei(2)
            Label3.Text = Gokei(3)
            Label4.Text = Gokei(4)
            Label5.Text = Gokei(5)
            Label6.Text = Gokei(6)
            Label7.Text = Gokei(7)
            Label8.Text = Gokei(8)
            Label9.Text = Gokei(9)
        Next i

        DGokei(1) = Tshokei(1) + Tshokei(2) + Tshokei(3) + Tshokei(4) + Tshokei(5)
        DGokei(2) = Tshokei(6) + Tshokei(7) + Tshokei(8) + Tshokei(9) + Tshokei(10)
        DGokei(3) = Tshokei(11) + Tshokei(12) + Tshokei(13) + Tshokei(14) + Tshokei(15)


        DGokei1.Text = ("計" & " " &
                DGokei(1) & " " & "中")
        DGokei2.Text = ("計" & " " &
                DGokei(2) & " " & "中")
        DGokei3.Text = ("計" & " " &
            DGokei(3) & " " & "中")
    End Sub
    Private Sub Gokei_2_Click(sender As Object, e As EventArgs) Handles Gokei_2.Click
        Dim i As Integer
        Hant = 1

        For i = 0 To 8
            Gokei(1 + i) = Shokei(1 + 5 * i) + Shokei(2 + 5 * i) + Shokei(3 + 5 * i) + Shokei(4 + 5 * i) + Shokei(5 * (i + 1))

            Gokei(1 + i) = Gokei(1 + i) - (Shokei(3 + 5 * i) + Shokei(4 + 5 * i) + Shokei(5 * (i + 1)))
            Label1.Text = Gokei(1)
            Label2.Text = Gokei(2)
            Label3.Text = Gokei(3)
            Label4.Text = Gokei(4)
            Label5.Text = Gokei(5)
            Label6.Text = Gokei(6)
            Label7.Text = Gokei(7)
            Label8.Text = Gokei(8)
            Label9.Text = Gokei(9)
        Next i

        DGokei(1) = Tshokei(1) + Tshokei(2)
        DGokei(2) = Tshokei(6) + Tshokei(7)
        DGokei(3) = Tshokei(11) + Tshokei(12)


        DGokei1.Text = ("計" & " " &
            DGokei(1) & " " & "中")
        DGokei2.Text = ("計" & " " &
            DGokei(2) & " " & "中")
        DGokei3.Text = ("計" & " " &
            DGokei(3) & " " & "中")


    End Sub
    Private Sub Goke_3_Click(sender As Object, e As EventArgs) Handles Goke_3.Click
        Dim i As Integer
        Hant = 2

        For i = 0 To 8
            Gokei(1 + i) = Shokei(1 + 5 * i) + Shokei(2 + 5 * i) + Shokei(3 + 5 * i) + Shokei(4 + 5 * i) + Shokei(5 * (i + 1))

            Gokei(1 + i) = Gokei(1 + i) - (Shokei(4 + 5 * i) + Shokei(5 * (i + 1)))
            Label1.Text = Gokei(1)
            Label2.Text = Gokei(2)
            Label3.Text = Gokei(3)
            Label4.Text = Gokei(4)
            Label5.Text = Gokei(5)
            Label6.Text = Gokei(6)
            Label7.Text = Gokei(7)
            Label8.Text = Gokei(8)
            Label9.Text = Gokei(9)
        Next i

        DGokei(1) = Tshokei(1) + Tshokei(2) + Tshokei(3)
        DGokei(2) = Tshokei(6) + Tshokei(7) + Tshokei(8)
        DGokei(3) = Tshokei(11) + Tshokei(12) + Tshokei(13)


        DGokei1.Text = ("計" & " " &
            DGokei(1) & " " & "中")
        DGokei2.Text = ("計" & " " &
            DGokei(2) & " " & "中")
        DGokei3.Text = ("計" & " " &
            DGokei(3) & " " & "中")

    End Sub



    Private datstart As Date
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Dim ts As TimeSpan

        ts = DateTime.op_Subtraction(Now, datstart)
        timer.Text = Format(ts.Minutes, "00") & ":" &
        Format(ts.Seconds, "00")

        If timer.Text = "6:30" Then
            MsgBox("30秒前です")
        End If

    End Sub
    Private Sub Start_Click(sender As Object, e As EventArgs) Handles Start.Click
        d = d + 1

        StopNo1.Enabled = True
        StopNo2.Enabled = True
        StopNo3.Enabled = True
        Timer1.Enabled = True
        datstart = Now
        Me.Start.Enabled = False
        Me.reset.Enabled = False

        If k = 5 Then
            StopNo1.Enabled = False
        End If

        If g = 5 Then
            StopNo2.Enabled = False
        End If

        If h = 5 Then
            StopNo3.Enabled = False
        End If

        If k > 0 Then
            Me.Button201.Enabled = True
        End If

        If g > 0 Then
            Me.Button202.Enabled = True
        End If

        If h > 0 Then
            Me.Button203.Enabled = True
        End If
    End Sub
    Private Sub Reset_Click(sender As Object, e As EventArgs) Handles reset.Click
        StopNo1.Enabled = False
        StopNo2.Enabled = False
        StopNo3.Enabled = False
        Timer1.Enabled = False
        timer.Text = "00:00"
        Me.Start.Enabled = True
        r = 0
        If k = 5 And g = 5 And h = 5 Then
            Start.Enabled = False
        End If
    End Sub

    Private Sub StopNo1_Click(sender As Object, e As EventArgs) Handles StopNo1.Click


        r = r + 1
        k = k + 1
        Me.reset.Enabled = True
        If r = 3 Then
            Timer1.Enabled = False
        End If

        '大合計計算

        Tshokei(k) = Shokei(k) + Shokei(k + 5) + Shokei(k + 10)

        'タイマー表示
        TMcontrol(1) = Controls("No1_" & k)
        TMcontrol(1).Text = timer.Text

        '合計表示
        KNcontrol(1) = Controls("KeiNo1_" & k)
        KNcontrol(1).Text = ("計" & " " & Tshokei(k) & " " & "中")



        If Hant = 0 Then

            DGokei(1) = Tshokei(1) + Tshokei(2) + Tshokei(3) + Tshokei(4) + Tshokei(5)
            DGokei1.Text = ("計" & " " &
                DGokei(1) & " " & "中")

        ElseIf Hant = 1 Then

            DGokei(1) = Tshokei(1) + Tshokei(2)
            DGokei1.Text = ("計" & " " &
                DGokei(1) & " " & "中")

        ElseIf Hant = 2 Then

            DGokei(1) = Tshokei(1) + Tshokei(2) + Tshokei(3)
            DGokei1.Text = ("計" & " " &
                DGokei(1) & " " & "中")

        End If

        StopNo1.Enabled = False

        If k = 4 Then
            Me.Button181.Enabled = False
        End If

        If k < 4 Then
            Button181.Enabled = True
        End If

        If k < 5 Then
            Core(k + 1).Text = "●"
            Core(k).Text = ""
        End If

    End Sub
    Private Sub StopNo2_Click(sender As Object, e As EventArgs) Handles StopNo2.Click

        r = r + 1
        g = g + 1

        Me.reset.Enabled = True
        If r = 3 Then
            Timer1.Enabled = False
        End If

        '団体ごとの的中計算


        Tshokei(k + 5) = Shokei(k + 15) + Shokei(k + 20) + Shokei(k + 25)



        TMcontrol(2) = Controls("No2_" & g)
        TMcontrol(2).Text = timer.Text


        KNcontrol(2) = Controls("KeiNo2_" & g)
        KNcontrol(2).Text = ("計" & " " &
             Shokei(g + 15) + Shokei(g + 20) + Shokei(g + 25) & " " & "中")

        If Hant = 0 Then
            DGokei(2) = Tshokei(6) + Tshokei(7) + Tshokei(8) + Tshokei(9) + Tshokei(10)
            DGokei2.Text = ("計" & " " &
                DGokei(2) & " " & "中")

        ElseIf Hant = 1 Then
            DGokei(2) = Tshokei(6) + Tshokei(7)
            DGokei2.Text = ("計" & " " &
                DGokei(2) & " " & "中")

        ElseIf Hant = 2 Then
            DGokei(2) = Tshokei(6) + Tshokei(7) + Tshokei(8)
            DGokei2.Text = ("計" & " " &
                DGokei(2) & " " & "中")

        End If

        StopNo2.Enabled = False


        If g = 4 Then
            Me.Button182.Enabled = False
        End If


        If g < 4 Then
            Button182.Enabled = True
        End If

        If g < 5 Then
            Core(g + 6).Text = "●"
            Core(g + 5).Text = ""
        End If

    End Sub
    Private Sub StopNo3_Click(sender As Object, e As EventArgs) Handles StopNo3.Click

        r = r + 1
        h = h + 1

        Me.reset.Enabled = True
        If r = 3 Then
            Timer1.Enabled = False
        End If


        '団体ごとの的中計算

        Tshokei(k + 10) = Shokei(k + 30) + Shokei(k + 35) + Shokei(k + 40)



        TMcontrol(3) = Controls("No3_" & h)
        TMcontrol(3).Text = timer.Text


        KNcontrol(3) = Controls("KeiNo3_" & h)
        KNcontrol(3).Text = ("計" & " " &
             Shokei(h + 30) + Shokei(h + 35) + Shokei(h + 40) & " " & "中")

        If Hant = 0 Then
            DGokei(3) = Tshokei(11) + Tshokei(12) + Tshokei(13) + Tshokei(14) + Tshokei(15)
            DGokei3.Text = ("計" & " " &
                DGokei(3) & " " & "中")


        ElseIf Hant = 1 Then
            DGokei(3) = Tshokei(11) + Tshokei(12)
            DGokei3.Text = ("計" & " " &
                DGokei(3) & " " & "中")

        ElseIf Hant = 2 Then
            DGokei(3) = Tshokei(11) + Tshokei(12) + Tshokei(13)
            DGokei3.Text = ("計" & " " &
                DGokei(3) & " " & "中")

        End If

        StopNo3.Enabled = False

        If h = 4 Then
            Me.Button183.Enabled = False
        End If


        If h < 4 Then
            Button183.Enabled = True
        End If

        If h < 5 Then
            Core(h + 11).Text = "●"
            Core(h + 10).Text = ""
        End If
    End Sub








    Private Sub Button201_Click(sender As Object, e As EventArgs) Handles Button201.Click
        If k = 5 Then
            k = k - 2
        Else
            k = k - 1
        End If


        If k = 0 Then
            Me.Button201.Enabled = False
        End If

        If k < 4 Then
            Button181.Enabled = True
        End If


        If Start.Enabled = False Then
            StopNo1.Enabled = True
        End If

        Core(k + 2).Text = ""
        Core(k + 1).Text = "●"
    End Sub

    Private Sub Button202_Click(sender As Object, e As EventArgs) Handles Button202.Click
        If g = 5 Then
            g = g - 2
        Else
            g = g - 1
        End If

        If g = 0 Then
            Me.Button202.Enabled = False
        End If

        If g < 4 Then
            Button182.Enabled = True
        End If

        If Start.Enabled = False Then
            StopNo2.Enabled = True
        End If


        Core(g + 7).Text = ""
        Core(g + 6).Text = "●"
    End Sub

    Private Sub Button203_Click(sender As Object, e As EventArgs) Handles Button203.Click
        If h = 5 Then
            h = h - 2
        Else
            h = h - 1
        End If

        If h = 0 Then
            Me.Button203.Enabled = False
        End If

        If h < 4 Then
            Button183.Enabled = True
        End If

        If Start.Enabled = False Then
            StopNo3.Enabled = True
        End If


        Core(h + 12).Text = ""
        Core(h + 11).Text = "●"
    End Sub

    Private Sub Button181_Click(sender As Object, e As EventArgs) Handles Button181.Click
        If k = 5 Then
            Button181.Enabled = False
            Exit Sub
        End If

        k = k + 1


        If k = 4 And Start.Enabled = True Then
            Me.Button181.Enabled = False
            StopNo1.Enabled = False
        End If

        If k = 4 Then
            Button181.Enabled = False
        End If



        Button201.Enabled = True

        Core(k + 1).Text = "●"
        Core(k).Text = ""

    End Sub

    Private Sub Button182_Click(sender As Object, e As EventArgs) Handles Button182.Click
        g = g + 1

        If g = 4 And Start.Enabled = True Then
            Me.Button182.Enabled = False
            StopNo2.Enabled = False
        End If

        If g = 4 Then
            Button182.Enabled = False
        End If

        Button202.Enabled = True


        Core(g + 6).Text = "●"
        Core(g + 5).Text = ""
    End Sub

    Private Sub Button183_Click(sender As Object, e As EventArgs) Handles Button183.Click
        h = h + 1

        If h = 4 And Start.Enabled = True Then
            Me.Button183.Enabled = False
            StopNo3.Enabled = False
        End If

        If h = 4 Then
            Button183.Enabled = False
        End If

        Button203.Enabled = True


        Core(h + 11).Text = "●"
        Core(h + 10).Text = ""
    End Sub







    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Hyo(1) = Hyo(1) + 1

        If Hyo(1) = 1 Then
            Button1.Text = "〇"
            Atari(1) = Atari(1) + 1

        ElseIf Hyo(1) = 2 Then
            Button1.Text = "×"
            Atari(1) = Atari(1) - 1

        ElseIf Hyo(1) = 3 Then
            Button1.Text = ""
            Hyo(1) = 0
        End If

        Shokei(1) = Atari(1) + Atari(2) + Atari(3) + Atari(4)

        Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        If Hant = 0 Then
            Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        ElseIf Hant = 1 Then
            Gokei(1) = Gokei(1) - (Shokei(3) + Shokei(4) + Shokei(5))

        ElseIf Hant = 2 Then
            Gokei(1) = Gokei(1) - (Shokei(4) + Shokei(5))
        End If




        Label1.Text = Gokei(1)
    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        Hyo(2) = Hyo(2) + 1

        If Hyo(2) = 1 Then
            Button2.Text = "〇"
            Atari(2) = Atari(2) + 1

        ElseIf Hyo(2) = 2 Then
            Button2.Text = "×"
            Atari(2) = Atari(2) - 1

        ElseIf Hyo(2) = 3 Then
            Button2.Text = ""
            Hyo(2) = 0

        End If

        Shokei(1) = Atari(1) + Atari(2) + Atari(3) + Atari(4)

        Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        If Hant = 0 Then
            Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        ElseIf Hant = 1 Then
            Gokei(1) = Gokei(1) - (Shokei(3) + Shokei(4) + Shokei(5))

        ElseIf Hant = 2 Then
            Gokei(1) = Gokei(1) - (Shokei(4) + Shokei(5))
        End If

        Label1.Text = Gokei(1)

    End Sub
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Hyo(3) = Hyo(3) + 1

        If Hyo(3) = 1 Then
            Button3.Text = "〇"
            Atari(3) = Atari(3) + 1

        ElseIf Hyo(3) = 2 Then
            Button3.Text = "×"
            Atari(3) = Atari(3) - 1

        ElseIf Hyo(3) = 3 Then
            Button3.Text = ""
            Hyo(3) = 0

        End If

        Shokei(1) = Atari(1) + Atari(2) + Atari(3) + Atari(4)

        Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        If Hant = 0 Then
            Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        ElseIf Hant = 1 Then
            Gokei(1) = Gokei(1) - (Shokei(3) + Shokei(4) + Shokei(5))

        ElseIf Hant = 2 Then
            Gokei(1) = Gokei(1) - (Shokei(4) + Shokei(5))
        End If


        Label1.Text = Gokei(1)
    End Sub
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click

        Hyo(4) = Hyo(4) + 1

        If Hyo(4) = 1 Then
            Button4.Text = "〇"
            Atari(4) = Atari(4) + 1

        ElseIf Hyo(4) = 2 Then
            Button4.Text = "×"
            Atari(4) = Atari(4) - 1

        ElseIf Hyo(4) = 3 Then
            Button4.Text = ""
            Hyo(4) = 0

        End If

        Shokei(1) = Atari(1) + Atari(2) + Atari(3) + Atari(4)

        Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        If Hant = 0 Then
            Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        ElseIf Hant = 1 Then
            Gokei(1) = Gokei(1) - (Shokei(3) + Shokei(4) + Shokei(5))

        ElseIf Hant = 2 Then
            Gokei(1) = Gokei(1) - (Shokei(4) + Shokei(5))
        End If


        Label1.Text = Gokei(1)

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click

        Hyo(5) = Hyo(5) + 1

        If Hyo(5) = 1 Then
            Button5.Text = "〇"
            Atari(5) = Atari(5) + 1

        ElseIf Hyo(5) = 2 Then
            Button5.Text = "×"
            Atari(5) = Atari(5) - 1

        ElseIf Hyo(5) = 3 Then
            Button5.Text = ""
            Hyo(5) = 0

        End If

        Shokei(2) = Atari(5) + Atari(6) + Atari(7) + Atari(8)

        Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        If Hant = 0 Then
            Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        ElseIf Hant = 1 Then
            Gokei(1) = Gokei(1) - (Shokei(3) + Shokei(4) + Shokei(5))

        ElseIf Hant = 2 Then
            Gokei(1) = Gokei(1) - (Shokei(4) + Shokei(5))
        End If

        Label1.Text = Gokei(1)
    End Sub
    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click

        Hyo(6) = Hyo(6) + 1

        If Hyo(6) = 1 Then
            Button6.Text = "〇"
            Atari(6) = Atari(6) + 1

        ElseIf Hyo(6) = 2 Then
            Button6.Text = "×"
            Atari(6) = Atari(6) - 1

        ElseIf Hyo(6) = 3 Then
            Button6.Text = ""
            Hyo(6) = 0

        End If

        Shokei(2) = Atari(5) + Atari(6) + Atari(7) + Atari(8)

        Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        If Hant = 0 Then
            Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        ElseIf Hant = 1 Then
            Gokei(1) = Gokei(1) - (Shokei(3) + Shokei(4) + Shokei(5))

        ElseIf Hant = 2 Then
            Gokei(1) = Gokei(1) - (Shokei(4) + Shokei(5))
        End If

        Label1.Text = Gokei(1)
    End Sub
    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click

        Hyo(7) = Hyo(7) + 1

        If Hyo(7) = 1 Then
            Button7.Text = "〇"
            Atari(7) = Atari(7) + 1

        ElseIf Hyo(7) = 2 Then
            Button7.Text = "×"
            Atari(7) = Atari(7) - 1

        ElseIf Hyo(7) = 3 Then
            Button7.Text = ""
            Hyo(7) = 0

        End If

        Shokei(2) = Atari(5) + Atari(6) + Atari(7) + Atari(8)

        Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        If Hant = 0 Then
            Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        ElseIf Hant = 1 Then
            Gokei(1) = Gokei(1) - (Shokei(3) + Shokei(4) + Shokei(5))

        ElseIf Hant = 2 Then
            Gokei(1) = Gokei(1) - (Shokei(4) + Shokei(5))
        End If

        Label1.Text = Gokei(1)
    End Sub
    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click

        Hyo(8) = Hyo(8) + 1

        If Hyo(8) = 1 Then
            Button8.Text = "〇"
            Atari(8) = Atari(8) + 1

        ElseIf Hyo(8) = 2 Then
            Button8.Text = "×"
            Atari(8) = Atari(8) - 1

        ElseIf Hyo(8) = 3 Then
            Button8.Text = ""
            Hyo(8) = 0

        End If

        Shokei(2) = Atari(5) + Atari(6) + Atari(7) + Atari(8)

        Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        If Hant = 0 Then
            Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        ElseIf Hant = 1 Then
            Gokei(1) = Gokei(1) - (Shokei(3) + Shokei(4) + Shokei(5))

        ElseIf Hant = 2 Then
            Gokei(1) = Gokei(1) - (Shokei(4) + Shokei(5))
        End If

        Label1.Text = Gokei(1)
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click

        Hyo(9) = Hyo(9) + 1


        If Hyo(9) = 1 Then
            Button9.Text = "〇"
            Atari(9) = Atari(9) + 1

        ElseIf Hyo(9) = 2 Then
            Button9.Text = "×"
            Atari(9) = Atari(9) - 1

        ElseIf Hyo(9) = 3 Then
            Button9.Text = ""
            Hyo(9) = 0

        End If

        Shokei(3) = Atari(9) + Atari(10) + Atari(11) + Atari(12)

        Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        If Hant = 0 Then
            Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        ElseIf Hant = 1 Then
            Gokei(1) = Gokei(1) - (Shokei(3) + Shokei(4) + Shokei(5))

        ElseIf Hant = 2 Then
            Gokei(1) = Gokei(1) - (Shokei(4) + Shokei(5))
        End If

        Label1.Text = Gokei(1)
    End Sub
    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        Hyo(10) = Hyo(10) + 1

        If Hyo(10) = 1 Then
            Button10.Text = "〇"
            Atari(10) = Atari(10) + 1

        ElseIf Hyo(10) = 2 Then
            Button10.Text = "×"
            Atari(10) = Atari(10) - 1

        ElseIf Hyo(10) = 3 Then
            Button10.Text = ""
            Hyo(10) = 0

        End If

        Shokei(3) = Atari(9) + Atari(10) + Atari(11) + Atari(12)

        Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        If Hant = 0 Then
            Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        ElseIf Hant = 1 Then
            Gokei(1) = Gokei(1) - (Shokei(3) + Shokei(4) + Shokei(5))

        ElseIf Hant = 2 Then
            Gokei(1) = Gokei(1) - (Shokei(4) + Shokei(5))
        End If

        Label1.Text = Gokei(1)
    End Sub
    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        Hyo(11) = Hyo(11) + 1

        If Hyo(11) = 1 Then
            Button11.Text = "〇"
            Atari(11) = Atari(11) + 1

        ElseIf Hyo(11) = 2 Then
            Button11.Text = "×"
            Atari(11) = Atari(11) - 1

        ElseIf Hyo(11) = 3 Then
            Button11.Text = ""
            Hyo(11) = 0

        End If

        Shokei(3) = Atari(9) + Atari(10) + Atari(11) + Atari(12)

        Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        If Hant = 0 Then
            Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        ElseIf Hant = 1 Then
            Gokei(1) = Gokei(1) - (Shokei(3) + Shokei(4) + Shokei(5))

        ElseIf Hant = 2 Then
            Gokei(1) = Gokei(1) - (Shokei(4) + Shokei(5))
        End If

        Label1.Text = Gokei(1)
    End Sub
    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click
        Hyo(12) = Hyo(12) + 1

        If Hyo(12) = 1 Then
            Button12.Text = "〇"
            Atari(12) = Atari(12) + 1

        ElseIf Hyo(12) = 2 Then
            Button12.Text = "×"
            Atari(12) = Atari(12) - 1

        ElseIf Hyo(12) = 3 Then
            Button12.Text = ""
            Hyo(12) = 0

        End If

        Shokei(3) = Atari(9) + Atari(10) + Atari(11) + Atari(12)

        Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        If Hant = 0 Then
            Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        ElseIf Hant = 1 Then
            Gokei(1) = Gokei(1) - (Shokei(3) + Shokei(4) + Shokei(5))

        ElseIf Hant = 2 Then
            Gokei(1) = Gokei(1) - (Shokei(4) + Shokei(5))
        End If

        Label1.Text = Gokei(1)
    End Sub

    Private Sub Button13_Click(sender As Object, e As EventArgs) Handles Button13.Click
        Hyo(13) = Hyo(13) + 1

        If Hyo(13) = 1 Then
            Button13.Text = "〇"
            Atari(13) = Atari(13) + 1

        ElseIf Hyo(13) = 2 Then
            Button13.Text = "×"
            Atari(13) = Atari(13) - 1

        ElseIf Hyo(13) = 3 Then
            Button13.Text = ""
            Hyo(13) = 0

        End If

        Shokei(4) = Atari(13) + Atari(14) + Atari(15) + Atari(16)

        Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        If Hant = 0 Then
            Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        ElseIf Hant = 1 Then
            Gokei(1) = Gokei(1) - (Shokei(3) + Shokei(4) + Shokei(5))

        ElseIf Hant = 2 Then
            Gokei(1) = Gokei(1) - (Shokei(4) + Shokei(5))
        End If

        Label1.Text = Gokei(1)
    End Sub
    Private Sub Button14_Click(sender As Object, e As EventArgs) Handles Button14.Click
        Hyo(14) = Hyo(14) + 1

        If Hyo(14) = 1 Then
            Button14.Text = "〇"
            Atari(14) = Atari(14) + 1

        ElseIf Hyo(14) = 2 Then
            Button14.Text = "×"
            Atari(14) = Atari(14) - 1

        ElseIf Hyo(14) = 3 Then
            Button14.Text = ""
            Hyo(14) = 0

        End If

        Shokei(4) = Atari(13) + Atari(14) + Atari(15) + Atari(16)

        Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        If Hant = 0 Then
            Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        ElseIf Hant = 1 Then
            Gokei(1) = Gokei(1) - (Shokei(3) + Shokei(4) + Shokei(5))

        ElseIf Hant = 2 Then
            Gokei(1) = Gokei(1) - (Shokei(4) + Shokei(5))
        End If

        Label1.Text = Gokei(1)
    End Sub
    Private Sub Button15_Click(sender As Object, e As EventArgs) Handles Button15.Click
        Hyo(15) = Hyo(15) + 1

        If Hyo(15) = 1 Then
            Button15.Text = "〇"
            Atari(15) = Atari(15) + 1

        ElseIf Hyo(15) = 2 Then
            Button15.Text = "×"
            Atari(15) = Atari(15) - 1

        ElseIf Hyo(15) = 3 Then
            Button15.Text = ""
            Hyo(15) = 0

        End If

        Shokei(4) = Atari(13) + Atari(14) + Atari(15) + Atari(16)

        Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        If Hant = 0 Then
            Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        ElseIf Hant = 1 Then
            Gokei(1) = Gokei(1) - (Shokei(3) + Shokei(4) + Shokei(5))

        ElseIf Hant = 2 Then
            Gokei(1) = Gokei(1) - (Shokei(4) + Shokei(5))
        End If

        Label1.Text = Gokei(1)
    End Sub
    Private Sub Button16_Click(sender As Object, e As EventArgs) Handles Button16.Click
        Hyo(16) = Hyo(16) + 1

        If Hyo(16) = 1 Then
            Button16.Text = "〇"
            Atari(16) = Atari(16) + 1

        ElseIf Hyo(16) = 2 Then
            Button16.Text = "×"
            Atari(16) = Atari(16) - 1

        ElseIf Hyo(16) = 3 Then
            Button16.Text = ""
            Hyo(16) = 0

        End If

        Shokei(4) = Atari(13) + Atari(14) + Atari(15) + Atari(16)

        Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        If Hant = 0 Then
            Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        ElseIf Hant = 1 Then
            Gokei(1) = Gokei(1) - (Shokei(3) + Shokei(4) + Shokei(5))

        ElseIf Hant = 2 Then
            Gokei(1) = Gokei(1) - (Shokei(4) + Shokei(5))
        End If

        Label1.Text = Gokei(1)
    End Sub

    Private Sub Button17_Click(sender As Object, e As EventArgs) Handles Button17.Click
        Hyo(17) = Hyo(17) + 1

        If Hyo(17) = 1 Then
            Button17.Text = "〇"
            Atari(17) = Atari(17) + 1

        ElseIf Hyo(17) = 2 Then
            Button17.Text = "×"
            Atari(17) = Atari(17) - 1

        ElseIf Hyo(17) = 3 Then
            Button17.Text = ""
            Hyo(17) = 0

        End If

        Shokei(5) = Atari(17) + Atari(18) + Atari(19) + Atari(20)

        Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        If Hant = 0 Then
            Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        ElseIf Hant = 1 Then
            Gokei(1) = Gokei(1) - (Shokei(3) + Shokei(4) + Shokei(5))

        ElseIf Hant = 2 Then
            Gokei(1) = Gokei(1) - (Shokei(4) + Shokei(5))
        End If

        Label1.Text = Gokei(1)
    End Sub
    Private Sub Button18_Click(sender As Object, e As EventArgs) Handles Button18.Click
        Hyo(18) = Hyo(18) + 1

        If Hyo(18) = 1 Then
            Button18.Text = "〇"
            Atari(18) = Atari(18) + 1

        ElseIf Hyo(18) = 2 Then
            Button18.Text = "×"
            Atari(18) = Atari(18) - 1

        ElseIf Hyo(18) = 3 Then
            Button18.Text = ""
            Hyo(18) = 0

        End If

        Shokei(5) = Atari(17) + Atari(18) + Atari(19) + Atari(20)

        Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        If Hant = 0 Then
            Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        ElseIf Hant = 1 Then
            Gokei(1) = Gokei(1) - (Shokei(3) + Shokei(4) + Shokei(5))

        ElseIf Hant = 2 Then
            Gokei(1) = Gokei(1) - (Shokei(4) + Shokei(5))
        End If

        Label1.Text = Gokei(1)
    End Sub
    Private Sub Button19_Click(sender As Object, e As EventArgs) Handles Button19.Click
        Hyo(19) = Hyo(19) + 1

        If Hyo(19) = 1 Then
            Button19.Text = "〇"
            Atari(19) = Atari(19) + 1

        ElseIf Hyo(19) = 2 Then
            Button19.Text = "×"
            Atari(19) = Atari(19) - 1

        ElseIf Hyo(19) = 3 Then
            Button19.Text = ""
            Hyo(19) = 0

        End If

        Shokei(5) = Atari(17) + Atari(18) + Atari(19) + Atari(20)

        Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        If Hant = 0 Then
            Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        ElseIf Hant = 1 Then
            Gokei(1) = Gokei(1) - (Shokei(3) + Shokei(4) + Shokei(5))

        ElseIf Hant = 2 Then
            Gokei(1) = Gokei(1) - (Shokei(4) + Shokei(5))
        End If

        Label1.Text = Gokei(1)
    End Sub
    Private Sub Button20_Click(sender As Object, e As EventArgs) Handles Button20.Click
        Hyo(20) = Hyo(20) + 1

        If Hyo(20) = 1 Then
            Button20.Text = "〇"
            Atari(20) = Atari(20) + 1

        ElseIf Hyo(20) = 2 Then
            Button20.Text = "×"
            Atari(20) = Atari(20) - 1

        ElseIf Hyo(20) = 3 Then
            Button20.Text = ""
            Hyo(20) = 0

        End If

        Shokei(5) = Atari(17) + Atari(18) + Atari(19) + Atari(20)

        Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        If Hant = 0 Then
            Gokei(1) = Shokei(1) + Shokei(2) + Shokei(3) + Shokei(4) + Shokei(5)

        ElseIf Hant = 1 Then
            Gokei(1) = Gokei(1) - (Shokei(3) + Shokei(4) + Shokei(5))

        ElseIf Hant = 2 Then
            Gokei(1) = Gokei(1) - (Shokei(4) + Shokei(5))
        End If

        Label1.Text = Gokei(1)

    End Sub



    Private Sub Button21_Click(sender As Object, e As EventArgs) Handles Button21.Click
        Hyo(21) = Hyo(21) + 1

        If Hyo(21) = 1 Then
            Button21.Text = "〇"
            Atari(21) = Atari(21) + 1

        ElseIf Hyo(21) = 2 Then
            Button21.Text = "×"
            Atari(21) = Atari(21) - 1

        ElseIf Hyo(21) = 3 Then
            Button21.Text = ""
            Hyo(21) = 0

        End If

        Shokei(6) = Atari(21) + Atari(22) + Atari(23) + Atari(24)

        Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        If Hant = 0 Then
            Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        ElseIf Hant = 1 Then
            Gokei(2) = Gokei(2) - (Shokei(8) + Shokei(9) + Shokei(10))

        ElseIf Hant = 2 Then
            Gokei(2) = Gokei(2) - (Shokei(9) + Shokei(10))
        End If

        Label2.Text = Gokei(2)
    End Sub
    Private Sub Button22_Click(sender As Object, e As EventArgs) Handles Button22.Click
        Hyo(22) = Hyo(22) + 1

        If Hyo(22) = 1 Then
            Button22.Text = "〇"
            Atari(22) = Atari(22) + 1

        ElseIf Hyo(22) = 2 Then
            Button22.Text = "×"
            Atari(22) = Atari(22) - 1

        ElseIf Hyo(22) = 3 Then
            Button22.Text = ""
            Hyo(22) = 0

        End If

        Shokei(6) = Atari(21) + Atari(22) + Atari(23) + Atari(24)

        Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        If Hant = 0 Then
            Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        ElseIf Hant = 1 Then
            Gokei(2) = Gokei(2) - (Shokei(8) + Shokei(9) + Shokei(10))

        ElseIf Hant = 2 Then
            Gokei(2) = Gokei(2) - (Shokei(9) + Shokei(10))
        End If

        Label2.Text = Gokei(2)
    End Sub
    Private Sub Button23_Click(sender As Object, e As EventArgs) Handles Button23.Click
        Hyo(23) = Hyo(23) + 1

        If Hyo(23) = 1 Then
            Button23.Text = "〇"
            Atari(23) = Atari(23) + 1

        ElseIf Hyo(23) = 2 Then
            Button23.Text = "×"
            Atari(23) = Atari(23) - 1

        ElseIf Hyo(23) = 3 Then
            Button23.Text = ""
            Hyo(23) = 0

        End If

        Shokei(6) = Atari(21) + Atari(22) + Atari(23) + Atari(24)

        Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        If Hant = 0 Then
            Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        ElseIf Hant = 1 Then
            Gokei(2) = Gokei(2) - (Shokei(8) + Shokei(9) + Shokei(10))

        ElseIf Hant = 2 Then
            Gokei(2) = Gokei(2) - (Shokei(9) + Shokei(10))
        End If

        Label2.Text = Gokei(2)
    End Sub
    Private Sub Button24_Click(sender As Object, e As EventArgs) Handles Button24.Click
        Hyo(24) = Hyo(24) + 1

        If Hyo(24) = 1 Then
            Button24.Text = "〇"
            Atari(24) = Atari(24) + 1

        ElseIf Hyo(24) = 2 Then
            Button24.Text = "×"
            Atari(24) = Atari(24) - 1

        ElseIf Hyo(24) = 3 Then
            Button24.Text = ""
            Hyo(24) = 0

        End If

        Shokei(6) = Atari(21) + Atari(22) + Atari(23) + Atari(24)

        Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        If Hant = 0 Then
            Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        ElseIf Hant = 1 Then
            Gokei(2) = Gokei(2) - (Shokei(8) + Shokei(9) + Shokei(10))

        ElseIf Hant = 2 Then
            Gokei(2) = Gokei(2) - (Shokei(9) + Shokei(10))
        End If

        Label2.Text = Gokei(2)
    End Sub

    Private Sub Button25_Click(sender As Object, e As EventArgs) Handles Button25.Click
        Hyo(25) = Hyo(25) + 1

        If Hyo(25) = 1 Then
            Button25.Text = "〇"
            Atari(25) = Atari(25) + 1

        ElseIf Hyo(25) = 2 Then
            Button25.Text = "×"
            Atari(25) = Atari(25) - 1

        ElseIf Hyo(25) = 3 Then
            Button25.Text = ""
            Hyo(25) = 0

        End If

        Shokei(7) = Atari(25) + Atari(26) + Atari(27) + Atari(28)

        Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        If Hant = 0 Then
            Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        ElseIf Hant = 1 Then
            Gokei(2) = Gokei(2) - (Shokei(8) + Shokei(9) + Shokei(10))

        ElseIf Hant = 2 Then
            Gokei(2) = Gokei(2) - (Shokei(9) + Shokei(10))
        End If

        Label2.Text = Gokei(2)
    End Sub
    Private Sub Button26_Click(sender As Object, e As EventArgs) Handles Button26.Click
        Hyo(26) = Hyo(26) + 1

        If Hyo(26) = 1 Then
            Button26.Text = "〇"
            Atari(26) = Atari(26) + 1

        ElseIf Hyo(26) = 2 Then
            Button26.Text = "×"
            Atari(26) = Atari(26) - 1

        ElseIf Hyo(26) = 3 Then
            Button26.Text = ""
            Hyo(26) = 0

        End If

        Shokei(7) = Atari(25) + Atari(26) + Atari(27) + Atari(28)

        Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        If Hant = 0 Then
            Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        ElseIf Hant = 1 Then
            Gokei(2) = Gokei(2) - (Shokei(8) + Shokei(9) + Shokei(10))

        ElseIf Hant = 2 Then
            Gokei(2) = Gokei(2) - (Shokei(9) + Shokei(10))
        End If

        Label2.Text = Gokei(2)

    End Sub
    Private Sub Button27_Click(sender As Object, e As EventArgs) Handles Button27.Click
        Hyo(27) = Hyo(27) + 1

        If Hyo(27) = 1 Then
            Button27.Text = "〇"
            Atari(27) = Atari(27) + 1

        ElseIf Hyo(27) = 2 Then
            Button27.Text = "×"
            Atari(27) = Atari(27) - 1

        ElseIf Hyo(27) = 3 Then
            Button27.Text = ""
            Hyo(27) = 0

        End If

        Shokei(7) = Atari(25) + Atari(26) + Atari(27) + Atari(28)

        Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        If Hant = 0 Then
            Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        ElseIf Hant = 1 Then
            Gokei(2) = Gokei(2) - (Shokei(8) + Shokei(9) + Shokei(10))

        ElseIf Hant = 2 Then
            Gokei(2) = Gokei(2) - (Shokei(9) + Shokei(10))
        End If

        Label2.Text = Gokei(2)
    End Sub
    Private Sub Button28_Click(sender As Object, e As EventArgs) Handles Button28.Click
        Hyo(28) = Hyo(28) + 1

        If Hyo(28) = 1 Then
            Button28.Text = "〇"
            Atari(28) = Atari(28) + 1

        ElseIf Hyo(28) = 2 Then
            Button28.Text = "×"
            Atari(28) = Atari(28) - 1

        ElseIf Hyo(28) = 3 Then
            Button28.Text = ""
            Hyo(28) = 0

        End If

        Shokei(7) = Atari(25) + Atari(26) + Atari(27) + Atari(28)

        Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        If Hant = 0 Then
            Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        ElseIf Hant = 1 Then
            Gokei(2) = Gokei(2) - (Shokei(8) + Shokei(9) + Shokei(10))

        ElseIf Hant = 2 Then
            Gokei(2) = Gokei(2) - (Shokei(9) + Shokei(10))
        End If

        Label2.Text = Gokei(2)
    End Sub

    Private Sub Button29_Click(sender As Object, e As EventArgs) Handles Button29.Click
        Hyo(29) = Hyo(29) + 1

        If Hyo(29) = 1 Then
            Button29.Text = "〇"
            Atari(29) = Atari(29) + 1

        ElseIf Hyo(29) = 2 Then
            Button29.Text = "×"
            Atari(29) = Atari(29) - 1

        ElseIf Hyo(29) = 3 Then
            Button29.Text = ""
            Hyo(29) = 0

        End If

        Shokei(8) = Atari(29) + Atari(30) + Atari(31) + Atari(32)

        Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        If Hant = 0 Then
            Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        ElseIf Hant = 1 Then
            Gokei(2) = Gokei(2) - (Shokei(8) + Shokei(9) + Shokei(10))

        ElseIf Hant = 2 Then
            Gokei(2) = Gokei(2) - (Shokei(9) + Shokei(10))
        End If

        Label2.Text = Gokei(2)
    End Sub
    Private Sub Button30_Click(sender As Object, e As EventArgs) Handles Button30.Click
        Hyo(30) = Hyo(30) + 1

        If Hyo(30) = 1 Then
            Button30.Text = "〇"
            Atari(30) = Atari(30) + 1

        ElseIf Hyo(30) = 2 Then
            Button30.Text = "×"
            Atari(30) = Atari(30) - 1

        ElseIf Hyo(30) = 3 Then
            Button30.Text = ""
            Hyo(30) = 0

        End If

        Shokei(8) = Atari(29) + Atari(30) + Atari(31) + Atari(32)

        Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        If Hant = 0 Then
            Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        ElseIf Hant = 1 Then
            Gokei(2) = Gokei(2) - (Shokei(8) + Shokei(9) + Shokei(10))

        ElseIf Hant = 2 Then
            Gokei(2) = Gokei(2) - (Shokei(9) + Shokei(10))
        End If

        Label2.Text = Gokei(2)
    End Sub
    Private Sub Button31_Click(sender As Object, e As EventArgs) Handles Button31.Click
        Hyo(31) = Hyo(31) + 1

        If Hyo(31) = 1 Then
            Button31.Text = "〇"
            Atari(31) = Atari(31) + 1

        ElseIf Hyo(31) = 2 Then
            Button31.Text = "×"
            Atari(31) = Atari(31) - 1

        ElseIf Hyo(31) = 3 Then
            Button31.Text = ""
            Hyo(31) = 0

        End If

        Shokei(8) = Atari(29) + Atari(30) + Atari(31) + Atari(32)

        Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        If Hant = 0 Then
            Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        ElseIf Hant = 1 Then
            Gokei(2) = Gokei(2) - (Shokei(8) + Shokei(9) + Shokei(10))

        ElseIf Hant = 2 Then
            Gokei(2) = Gokei(2) - (Shokei(9) + Shokei(10))
        End If

        Label2.Text = Gokei(2)
    End Sub
    Private Sub Button32_Click(sender As Object, e As EventArgs) Handles Button32.Click
        Hyo(32) = Hyo(32) + 1

        If Hyo(32) = 1 Then
            Button32.Text = "〇"
            Atari(32) = Atari(32) + 1

        ElseIf Hyo(32) = 2 Then
            Button32.Text = "×"
            Atari(32) = Atari(32) - 1

        ElseIf Hyo(32) = 3 Then
            Button32.Text = ""
            Hyo(32) = 0

        End If

        Shokei(8) = Atari(29) + Atari(30) + Atari(31) + Atari(32)

        Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        If Hant = 0 Then
            Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        ElseIf Hant = 1 Then
            Gokei(2) = Gokei(2) - (Shokei(8) + Shokei(9) + Shokei(10))

        ElseIf Hant = 2 Then
            Gokei(2) = Gokei(2) - (Shokei(9) + Shokei(10))
        End If

        Label2.Text = Gokei(2)
    End Sub

    Private Sub Button33_Click(sender As Object, e As EventArgs) Handles Button33.Click
        Hyo(33) = Hyo(33) + 1

        If Hyo(33) = 1 Then
            Button33.Text = "〇"
            Atari(33) = Atari(33) + 1

        ElseIf Hyo(33) = 2 Then
            Button33.Text = "×"
            Atari(33) = Atari(33) - 1

        ElseIf Hyo(33) = 3 Then
            Button33.Text = ""
            Hyo(33) = 0

        End If

        Shokei(9) = Atari(33) + Atari(34) + Atari(35) + Atari(36)

        Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        If Hant = 0 Then
            Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        ElseIf Hant = 1 Then
            Gokei(2) = Gokei(2) - (Shokei(8) + Shokei(9) + Shokei(10))

        ElseIf Hant = 2 Then
            Gokei(2) = Gokei(2) - (Shokei(9) + Shokei(10))
        End If

        Label2.Text = Gokei(2)
    End Sub
    Private Sub Button34_Click(sender As Object, e As EventArgs) Handles Button34.Click
        Hyo(34) = Hyo(34) + 1

        If Hyo(34) = 1 Then
            Button34.Text = "〇"
            Atari(34) = Atari(34) + 1

        ElseIf Hyo(34) = 2 Then
            Button34.Text = "×"
            Atari(34) = Atari(34) - 1

        ElseIf Hyo(34) = 3 Then
            Button34.Text = ""
            Hyo(34) = 0

        End If

        Shokei(9) = Atari(33) + Atari(34) + Atari(35) + Atari(36)

        Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        If Hant = 0 Then
            Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        ElseIf Hant = 1 Then
            Gokei(2) = Gokei(2) - (Shokei(8) + Shokei(9) + Shokei(10))

        ElseIf Hant = 2 Then
            Gokei(2) = Gokei(2) - (Shokei(9) + Shokei(10))
        End If

        Label2.Text = Gokei(2)
    End Sub
    Private Sub Button35_Click(sender As Object, e As EventArgs) Handles Button35.Click
        Hyo(35) = Hyo(35) + 1

        If Hyo(35) = 1 Then
            Button35.Text = "〇"
            Atari(35) = Atari(35) + 1

        ElseIf Hyo(35) = 2 Then
            Button35.Text = "×"
            Atari(35) = Atari(35) - 1

        ElseIf Hyo(35) = 3 Then
            Button35.Text = ""
            Hyo(35) = 0

        End If

        Shokei(9) = Atari(33) + Atari(34) + Atari(35) + Atari(36)

        Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        If Hant = 0 Then
            Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        ElseIf Hant = 1 Then
            Gokei(2) = Gokei(2) - (Shokei(8) + Shokei(9) + Shokei(10))

        ElseIf Hant = 2 Then
            Gokei(2) = Gokei(2) - (Shokei(9) + Shokei(10))
        End If

        Label2.Text = Gokei(2)
    End Sub
    Private Sub Button36_Click(sender As Object, e As EventArgs) Handles Button36.Click
        Hyo(36) = Hyo(36) + 1

        If Hyo(36) = 1 Then
            Button36.Text = "〇"
            Atari(36) = Atari(36) + 1

        ElseIf Hyo(36) = 2 Then
            Button36.Text = "×"
            Atari(36) = Atari(36) - 1

        ElseIf Hyo(36) = 3 Then
            Button36.Text = ""
            Hyo(36) = 0

        End If

        Shokei(9) = Atari(33) + Atari(34) + Atari(35) + Atari(36)

        Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        If Hant = 0 Then
            Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        ElseIf Hant = 1 Then
            Gokei(2) = Gokei(2) - (Shokei(8) + Shokei(9) + Shokei(10))

        ElseIf Hant = 2 Then
            Gokei(2) = Gokei(2) - (Shokei(9) + Shokei(10))
        End If

        Label2.Text = Gokei(2)
    End Sub

    Private Sub Button37_Click(sender As Object, e As EventArgs) Handles Button37.Click
        Hyo(37) = Hyo(37) + 1

        If Hyo(37) = 1 Then
            Button37.Text = "〇"
            Atari(37) = Atari(37) + 1

        ElseIf Hyo(37) = 2 Then
            Button37.Text = "×"
            Atari(37) = Atari(37) - 1

        ElseIf Hyo(37) = 3 Then
            Button37.Text = ""
            Hyo(37) = 0

        End If

        Shokei(10) = Atari(37) + Atari(38) + Atari(39) + Atari(40)

        Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        If Hant = 0 Then
            Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        ElseIf Hant = 1 Then
            Gokei(2) = Gokei(2) - (Shokei(8) + Shokei(9) + Shokei(10))

        ElseIf Hant = 2 Then
            Gokei(2) = Gokei(2) - (Shokei(9) + Shokei(10))
        End If

        Label2.Text = Gokei(2)
    End Sub
    Private Sub Button38_Click(sender As Object, e As EventArgs) Handles Button38.Click
        Hyo(38) = Hyo(38) + 1

        If Hyo(38) = 1 Then
            Button38.Text = "〇"
            Atari(38) = Atari(38) + 1

        ElseIf Hyo(38) = 2 Then
            Button38.Text = "×"
            Atari(38) = Atari(38) - 1

        ElseIf Hyo(38) = 3 Then
            Button38.Text = ""
            Hyo(38) = 0

        End If

        Shokei(10) = Atari(37) + Atari(38) + Atari(39) + Atari(40)

        Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        If Hant = 0 Then
            Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        ElseIf Hant = 1 Then
            Gokei(2) = Gokei(2) - (Shokei(8) + Shokei(9) + Shokei(10))

        ElseIf Hant = 2 Then
            Gokei(2) = Gokei(2) - (Shokei(9) + Shokei(10))
        End If

        Label2.Text = Gokei(2)
    End Sub
    Private Sub Button39_Click(sender As Object, e As EventArgs) Handles Button39.Click
        Hyo(39) = Hyo(39) + 1

        If Hyo(39) = 1 Then
            Button39.Text = "〇"
            Atari(39) = Atari(39) + 1

        ElseIf Hyo(39) = 2 Then
            Button39.Text = "×"
            Atari(39) = Atari(39) - 1

        ElseIf Hyo(39) = 3 Then
            Button39.Text = ""
            Hyo(39) = 0

        End If

        Shokei(10) = Atari(37) + Atari(38) + Atari(39) + Atari(40)

        Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        If Hant = 0 Then
            Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        ElseIf Hant = 1 Then
            Gokei(2) = Gokei(2) - (Shokei(8) + Shokei(9) + Shokei(10))

        ElseIf Hant = 2 Then
            Gokei(2) = Gokei(2) - (Shokei(9) + Shokei(10))
        End If

        Label2.Text = Gokei(2)
    End Sub
    Private Sub Button40_Click(sender As Object, e As EventArgs) Handles Button40.Click
        Hyo(40) = Hyo(40) + 1

        If Hyo(40) = 1 Then
            Button40.Text = "〇"
            Atari(40) = Atari(40) + 1

        ElseIf Hyo(40) = 2 Then
            Button40.Text = "×"
            Atari(40) = Atari(40) - 1

        ElseIf Hyo(40) = 3 Then
            Button40.Text = ""
            Hyo(40) = 0

        End If

        Shokei(10) = Atari(37) + Atari(38) + Atari(39) + Atari(40)

        Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        If Hant = 0 Then
            Gokei(2) = Shokei(6) + Shokei(7) + Shokei(8) + Shokei(9) + Shokei(10)

        ElseIf Hant = 1 Then
            Gokei(2) = Gokei(2) - (Shokei(8) + Shokei(9) + Shokei(10))

        ElseIf Hant = 2 Then
            Gokei(2) = Gokei(2) - (Shokei(9) + Shokei(10))
        End If

        Label2.Text = Gokei(2)
    End Sub



    Private Sub Button41_Click(sender As Object, e As EventArgs) Handles Button41.Click
        Hyo(41) = Hyo(41) + 1

        If Hyo(41) = 1 Then
            Button41.Text = "〇"
            Atari(41) = Atari(41) + 1

        ElseIf Hyo(41) = 2 Then
            Button41.Text = "×"
            Atari(41) = Atari(41) - 1

        ElseIf Hyo(41) = 3 Then
            Button41.Text = ""
            Hyo(41) = 0

        End If

        Shokei(11) = Atari(41) + Atari(42) + Atari(43) + Atari(44)

        Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        If Hant = 0 Then
            Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        ElseIf Hant = 1 Then
            Gokei(3) = Gokei(3) - (Shokei(13) + Shokei(14) + Shokei(15))

        ElseIf Hant = 2 Then
            Gokei(3) = Gokei(3) - (Shokei(14) + Shokei(15))
        End If

        Label3.Text = Gokei(3)
    End Sub
    Private Sub Button42_Click(sender As Object, e As EventArgs) Handles Button42.Click
        Hyo(42) = Hyo(42) + 1

        If Hyo(42) = 1 Then
            Button42.Text = "〇"
            Atari(42) = Atari(42) + 1

        ElseIf Hyo(42) = 2 Then
            Button42.Text = "×"
            Atari(42) = Atari(42) - 1

        ElseIf Hyo(42) = 3 Then
            Button42.Text = ""
            Hyo(42) = 0

        End If

        Shokei(11) = Atari(41) + Atari(42) + Atari(43) + Atari(44)

        Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        If Hant = 0 Then
            Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        ElseIf Hant = 1 Then
            Gokei(3) = Gokei(3) - (Shokei(13) + Shokei(14) + Shokei(15))

        ElseIf Hant = 2 Then
            Gokei(3) = Gokei(3) - (Shokei(14) + Shokei(15))
        End If

        Label3.Text = Gokei(3)
    End Sub
    Private Sub Button43_Click(sender As Object, e As EventArgs) Handles Button43.Click
        Hyo(43) = Hyo(43) + 1

        If Hyo(43) = 1 Then
            Button43.Text = "〇"
            Atari(43) = Atari(43) + 1

        ElseIf Hyo(43) = 2 Then
            Button43.Text = "×"
            Atari(43) = Atari(43) - 1

        ElseIf Hyo(43) = 3 Then
            Button43.Text = ""
            Hyo(43) = 0

        End If

        Shokei(11) = Atari(41) + Atari(42) + Atari(43) + Atari(44)

        Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        If Hant = 0 Then
            Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        ElseIf Hant = 1 Then
            Gokei(3) = Gokei(3) - (Shokei(13) + Shokei(14) + Shokei(15))

        ElseIf Hant = 2 Then
            Gokei(3) = Gokei(3) - (Shokei(14) + Shokei(15))
        End If

        Label3.Text = Gokei(3)
    End Sub
    Private Sub Button44_Click(sender As Object, e As EventArgs) Handles Button44.Click
        Hyo(44) = Hyo(44) + 1

        If Hyo(44) = 1 Then
            Button44.Text = "〇"
            Atari(44) = Atari(44) + 1

        ElseIf Hyo(44) = 2 Then
            Button44.Text = "×"
            Atari(44) = Atari(44) - 1

        ElseIf Hyo(44) = 3 Then
            Button44.Text = ""
            Hyo(44) = 0

        End If

        Shokei(11) = Atari(41) + Atari(42) + Atari(43) + Atari(44)

        Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        If Hant = 0 Then
            Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        ElseIf Hant = 1 Then
            Gokei(3) = Gokei(3) - (Shokei(13) + Shokei(14) + Shokei(15))

        ElseIf Hant = 2 Then
            Gokei(3) = Gokei(3) - (Shokei(14) + Shokei(15))
        End If

        Label3.Text = Gokei(3)
    End Sub

    Private Sub Button45_Click(sender As Object, e As EventArgs) Handles Button45.Click
        Hyo(45) = Hyo(45) + 1

        If Hyo(45) = 1 Then
            Button45.Text = "〇"
            Atari(45) = Atari(45) + 1

        ElseIf Hyo(45) = 2 Then
            Button45.Text = "×"
            Atari(45) = Atari(45) - 1

        ElseIf Hyo(45) = 3 Then
            Button45.Text = ""
            Hyo(45) = 0
        End If

        Shokei(12) = Atari(45) + Atari(46) + Atari(47) + Atari(48)

        Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        If Hant = 0 Then
            Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        ElseIf Hant = 1 Then
            Gokei(3) = Gokei(3) - (Shokei(13) + Shokei(14) + Shokei(15))

        ElseIf Hant = 2 Then
            Gokei(3) = Gokei(3) - (Shokei(14) + Shokei(15))
        End If

        Label3.Text = Gokei(3)
    End Sub
    Private Sub Button46_Click(sender As Object, e As EventArgs) Handles Button46.Click
        Hyo(46) = Hyo(46) + 1

        If Hyo(46) = 1 Then
            Button46.Text = "〇"
            Atari(46) = Atari(46) + 1

        ElseIf Hyo(46) = 2 Then
            Button46.Text = "×"
            Atari(46) = Atari(46) - 1

        ElseIf Hyo(46) = 3 Then
            Button46.Text = ""
            Hyo(46) = 0
        End If

        Shokei(12) = Atari(45) + Atari(46) + Atari(47) + Atari(48)

        Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        If Hant = 0 Then
            Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        ElseIf Hant = 1 Then
            Gokei(3) = Gokei(3) - (Shokei(13) + Shokei(14) + Shokei(15))

        ElseIf Hant = 2 Then
            Gokei(3) = Gokei(3) - (Shokei(14) + Shokei(15))
        End If

        Label3.Text = Gokei(3)
    End Sub
    Private Sub Button47_Click(sender As Object, e As EventArgs) Handles Button47.Click
        Hyo(47) = Hyo(47) + 1

        If Hyo(47) = 1 Then
            Button47.Text = "〇"
            Atari(47) = Atari(47) + 1

        ElseIf Hyo(47) = 2 Then
            Button47.Text = "×"
            Atari(47) = Atari(47) - 1

        ElseIf Hyo(47) = 3 Then
            Button47.Text = ""
            Hyo(47) = 0
        End If

        Shokei(12) = Atari(45) + Atari(46) + Atari(47) + Atari(48)

        Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        If Hant = 0 Then
            Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        ElseIf Hant = 1 Then
            Gokei(3) = Gokei(3) - (Shokei(13) + Shokei(14) + Shokei(15))

        ElseIf Hant = 2 Then
            Gokei(3) = Gokei(3) - (Shokei(14) + Shokei(15))
        End If

        Label3.Text = Gokei(3)
    End Sub
    Private Sub Button48_Click(sender As Object, e As EventArgs) Handles Button48.Click
        Hyo(48) = Hyo(48) + 1

        If Hyo(48) = 1 Then
            Button48.Text = "〇"
            Atari(48) = Atari(48) + 1

        ElseIf Hyo(48) = 2 Then
            Button48.Text = "×"
            Atari(48) = Atari(48) - 1

        ElseIf Hyo(48) = 3 Then
            Button48.Text = ""
            Hyo(48) = 0
        End If

        Shokei(12) = Atari(45) + Atari(46) + Atari(47) + Atari(48)

        Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        If Hant = 0 Then
            Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        ElseIf Hant = 1 Then
            Gokei(3) = Gokei(3) - (Shokei(13) + Shokei(14) + Shokei(15))

        ElseIf Hant = 2 Then
            Gokei(3) = Gokei(3) - (Shokei(14) + Shokei(15))
        End If

        Label3.Text = Gokei(3)
    End Sub

    Private Sub Button49_Click(sender As Object, e As EventArgs) Handles Button49.Click
        Hyo(49) = Hyo(49) + 1

        If Hyo(49) = 1 Then
            Button49.Text = "〇"
            Atari(49) = Atari(49) + 1

        ElseIf Hyo(49) = 2 Then
            Button49.Text = "×"
            Atari(49) = Atari(49) - 1

        ElseIf Hyo(49) = 3 Then
            Button49.Text = ""
            Hyo(49) = 0

        End If

        Shokei(13) = Atari(49) + Atari(50) + Atari(51) + Atari(52)

        Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        If Hant = 0 Then
            Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        ElseIf Hant = 1 Then
            Gokei(3) = Gokei(3) - (Shokei(13) + Shokei(14) + Shokei(15))

        ElseIf Hant = 2 Then
            Gokei(3) = Gokei(3) - (Shokei(14) + Shokei(15))
        End If

        Label3.Text = Gokei(3)
    End Sub
    Private Sub Button50_Click(sender As Object, e As EventArgs) Handles Button50.Click
        Hyo(50) = Hyo(50) + 1

        If Hyo(50) = 1 Then
            Button50.Text = "〇"
            Atari(50) = Atari(50) + 1

        ElseIf Hyo(50) = 2 Then
            Button50.Text = "×"
            Atari(50) = Atari(50) - 1

        ElseIf Hyo(50) = 3 Then
            Button50.Text = ""
            Hyo(50) = 0

        End If

        Shokei(13) = Atari(49) + Atari(50) + Atari(51) + Atari(52)

        Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        If Hant = 0 Then
            Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        ElseIf Hant = 1 Then
            Gokei(3) = Gokei(3) - (Shokei(13) + Shokei(14) + Shokei(15))

        ElseIf Hant = 2 Then
            Gokei(3) = Gokei(3) - (Shokei(14) + Shokei(15))
        End If

        Label3.Text = Gokei(3)
    End Sub
    Private Sub Button51_Click(sender As Object, e As EventArgs) Handles Button51.Click
        Hyo(51) = Hyo(51) + 1

        If Hyo(51) = 1 Then
            Button51.Text = "〇"
            Atari(51) = Atari(51) + 1

        ElseIf Hyo(51) = 2 Then
            Button51.Text = "×"
            Atari(51) = Atari(51) - 1

        ElseIf Hyo(51) = 3 Then
            Button51.Text = ""
            Hyo(51) = 0

        End If

        Shokei(13) = Atari(49) + Atari(50) + Atari(51) + Atari(52)

        Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        If Hant = 0 Then
            Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        ElseIf Hant = 1 Then
            Gokei(3) = Gokei(3) - (Shokei(13) + Shokei(14) + Shokei(15))

        ElseIf Hant = 2 Then
            Gokei(3) = Gokei(3) - (Shokei(14) + Shokei(15))
        End If

        Label3.Text = Gokei(3)
    End Sub
    Private Sub Button52_Click(sender As Object, e As EventArgs) Handles Button52.Click
        Hyo(52) = Hyo(52) + 1

        If Hyo(52) = 1 Then
            Button52.Text = "〇"
            Atari(52) = Atari(52) + 1

        ElseIf Hyo(52) = 2 Then
            Button52.Text = "×"
            Atari(52) = Atari(52) - 1

        ElseIf Hyo(52) = 3 Then
            Button52.Text = ""
            Hyo(52) = 0

        End If

        Shokei(13) = Atari(49) + Atari(50) + Atari(51) + Atari(52)

        Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        If Hant = 0 Then
            Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        ElseIf Hant = 1 Then
            Gokei(3) = Gokei(3) - (Shokei(13) + Shokei(14) + Shokei(15))

        ElseIf Hant = 2 Then
            Gokei(3) = Gokei(3) - (Shokei(14) + Shokei(15))
        End If

        Label3.Text = Gokei(3)
    End Sub

    Private Sub Button53_Click(sender As Object, e As EventArgs) Handles Button53.Click
        Hyo(53) = Hyo(53) + 1

        If Hyo(53) = 1 Then
            Button53.Text = "〇"
            Atari(53) = Atari(53) + 1

        ElseIf Hyo(53) = 2 Then
            Button53.Text = "×"
            Atari(53) = Atari(53) - 1

        ElseIf Hyo(53) = 3 Then
            Button53.Text = ""
            Hyo(53) = 0

        End If

        Shokei(14) = Atari(53) + Atari(54) + Atari(55) + Atari(56)

        Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        If Hant = 0 Then
            Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        ElseIf Hant = 1 Then
            Gokei(3) = Gokei(3) - (Shokei(13) + Shokei(14) + Shokei(15))

        ElseIf Hant = 2 Then
            Gokei(3) = Gokei(3) - (Shokei(14) + Shokei(15))
        End If

        Label3.Text = Gokei(3)
    End Sub
    Private Sub Button54_Click(sender As Object, e As EventArgs) Handles Button54.Click
        Hyo(54) = Hyo(54) + 1

        If Hyo(54) = 1 Then
            Button54.Text = "〇"
            Atari(54) = Atari(54) + 1

        ElseIf Hyo(54) = 2 Then
            Button54.Text = "×"
            Atari(54) = Atari(54) - 1

        ElseIf Hyo(54) = 3 Then
            Button54.Text = ""
            Hyo(54) = 0

        End If

        Shokei(14) = Atari(53) + Atari(54) + Atari(55) + Atari(56)

        Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        If Hant = 0 Then
            Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        ElseIf Hant = 1 Then
            Gokei(3) = Gokei(3) - (Shokei(13) + Shokei(14) + Shokei(15))

        ElseIf Hant = 2 Then
            Gokei(3) = Gokei(3) - (Shokei(14) + Shokei(15))
        End If

        Label3.Text = Gokei(3)
    End Sub
    Private Sub Button55_Click(sender As Object, e As EventArgs) Handles Button55.Click
        Hyo(55) = Hyo(55) + 1

        If Hyo(55) = 1 Then
            Button55.Text = "〇"
            Atari(55) = Atari(55) + 1

        ElseIf Hyo(55) = 2 Then
            Button55.Text = "×"
            Atari(55) = Atari(55) - 1

        ElseIf Hyo(55) = 3 Then
            Button55.Text = ""
            Hyo(55) = 0

        End If

        Shokei(14) = Atari(53) + Atari(54) + Atari(55) + Atari(56)

        Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        If Hant = 0 Then
            Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        ElseIf Hant = 1 Then
            Gokei(3) = Gokei(3) - (Shokei(13) + Shokei(14) + Shokei(15))

        ElseIf Hant = 2 Then
            Gokei(3) = Gokei(3) - (Shokei(14) + Shokei(15))
        End If

        Label3.Text = Gokei(3)
    End Sub
    Private Sub Button56_Click(sender As Object, e As EventArgs) Handles Button56.Click
        Hyo(56) = Hyo(56) + 1

        If Hyo(56) = 1 Then
            Button56.Text = "〇"
            Atari(56) = Atari(56) + 1

        ElseIf Hyo(56) = 2 Then
            Button56.Text = "×"
            Atari(56) = Atari(56) - 1

        ElseIf Hyo(56) = 3 Then
            Button56.Text = ""
            Hyo(56) = 0

        End If

        Shokei(14) = Atari(53) + Atari(54) + Atari(55) + Atari(56)

        Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        If Hant = 0 Then
            Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        ElseIf Hant = 1 Then
            Gokei(3) = Gokei(3) - (Shokei(13) + Shokei(14) + Shokei(15))

        ElseIf Hant = 2 Then
            Gokei(3) = Gokei(3) - (Shokei(14) + Shokei(15))
        End If

        Label3.Text = Gokei(3)
    End Sub

    Private Sub Button57_Click(sender As Object, e As EventArgs) Handles Button57.Click
        Hyo(57) = Hyo(57) + 1

        If Hyo(57) = 1 Then
            Button57.Text = "〇"
            Atari(57) = Atari(57) + 1

        ElseIf Hyo(57) = 2 Then
            Button57.Text = "×"
            Atari(57) = Atari(57) - 1

        ElseIf Hyo(57) = 3 Then
            Button57.Text = ""
            Hyo(57) = 0

        End If

        Shokei(15) = Atari(57) + Atari(58) + Atari(59) + Atari(60)

        Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        If Hant = 0 Then
            Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        ElseIf Hant = 1 Then
            Gokei(3) = Gokei(3) - (Shokei(13) + Shokei(14) + Shokei(15))

        ElseIf Hant = 2 Then
            Gokei(3) = Gokei(3) - (Shokei(14) + Shokei(15))
        End If

        Label3.Text = Gokei(3)
    End Sub
    Private Sub Button58_Click(sender As Object, e As EventArgs) Handles Button58.Click
        Hyo(58) = Hyo(58) + 1

        If Hyo(58) = 1 Then
            Button58.Text = "〇"
            Atari(58) = Atari(58) + 1

        ElseIf Hyo(58) = 2 Then
            Button58.Text = "×"
            Atari(58) = Atari(58) - 1

        ElseIf Hyo(58) = 3 Then
            Button58.Text = ""
            Hyo(58) = 0

        End If

        Shokei(15) = Atari(57) + Atari(58) + Atari(59) + Atari(60)

        Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        If Hant = 0 Then
            Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        ElseIf Hant = 1 Then
            Gokei(3) = Gokei(3) - (Shokei(13) + Shokei(14) + Shokei(15))

        ElseIf Hant = 2 Then
            Gokei(3) = Gokei(3) - (Shokei(14) + Shokei(15))
        End If

        Label3.Text = Gokei(3)
    End Sub
    Private Sub Button59_Click(sender As Object, e As EventArgs) Handles Button59.Click
        Hyo(59) = Hyo(59) + 1

        If Hyo(59) = 1 Then
            Button59.Text = "〇"
            Atari(59) = Atari(59) + 1

        ElseIf Hyo(59) = 2 Then
            Button59.Text = "×"
            Atari(59) = Atari(59) - 1

        ElseIf Hyo(59) = 3 Then
            Button59.Text = ""
            Hyo(59) = 0

        End If

        Shokei(15) = Atari(57) + Atari(58) + Atari(59) + Atari(60)

        Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        If Hant = 0 Then
            Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        ElseIf Hant = 1 Then
            Gokei(3) = Gokei(3) - (Shokei(13) + Shokei(14) + Shokei(15))

        ElseIf Hant = 2 Then
            Gokei(3) = Gokei(3) - (Shokei(14) + Shokei(15))
        End If

        Label3.Text = Gokei(3)
    End Sub
    Private Sub Button60_Click(sender As Object, e As EventArgs) Handles Button60.Click
        Hyo(60) = Hyo(60) + 1

        If Hyo(60) = 1 Then
            Button60.Text = "〇"
            Atari(60) = Atari(60) + 1

        ElseIf Hyo(60) = 2 Then
            Button60.Text = "×"
            Atari(60) = Atari(60) - 1

        ElseIf Hyo(60) = 3 Then
            Button60.Text = ""
            Hyo(60) = 0

        End If

        Shokei(15) = Atari(57) + Atari(58) + Atari(59) + Atari(60)

        Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        If Hant = 0 Then
            Gokei(3) = Shokei(11) + Shokei(12) + Shokei(13) + Shokei(14) + Shokei(15)

        ElseIf Hant = 1 Then
            Gokei(3) = Gokei(3) - (Shokei(13) + Shokei(14) + Shokei(15))

        ElseIf Hant = 2 Then
            Gokei(3) = Gokei(3) - (Shokei(14) + Shokei(15))
        End If

        Label3.Text = Gokei(3)
    End Sub



    Private Sub Button61_Click(sender As Object, e As EventArgs) Handles Button61.Click
        Hyo(61) = Hyo(61) + 1

        If Hyo(61) = 1 Then
            Button61.Text = "〇"
            Atari(61) = Atari(61) + 1

        ElseIf Hyo(61) = 2 Then
            Button61.Text = "×"
            Atari(61) = Atari(61) - 1

        ElseIf Hyo(61) = 3 Then
            Button61.Text = ""
            Hyo(61) = 0

        End If

        Shokei(16) = Atari(61) + Atari(62) + Atari(63) + Atari(64)

        Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        If Hant = 0 Then
            Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        ElseIf Hant = 1 Then
            Gokei(4) = Gokei(4) - (Shokei(18) + Shokei(19) + Shokei(20))

        ElseIf Hant = 2 Then
            Gokei(4) = Gokei(4) - (Shokei(19) + Shokei(20))
        End If

        Label4.Text = Gokei(4)
    End Sub
    Private Sub Button62_Click(sender As Object, e As EventArgs) Handles Button62.Click
        Hyo(62) = Hyo(62) + 1

        If Hyo(62) = 1 Then
            Button62.Text = "〇"
            Atari(62) = Atari(62) + 1

        ElseIf Hyo(62) = 2 Then
            Button62.Text = "×"
            Atari(62) = Atari(62) - 1

        ElseIf Hyo(62) = 3 Then
            Button62.Text = ""
            Hyo(62) = 0

        End If

        Shokei(16) = Atari(61) + Atari(62) + Atari(63) + Atari(64)

        Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        If Hant = 0 Then
            Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        ElseIf Hant = 1 Then
            Gokei(4) = Gokei(4) - (Shokei(18) + Shokei(19) + Shokei(20))

        ElseIf Hant = 2 Then
            Gokei(4) = Gokei(4) - (Shokei(19) + Shokei(20))
        End If

        Label4.Text = Gokei(4)
    End Sub
    Private Sub Button63_Click(sender As Object, e As EventArgs) Handles Button63.Click
        Hyo(63) = Hyo(63) + 1

        If Hyo(63) = 1 Then
            Button63.Text = "〇"
            Atari(63) = Atari(63) + 1

        ElseIf Hyo(63) = 2 Then
            Button63.Text = "×"
            Atari(63) = Atari(63) - 1

        ElseIf Hyo(63) = 3 Then
            Button63.Text = ""
            Hyo(63) = 0

        End If

        Shokei(16) = Atari(61) + Atari(62) + Atari(63) + Atari(64)

        Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        If Hant = 0 Then
            Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        ElseIf Hant = 1 Then
            Gokei(4) = Gokei(4) - (Shokei(18) + Shokei(19) + Shokei(20))

        ElseIf Hant = 2 Then
            Gokei(4) = Gokei(4) - (Shokei(19) + Shokei(20))
        End If

        Label4.Text = Gokei(4)
    End Sub
    Private Sub Button64_Click(sender As Object, e As EventArgs) Handles Button64.Click
        Hyo(64) = Hyo(64) + 1

        If Hyo(64) = 1 Then
            Button64.Text = "〇"
            Atari(64) = Atari(64) + 1

        ElseIf Hyo(64) = 2 Then
            Button64.Text = "×"
            Atari(64) = Atari(64) - 1

        ElseIf Hyo(64) = 3 Then
            Button64.Text = ""
            Hyo(64) = 0

        End If

        Shokei(16) = Atari(61) + Atari(62) + Atari(63) + Atari(64)

        Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        If Hant = 0 Then
            Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        ElseIf Hant = 1 Then
            Gokei(4) = Gokei(4) - (Shokei(18) + Shokei(19) + Shokei(20))

        ElseIf Hant = 2 Then
            Gokei(4) = Gokei(4) - (Shokei(19) + Shokei(20))
        End If

        Label4.Text = Gokei(4)
    End Sub

    Private Sub Button65_Click(sender As Object, e As EventArgs) Handles Button65.Click
        Hyo(65) = Hyo(65) + 1

        If Hyo(65) = 1 Then
            Button65.Text = "〇"
            Atari(65) = Atari(65) + 1

        ElseIf Hyo(65) = 2 Then
            Button65.Text = "×"
            Atari(65) = Atari(65) - 1

        ElseIf Hyo(65) = 3 Then
            Button65.Text = ""
            Hyo(65) = 0

        End If

        Shokei(17) = Atari(65) + Atari(66) + Atari(67) + Atari(68)

        Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        If Hant = 0 Then
            Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        ElseIf Hant = 1 Then
            Gokei(4) = Gokei(4) - (Shokei(18) + Shokei(19) + Shokei(20))

        ElseIf Hant = 2 Then
            Gokei(4) = Gokei(4) - (Shokei(19) + Shokei(20))
        End If

        Label4.Text = Gokei(4)
    End Sub
    Private Sub Button66_Click(sender As Object, e As EventArgs) Handles Button66.Click
        Hyo(66) = Hyo(66) + 1

        If Hyo(66) = 1 Then
            Button66.Text = "〇"
            Atari(66) = Atari(66) + 1

        ElseIf Hyo(66) = 2 Then
            Button66.Text = "×"
            Atari(66) = Atari(66) - 1

        ElseIf Hyo(66) = 3 Then
            Button66.Text = ""
            Hyo(66) = 0

        End If

        Shokei(17) = Atari(65) + Atari(66) + Atari(67) + Atari(68)

        Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        If Hant = 0 Then
            Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        ElseIf Hant = 1 Then
            Gokei(4) = Gokei(4) - (Shokei(18) + Shokei(19) + Shokei(20))

        ElseIf Hant = 2 Then
            Gokei(4) = Gokei(4) - (Shokei(19) + Shokei(20))
        End If

        Label4.Text = Gokei(4)
    End Sub
    Private Sub Button67_Click(sender As Object, e As EventArgs) Handles Button67.Click
        Hyo(67) = Hyo(67) + 1

        If Hyo(67) = 1 Then
            Button67.Text = "〇"
            Atari(67) = Atari(67) + 1

        ElseIf Hyo(67) = 2 Then
            Button67.Text = "×"
            Atari(67) = Atari(67) - 1

        ElseIf Hyo(67) = 3 Then
            Button67.Text = ""
            Hyo(67) = 0

        End If

        Shokei(17) = Atari(65) + Atari(66) + Atari(67) + Atari(68)

        Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        If Hant = 0 Then
            Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        ElseIf Hant = 1 Then
            Gokei(4) = Gokei(4) - (Shokei(18) + Shokei(19) + Shokei(20))

        ElseIf Hant = 2 Then
            Gokei(4) = Gokei(4) - (Shokei(19) + Shokei(20))
        End If

        Label4.Text = Gokei(4)
    End Sub
    Private Sub Button68_Click(sender As Object, e As EventArgs) Handles Button68.Click
        Hyo(68) = Hyo(68) + 1

        If Hyo(68) = 1 Then
            Button68.Text = "〇"
            Atari(68) = Atari(68) + 1

        ElseIf Hyo(68) = 2 Then
            Button68.Text = "×"
            Atari(68) = Atari(68) - 1

        ElseIf Hyo(68) = 3 Then
            Button68.Text = ""
            Hyo(68) = 0

        End If

        Shokei(17) = Atari(65) + Atari(66) + Atari(67) + Atari(68)

        Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        If Hant = 0 Then
            Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        ElseIf Hant = 1 Then
            Gokei(4) = Gokei(4) - (Shokei(18) + Shokei(19) + Shokei(20))

        ElseIf Hant = 2 Then
            Gokei(4) = Gokei(4) - (Shokei(19) + Shokei(20))
        End If

        Label4.Text = Gokei(4)
    End Sub

    Private Sub Button69_Click(sender As Object, e As EventArgs) Handles Button69.Click
        Hyo(69) = Hyo(69) + 1

        If Hyo(69) = 1 Then
            Button69.Text = "〇"
            Atari(69) = Atari(69) + 1

        ElseIf Hyo(69) = 2 Then
            Button69.Text = "×"
            Atari(69) = Atari(69) - 1

        ElseIf Hyo(69) = 3 Then
            Button69.Text = ""
            Hyo(69) = 0

        End If

        Shokei(18) = Atari(69) + Atari(70) + Atari(71) + Atari(72)

        Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        If Hant = 0 Then
            Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        ElseIf Hant = 1 Then
            Gokei(4) = Gokei(4) - (Shokei(18) + Shokei(19) + Shokei(20))

        ElseIf Hant = 2 Then
            Gokei(4) = Gokei(4) - (Shokei(19) + Shokei(20))
        End If

        Label4.Text = Gokei(4)
    End Sub
    Private Sub Button70_Click(sender As Object, e As EventArgs) Handles Button70.Click
        Hyo(70) = Hyo(70) + 1

        If Hyo(70) = 1 Then
            Button70.Text = "〇"
            Atari(70) = Atari(70) + 1

        ElseIf Hyo(70) = 2 Then
            Button70.Text = "×"
            Atari(70) = Atari(70) - 1

        ElseIf Hyo(70) = 3 Then
            Button70.Text = ""
            Hyo(70) = 0
        End If

        Shokei(18) = Atari(69) + Atari(70) + Atari(71) + Atari(72)

        Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        If Hant = 0 Then
            Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        ElseIf Hant = 1 Then
            Gokei(4) = Gokei(4) - (Shokei(18) + Shokei(19) + Shokei(20))

        ElseIf Hant = 2 Then
            Gokei(4) = Gokei(4) - (Shokei(19) + Shokei(20))
        End If

        Label4.Text = Gokei(4)
    End Sub
    Private Sub Button71_Click(sender As Object, e As EventArgs) Handles Button71.Click
        Hyo(71) = Hyo(71) + 1

        If Hyo(71) = 1 Then
            Button71.Text = "〇"
            Atari(71) = Atari(71) + 1

        ElseIf Hyo(71) = 2 Then
            Button71.Text = "×"
            Atari(71) = Atari(71) - 1

        ElseIf Hyo(71) = 3 Then
            Button71.Text = ""
            Hyo(71) = 0
        End If

        Shokei(18) = Atari(69) + Atari(70) + Atari(71) + Atari(72)

        Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        If Hant = 0 Then
            Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        ElseIf Hant = 1 Then
            Gokei(4) = Gokei(4) - (Shokei(18) + Shokei(19) + Shokei(20))

        ElseIf Hant = 2 Then
            Gokei(4) = Gokei(4) - (Shokei(19) + Shokei(20))
        End If

        Label4.Text = Gokei(4)
    End Sub
    Private Sub Button72_Click(sender As Object, e As EventArgs) Handles Button72.Click
        Hyo(72) = Hyo(72) + 1

        If Hyo(72) = 1 Then
            Button72.Text = "〇"
            Atari(72) = Atari(72) + 1

        ElseIf Hyo(72) = 2 Then
            Button72.Text = "×"
            Atari(72) = Atari(72) - 1

        ElseIf Hyo(72) = 3 Then
            Button72.Text = ""
            Hyo(72) = 0
        End If

        Shokei(18) = Atari(69) + Atari(70) + Atari(71) + Atari(72)

        Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        If Hant = 0 Then
            Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        ElseIf Hant = 1 Then
            Gokei(4) = Gokei(4) - (Shokei(18) + Shokei(19) + Shokei(20))

        ElseIf Hant = 2 Then
            Gokei(4) = Gokei(4) - (Shokei(19) + Shokei(20))
        End If

        Label4.Text = Gokei(4)
    End Sub

    Private Sub Button73_Click(sender As Object, e As EventArgs) Handles Button73.Click
        Hyo(73) = Hyo(73) + 1

        If Hyo(73) = 1 Then
            Button73.Text = "〇"
            Atari(73) = Atari(73) + 1

        ElseIf Hyo(73) = 2 Then
            Button73.Text = "×"
            Atari(73) = Atari(73) - 1

        ElseIf Hyo(73) = 3 Then
            Button73.Text = ""
            Hyo(73) = 0
        End If

        Shokei(19) = Atari(73) + Atari(74) + Atari(75) + Atari(76)

        Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        If Hant = 0 Then
            Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        ElseIf Hant = 1 Then
            Gokei(4) = Gokei(4) - (Shokei(18) + Shokei(19) + Shokei(20))

        ElseIf Hant = 2 Then
            Gokei(4) = Gokei(4) - (Shokei(19) + Shokei(20))
        End If

        Label4.Text = Gokei(4)
    End Sub
    Private Sub Button74_Click(sender As Object, e As EventArgs) Handles Button74.Click
        Hyo(74) = Hyo(74) + 1

        If Hyo(74) = 1 Then
            Button74.Text = "〇"
            Atari(74) = Atari(74) + 1

        ElseIf Hyo(74) = 2 Then
            Button74.Text = "×"
            Atari(74) = Atari(74) - 1

        ElseIf Hyo(74) = 3 Then
            Button74.Text = ""
            Hyo(74) = 0
        End If

        Shokei(19) = Atari(73) + Atari(74) + Atari(75) + Atari(76)

        Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        If Hant = 0 Then
            Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        ElseIf Hant = 1 Then
            Gokei(4) = Gokei(4) - (Shokei(18) + Shokei(19) + Shokei(20))

        ElseIf Hant = 2 Then
            Gokei(4) = Gokei(4) - (Shokei(19) + Shokei(20))
        End If

        Label4.Text = Gokei(4)
    End Sub
    Private Sub Button75_Click(sender As Object, e As EventArgs) Handles Button75.Click
        Hyo(75) = Hyo(75) + 1

        If Hyo(75) = 1 Then
            Button75.Text = "〇"
            Atari(75) = Atari(75) + 1

        ElseIf Hyo(75) = 2 Then
            Button75.Text = "×"
            Atari(75) = Atari(75) - 1

        ElseIf Hyo(75) = 3 Then
            Button75.Text = ""
            Hyo(75) = 0
        End If

        Shokei(19) = Atari(73) + Atari(74) + Atari(75) + Atari(76)

        Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        If Hant = 0 Then
            Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        ElseIf Hant = 1 Then
            Gokei(4) = Gokei(4) - (Shokei(18) + Shokei(19) + Shokei(20))

        ElseIf Hant = 2 Then
            Gokei(4) = Gokei(4) - (Shokei(19) + Shokei(20))
        End If

        Label4.Text = Gokei(4)
    End Sub
    Private Sub Button76_Click(sender As Object, e As EventArgs) Handles Button76.Click
        Hyo(76) = Hyo(76) + 1

        If Hyo(76) = 1 Then
            Button76.Text = "〇"
            Atari(76) = Atari(76) + 1

        ElseIf Hyo(76) = 2 Then
            Button76.Text = "×"
            Atari(76) = Atari(76) - 1

        ElseIf Hyo(76) = 3 Then
            Button76.Text = ""
            Hyo(76) = 0
        End If

        Shokei(19) = Atari(73) + Atari(74) + Atari(75) + Atari(76)

        Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        If Hant = 0 Then
            Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        ElseIf Hant = 1 Then
            Gokei(4) = Gokei(4) - (Shokei(18) + Shokei(19) + Shokei(20))

        ElseIf Hant = 2 Then
            Gokei(4) = Gokei(4) - (Shokei(19) + Shokei(20))
        End If

        Label4.Text = Gokei(4)
    End Sub

    Private Sub Button77_Click(sender As Object, e As EventArgs) Handles Button77.Click
        Hyo(77) = Hyo(77) + 1

        If Hyo(77) = 1 Then
            Button77.Text = "〇"
            Atari(77) = Atari(77) + 1

        ElseIf Hyo(77) = 2 Then
            Button77.Text = "×"
            Atari(77) = Atari(77) - 1

        ElseIf Hyo(77) = 3 Then
            Button77.Text = ""
            Hyo(77) = 0
        End If

        Shokei(20) = Atari(77) + Atari(78) + Atari(79) + Atari(80)

        Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        If Hant = 0 Then
            Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        ElseIf Hant = 1 Then
            Gokei(4) = Gokei(4) - (Shokei(18) + Shokei(19) + Shokei(20))

        ElseIf Hant = 2 Then
            Gokei(4) = Gokei(4) - (Shokei(19) + Shokei(20))
        End If

        Label4.Text = Gokei(4)
    End Sub
    Private Sub Button78_Click(sender As Object, e As EventArgs) Handles Button78.Click
        Hyo(78) = Hyo(78) + 1

        If Hyo(78) = 1 Then
            Button78.Text = "〇"
            Atari(78) = Atari(78) + 1

        ElseIf Hyo(78) = 2 Then
            Button78.Text = "×"
            Atari(78) = Atari(78) - 1

        ElseIf Hyo(78) = 3 Then
            Button78.Text = ""
            Hyo(78) = 0
        End If

        Shokei(20) = Atari(77) + Atari(78) + Atari(79) + Atari(80)

        Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        If Hant = 0 Then
            Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        ElseIf Hant = 1 Then
            Gokei(4) = Gokei(4) - (Shokei(18) + Shokei(19) + Shokei(20))

        ElseIf Hant = 2 Then
            Gokei(4) = Gokei(4) - (Shokei(19) + Shokei(20))
        End If

        Label4.Text = Gokei(4)
    End Sub
    Private Sub Button79_Click(sender As Object, e As EventArgs) Handles Button79.Click
        Hyo(79) = Hyo(79) + 1

        If Hyo(79) = 1 Then
            Button79.Text = "〇"
            Atari(79) = Atari(79) + 1

        ElseIf Hyo(79) = 2 Then
            Button79.Text = "×"
            Atari(79) = Atari(79) - 1

        ElseIf Hyo(79) = 3 Then
            Button79.Text = ""
            Hyo(79) = 0
        End If

        Shokei(20) = Atari(77) + Atari(78) + Atari(79) + Atari(80)

        Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        If Hant = 0 Then
            Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        ElseIf Hant = 1 Then
            Gokei(4) = Gokei(4) - (Shokei(18) + Shokei(19) + Shokei(20))

        ElseIf Hant = 2 Then
            Gokei(4) = Gokei(4) - (Shokei(19) + Shokei(20))
        End If

        Label4.Text = Gokei(4)
    End Sub
    Private Sub Button80_Click(sender As Object, e As EventArgs) Handles Button80.Click
        Hyo(80) = Hyo(80) + 1

        If Hyo(80) = 1 Then
            Button80.Text = "〇"
            Atari(80) = Atari(80) + 1

        ElseIf Hyo(80) = 2 Then
            Button80.Text = "×"
            Atari(80) = Atari(80) - 1

        ElseIf Hyo(80) = 3 Then
            Button80.Text = ""
            Hyo(80) = 0
        End If

        Shokei(20) = Atari(77) + Atari(78) + Atari(79) + Atari(80)

        Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        If Hant = 0 Then
            Gokei(4) = Shokei(16) + Shokei(17) + Shokei(18) + Shokei(19) + Shokei(20)

        ElseIf Hant = 1 Then
            Gokei(4) = Gokei(4) - (Shokei(18) + Shokei(19) + Shokei(20))

        ElseIf Hant = 2 Then
            Gokei(4) = Gokei(4) - (Shokei(19) + Shokei(20))
        End If

        Label4.Text = Gokei(4)
    End Sub



    Private Sub Button81_Click(sender As Object, e As EventArgs) Handles Button81.Click
        Hyo(81) = Hyo(81) + 1

        If Hyo(81) = 1 Then
            Button81.Text = "〇"
            Atari(81) = Atari(81) + 1

        ElseIf Hyo(81) = 2 Then
            Button81.Text = "×"
            Atari(81) = Atari(81) - 1

        ElseIf Hyo(81) = 3 Then
            Button81.Text = ""
            Hyo(81) = 0
        End If

        Shokei(21) = Atari(81) + Atari(82) + Atari(83) + Atari(84)

        Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        If Hant = 0 Then
            Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        ElseIf Hant = 1 Then
            Gokei(5) = Gokei(5) - (Shokei(23) + Shokei(24) + Shokei(25))

        ElseIf Hant = 2 Then
            Gokei(5) = Gokei(5) - (Shokei(24) + Shokei(25))
        End If

        Label5.Text = Gokei(5)
    End Sub
    Private Sub Button82_Click(sender As Object, e As EventArgs) Handles Button82.Click
        Hyo(82) = Hyo(82) + 1

        If Hyo(82) = 1 Then
            Button82.Text = "〇"
            Atari(82) = Atari(82) + 1

        ElseIf Hyo(82) = 2 Then
            Button82.Text = "×"
            Atari(82) = Atari(82) - 1

        ElseIf Hyo(82) = 3 Then
            Button82.Text = ""
            Hyo(82) = 0
        End If

        Shokei(21) = Atari(81) + Atari(82) + Atari(83) + Atari(84)

        Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        If Hant = 0 Then
            Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        ElseIf Hant = 1 Then
            Gokei(5) = Gokei(5) - (Shokei(23) + Shokei(24) + Shokei(25))

        ElseIf Hant = 2 Then
            Gokei(5) = Gokei(5) - (Shokei(24) + Shokei(25))
        End If

        Label5.Text = Gokei(5)
    End Sub
    Private Sub Button83_Click(sender As Object, e As EventArgs) Handles Button83.Click
        Hyo(83) = Hyo(83) + 1

        If Hyo(83) = 1 Then
            Button83.Text = "〇"
            Atari(83) = Atari(83) + 1

        ElseIf Hyo(83) = 2 Then
            Button83.Text = "×"
            Atari(83) = Atari(83) - 1

        ElseIf Hyo(83) = 3 Then
            Button83.Text = ""
            Hyo(83) = 0
        End If

        Shokei(21) = Atari(81) + Atari(82) + Atari(83) + Atari(84)

        Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        If Hant = 0 Then
            Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        ElseIf Hant = 1 Then
            Gokei(5) = Gokei(5) - (Shokei(23) + Shokei(24) + Shokei(25))

        ElseIf Hant = 2 Then
            Gokei(5) = Gokei(5) - (Shokei(24) + Shokei(25))
        End If

        Label5.Text = Gokei(5)
    End Sub
    Private Sub Button84_Click(sender As Object, e As EventArgs) Handles Button84.Click
        Hyo(84) = Hyo(84) + 1

        If Hyo(84) = 1 Then
            Button84.Text = "〇"
            Atari(84) = Atari(84) + 1

        ElseIf Hyo(84) = 2 Then
            Button84.Text = "×"
            Atari(84) = Atari(84) - 1

        ElseIf Hyo(84) = 3 Then
            Button84.Text = ""
            Hyo(84) = 0
        End If

        Shokei(21) = Atari(81) + Atari(82) + Atari(83) + Atari(84)

        Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        If Hant = 0 Then
            Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        ElseIf Hant = 1 Then
            Gokei(5) = Gokei(5) - (Shokei(23) + Shokei(24) + Shokei(25))

        ElseIf Hant = 2 Then
            Gokei(5) = Gokei(5) - (Shokei(24) + Shokei(25))
        End If

        Label5.Text = Gokei(5)
    End Sub

    Private Sub Button85_Click(sender As Object, e As EventArgs) Handles Button85.Click
        Hyo(85) = Hyo(85) + 1

        If Hyo(85) = 1 Then
            Button85.Text = "〇"
            Atari(85) = Atari(85) + 1

        ElseIf Hyo(85) = 2 Then
            Button85.Text = "×"
            Atari(85) = Atari(85) - 1

        ElseIf Hyo(85) = 3 Then
            Button85.Text = ""
            Hyo(85) = 0
        End If

        Shokei(22) = Atari(85) + Atari(86) + Atari(87) + Atari(88)

        Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        If Hant = 0 Then
            Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        ElseIf Hant = 1 Then
            Gokei(5) = Gokei(5) - (Shokei(23) + Shokei(24) + Shokei(25))

        ElseIf Hant = 2 Then
            Gokei(5) = Gokei(5) - (Shokei(24) + Shokei(25))
        End If

        Label5.Text = Gokei(5)
    End Sub
    Private Sub Button86_Click(sender As Object, e As EventArgs) Handles Button86.Click
        Hyo(86) = Hyo(86) + 1

        If Hyo(86) = 1 Then
            Button86.Text = "〇"
            Atari(86) = Atari(86) + 1

        ElseIf Hyo(86) = 2 Then
            Button86.Text = "×"
            Atari(86) = Atari(86) - 1

        ElseIf Hyo(86) = 3 Then
            Button86.Text = ""
            Hyo(86) = 0
        End If

        Shokei(22) = Atari(85) + Atari(86) + Atari(87) + Atari(88)

        Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        If Hant = 0 Then
            Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        ElseIf Hant = 1 Then
            Gokei(5) = Gokei(5) - (Shokei(23) + Shokei(24) + Shokei(25))

        ElseIf Hant = 2 Then
            Gokei(5) = Gokei(5) - (Shokei(24) + Shokei(25))
        End If

        Label5.Text = Gokei(5)
    End Sub
    Private Sub Button87_Click(sender As Object, e As EventArgs) Handles Button87.Click
        Hyo(87) = Hyo(87) + 1

        If Hyo(87) = 1 Then
            Button87.Text = "〇"
            Atari(87) = Atari(87) + 1

        ElseIf Hyo(87) = 2 Then
            Button87.Text = "×"
            Atari(87) = Atari(87) - 1

        ElseIf Hyo(87) = 3 Then
            Button87.Text = ""
            Hyo(87) = 0
        End If

        Shokei(22) = Atari(85) + Atari(86) + Atari(87) + Atari(88)

        Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        If Hant = 0 Then
            Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        ElseIf Hant = 1 Then
            Gokei(5) = Gokei(5) - (Shokei(23) + Shokei(24) + Shokei(25))

        ElseIf Hant = 2 Then
            Gokei(5) = Gokei(5) - (Shokei(24) + Shokei(25))
        End If

        Label5.Text = Gokei(5)
    End Sub
    Private Sub Button88_Click(sender As Object, e As EventArgs) Handles Button88.Click
        Hyo(88) = Hyo(88) + 1

        If Hyo(88) = 1 Then
            Button88.Text = "〇"
            Atari(88) = Atari(88) + 1

        ElseIf Hyo(88) = 2 Then
            Button88.Text = "×"
            Atari(88) = Atari(88) - 1

        ElseIf Hyo(88) = 3 Then
            Button88.Text = ""
            Hyo(88) = 0
        End If

        Shokei(22) = Atari(85) + Atari(86) + Atari(87) + Atari(88)

        Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        If Hant = 0 Then
            Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        ElseIf Hant = 1 Then
            Gokei(5) = Gokei(5) - (Shokei(23) + Shokei(24) + Shokei(25))

        ElseIf Hant = 2 Then
            Gokei(5) = Gokei(5) - (Shokei(24) + Shokei(25))
        End If

        Label5.Text = Gokei(5)
    End Sub

    Private Sub Button89_Click(sender As Object, e As EventArgs) Handles Button89.Click
        Hyo(89) = Hyo(89) + 1

        If Hyo(89) = 1 Then
            Button89.Text = "〇"
            Atari(89) = Atari(89) + 1

        ElseIf Hyo(89) = 2 Then
            Button89.Text = "×"
            Atari(89) = Atari(89) - 1

        ElseIf Hyo(89) = 3 Then
            Button89.Text = ""
            Hyo(89) = 0
        End If

        Shokei(23) = Atari(89) + Atari(90) + Atari(91) + Atari(92)

        Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        If Hant = 0 Then
            Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        ElseIf Hant = 1 Then
            Gokei(5) = Gokei(5) - (Shokei(23) + Shokei(24) + Shokei(25))

        ElseIf Hant = 2 Then
            Gokei(5) = Gokei(5) - (Shokei(24) + Shokei(25))
        End If

        Label5.Text = Gokei(5)
    End Sub
    Private Sub Button90_Click(sender As Object, e As EventArgs) Handles Button90.Click
        Hyo(90) = Hyo(90) + 1

        If Hyo(90) = 1 Then
            Button90.Text = "〇"
            Atari(90) = Atari(90) + 1

        ElseIf Hyo(90) = 2 Then
            Button90.Text = "×"
            Atari(90) = Atari(90) - 1

        ElseIf Hyo(90) = 3 Then
            Button90.Text = ""
            Hyo(90) = 0
        End If

        Shokei(23) = Atari(89) + Atari(90) + Atari(91) + Atari(92)

        Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        If Hant = 0 Then
            Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        ElseIf Hant = 1 Then
            Gokei(5) = Gokei(5) - (Shokei(23) + Shokei(24) + Shokei(25))

        ElseIf Hant = 2 Then
            Gokei(5) = Gokei(5) - (Shokei(24) + Shokei(25))
        End If

        Label5.Text = Gokei(5)
    End Sub
    Private Sub Button91_Click(sender As Object, e As EventArgs) Handles Button91.Click
        Hyo(91) = Hyo(91) + 1

        If Hyo(91) = 1 Then
            Button91.Text = "〇"
            Atari(91) = Atari(91) + 1

        ElseIf Hyo(91) = 2 Then
            Button91.Text = "×"
            Atari(91) = Atari(91) - 1

        ElseIf Hyo(91) = 3 Then
            Button91.Text = ""
            Hyo(91) = 0
        End If

        Shokei(23) = Atari(89) + Atari(90) + Atari(91) + Atari(92)

        Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        If Hant = 0 Then
            Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        ElseIf Hant = 1 Then
            Gokei(5) = Gokei(5) - (Shokei(23) + Shokei(24) + Shokei(25))

        ElseIf Hant = 2 Then
            Gokei(5) = Gokei(5) - (Shokei(24) + Shokei(25))
        End If

        Label5.Text = Gokei(5)
    End Sub
    Private Sub Button92_Click(sender As Object, e As EventArgs) Handles Button92.Click
        Hyo(92) = Hyo(92) + 1

        If Hyo(92) = 1 Then
            Button92.Text = "〇"
            Atari(92) = Atari(92) + 1

        ElseIf Hyo(92) = 2 Then
            Button92.Text = "×"
            Atari(92) = Atari(92) - 1

        ElseIf Hyo(92) = 3 Then
            Button92.Text = ""
            Hyo(92) = 0
        End If

        Shokei(23) = Atari(89) + Atari(90) + Atari(91) + Atari(92)

        Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        If Hant = 0 Then
            Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        ElseIf Hant = 1 Then
            Gokei(5) = Gokei(5) - (Shokei(23) + Shokei(24) + Shokei(25))

        ElseIf Hant = 2 Then
            Gokei(5) = Gokei(5) - (Shokei(24) + Shokei(25))
        End If

        Label5.Text = Gokei(5)
    End Sub

    Private Sub Button93_Click(sender As Object, e As EventArgs) Handles Button93.Click
        Hyo(93) = Hyo(93) + 1

        If Hyo(93) = 1 Then
            Button93.Text = "〇"
            Atari(93) = Atari(93) + 1

        ElseIf Hyo(93) = 2 Then
            Button93.Text = "×"
            Atari(93) = Atari(93) - 1

        ElseIf Hyo(93) = 3 Then
            Button93.Text = ""
            Hyo(93) = 0
        End If

        Shokei(24) = Atari(93) + Atari(94) + Atari(95) + Atari(96)

        Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        If Hant = 0 Then
            Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        ElseIf Hant = 1 Then
            Gokei(5) = Gokei(5) - (Shokei(23) + Shokei(24) + Shokei(25))

        ElseIf Hant = 2 Then
            Gokei(5) = Gokei(5) - (Shokei(24) + Shokei(25))
        End If

        Label5.Text = Gokei(5)
    End Sub
    Private Sub Button94_Click(sender As Object, e As EventArgs) Handles Button94.Click
        Hyo(94) = Hyo(94) + 1

        If Hyo(94) = 1 Then
            Button94.Text = "〇"
            Atari(94) = Atari(94) + 1

        ElseIf Hyo(94) = 2 Then
            Button94.Text = "×"
            Atari(94) = Atari(94) - 1

        ElseIf Hyo(94) = 3 Then
            Button94.Text = ""
            Hyo(94) = 0
        End If

        Shokei(24) = Atari(93) + Atari(94) + Atari(95) + Atari(96)

        Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        If Hant = 0 Then
            Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        ElseIf Hant = 1 Then
            Gokei(5) = Gokei(5) - (Shokei(23) + Shokei(24) + Shokei(25))

        ElseIf Hant = 2 Then
            Gokei(5) = Gokei(5) - (Shokei(24) + Shokei(25))
        End If

        Label5.Text = Gokei(5)
    End Sub
    Private Sub Button95_Click(sender As Object, e As EventArgs) Handles Button95.Click
        Hyo(95) = Hyo(95) + 1

        If Hyo(95) = 1 Then
            Button95.Text = "〇"
            Atari(95) = Atari(95) + 1

        ElseIf Hyo(95) = 2 Then
            Button95.Text = "×"
            Atari(95) = Atari(95) - 1

        ElseIf Hyo(95) = 3 Then
            Button95.Text = ""
            Hyo(95) = 0
        End If

        Shokei(24) = Atari(93) + Atari(94) + Atari(95) + Atari(96)

        Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        If Hant = 0 Then
            Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        ElseIf Hant = 1 Then
            Gokei(5) = Gokei(5) - (Shokei(23) + Shokei(24) + Shokei(25))

        ElseIf Hant = 2 Then
            Gokei(5) = Gokei(5) - (Shokei(24) + Shokei(25))
        End If

        Label5.Text = Gokei(5)
    End Sub
    Private Sub Button96_Click(sender As Object, e As EventArgs) Handles Button96.Click
        Hyo(96) = Hyo(96) + 1

        If Hyo(96) = 1 Then
            Button96.Text = "〇"
            Atari(96) = Atari(96) + 1

        ElseIf Hyo(96) = 2 Then
            Button96.Text = "×"
            Atari(96) = Atari(96) - 1

        ElseIf Hyo(96) = 3 Then
            Button96.Text = ""
            Hyo(96) = 0
        End If

        Shokei(24) = Atari(93) + Atari(94) + Atari(95) + Atari(96)

        Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        If Hant = 0 Then
            Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        ElseIf Hant = 1 Then
            Gokei(5) = Gokei(5) - (Shokei(23) + Shokei(24) + Shokei(25))

        ElseIf Hant = 2 Then
            Gokei(5) = Gokei(5) - (Shokei(24) + Shokei(25))
        End If

        Label5.Text = Gokei(5)
    End Sub

    Private Sub Button97_Click(sender As Object, e As EventArgs) Handles Button97.Click
        Hyo(97) = Hyo(97) + 1

        If Hyo(97) = 1 Then
            Button97.Text = "〇"
            Atari(97) = Atari(97) + 1

        ElseIf Hyo(97) = 2 Then
            Button97.Text = "×"
            Atari(97) = Atari(97) - 1

        ElseIf Hyo(97) = 3 Then
            Button97.Text = ""
            Hyo(97) = 0
        End If

        Shokei(25) = Atari(97) + Atari(98) + Atari(99) + Atari(100)

        Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        If Hant = 0 Then
            Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        ElseIf Hant = 1 Then
            Gokei(5) = Gokei(5) - (Shokei(23) + Shokei(24) + Shokei(25))

        ElseIf Hant = 2 Then
            Gokei(5) = Gokei(5) - (Shokei(24) + Shokei(25))
        End If

        Label5.Text = Gokei(5)
    End Sub
    Private Sub Button98_Click(sender As Object, e As EventArgs) Handles Button98.Click
        Hyo(98) = Hyo(98) + 1

        If Hyo(98) = 1 Then
            Button98.Text = "〇"
            Atari(98) = Atari(98) + 1

        ElseIf Hyo(98) = 2 Then
            Button98.Text = "×"
            Atari(98) = Atari(98) - 1

        ElseIf Hyo(98) = 3 Then
            Button98.Text = ""
            Hyo(98) = 0
        End If

        Shokei(25) = Atari(97) + Atari(98) + Atari(99) + Atari(100)

        Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        If Hant = 0 Then
            Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        ElseIf Hant = 1 Then
            Gokei(5) = Gokei(5) - (Shokei(23) + Shokei(24) + Shokei(25))

        ElseIf Hant = 2 Then
            Gokei(5) = Gokei(5) - (Shokei(24) + Shokei(25))
        End If

        Label5.Text = Gokei(5)
    End Sub
    Private Sub Button99_Click(sender As Object, e As EventArgs) Handles Button99.Click
        Hyo(99) = Hyo(99) + 1

        If Hyo(99) = 1 Then
            Button99.Text = "〇"
            Atari(99) = Atari(99) + 1

        ElseIf Hyo(99) = 2 Then
            Button99.Text = "×"
            Atari(99) = Atari(99) - 1

        ElseIf Hyo(99) = 3 Then
            Button99.Text = ""
            Hyo(99) = 0
        End If

        Shokei(25) = Atari(97) + Atari(98) + Atari(99) + Atari(100)

        Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        If Hant = 0 Then
            Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        ElseIf Hant = 1 Then
            Gokei(5) = Gokei(5) - (Shokei(23) + Shokei(24) + Shokei(25))

        ElseIf Hant = 2 Then
            Gokei(5) = Gokei(5) - (Shokei(24) + Shokei(25))
        End If

        Label5.Text = Gokei(5)
    End Sub
    Private Sub Button100_Click(sender As Object, e As EventArgs) Handles Button100.Click
        Hyo(100) = Hyo(100) + 1

        If Hyo(100) = 1 Then
            Button100.Text = "〇"
            Atari(100) = Atari(100) + 1

        ElseIf Hyo(100) = 2 Then
            Button100.Text = "×"
            Atari(100) = Atari(100) - 1

        ElseIf Hyo(100) = 3 Then
            Button100.Text = ""
            Hyo(100) = 0
        End If

        Shokei(25) = Atari(97) + Atari(98) + Atari(99) + Atari(100)

        Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        If Hant = 0 Then
            Gokei(5) = Shokei(21) + Shokei(22) + Shokei(23) + Shokei(24) + Shokei(25)

        ElseIf Hant = 1 Then
            Gokei(5) = Gokei(5) - (Shokei(23) + Shokei(24) + Shokei(25))

        ElseIf Hant = 2 Then
            Gokei(5) = Gokei(5) - (Shokei(24) + Shokei(25))
        End If

        Label5.Text = Gokei(5)
    End Sub



    Private Sub Button101_Click(sender As Object, e As EventArgs) Handles Button101.Click
        Hyo(101) = Hyo(101) + 1

        If Hyo(101) = 1 Then
            Button101.Text = "〇"
            Atari(101) = Atari(101) + 1

        ElseIf Hyo(101) = 2 Then
            Button101.Text = "×"
            Atari(101) = Atari(101) - 1

        ElseIf Hyo(101) = 3 Then
            Button101.Text = ""
            Hyo(101) = 0
        End If

        Shokei(26) = Atari(101) + Atari(102) + Atari(103) + Atari(104)

        Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        If Hant = 0 Then
            Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        ElseIf Hant = 1 Then
            Gokei(6) = Gokei(6) - (Shokei(28) + Shokei(29) + Shokei(30))

        ElseIf Hant = 2 Then
            Gokei(6) = Gokei(6) - (Shokei(29) + Shokei(30))
        End If

        Label6.Text = Gokei(6)
    End Sub
    Private Sub Button102_Click(sender As Object, e As EventArgs) Handles Button102.Click
        Hyo(102) = Hyo(102) + 1

        If Hyo(102) = 1 Then
            Button102.Text = "〇"
            Atari(102) = Atari(102) + 1

        ElseIf Hyo(102) = 2 Then
            Button102.Text = "×"
            Atari(102) = Atari(102) - 1

        ElseIf Hyo(102) = 3 Then
            Button102.Text = ""
            Hyo(102) = 0
        End If

        Shokei(26) = Atari(101) + Atari(102) + Atari(103) + Atari(104)

        Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        If Hant = 0 Then
            Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        ElseIf Hant = 1 Then
            Gokei(6) = Gokei(6) - (Shokei(28) + Shokei(29) + Shokei(30))

        ElseIf Hant = 2 Then
            Gokei(6) = Gokei(6) - (Shokei(29) + Shokei(30))
        End If

        Label6.Text = Gokei(6)
    End Sub
    Private Sub Button103_Click(sender As Object, e As EventArgs) Handles Button103.Click
        Hyo(103) = Hyo(103) + 1

        If Hyo(103) = 1 Then
            Button103.Text = "〇"
            Atari(103) = Atari(103) + 1

        ElseIf Hyo(103) = 2 Then
            Button103.Text = "×"
            Atari(103) = Atari(103) - 1

        ElseIf Hyo(103) = 3 Then
            Button103.Text = ""
            Hyo(103) = 0
        End If

        Shokei(26) = Atari(101) + Atari(102) + Atari(103) + Atari(104)

        Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        If Hant = 0 Then
            Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        ElseIf Hant = 1 Then
            Gokei(6) = Gokei(6) - (Shokei(28) + Shokei(29) + Shokei(30))

        ElseIf Hant = 2 Then
            Gokei(6) = Gokei(6) - (Shokei(29) + Shokei(30))
        End If

        Label6.Text = Gokei(6)
    End Sub
    Private Sub Button104_Click(sender As Object, e As EventArgs) Handles Button104.Click
        Hyo(104) = Hyo(104) + 1

        If Hyo(104) = 1 Then
            Button104.Text = "〇"
            Atari(104) = Atari(104) + 1

        ElseIf Hyo(104) = 2 Then
            Button104.Text = "×"
            Atari(104) = Atari(104) - 1

        ElseIf Hyo(104) = 3 Then
            Button104.Text = ""
            Hyo(104) = 0
        End If

        Shokei(26) = Atari(101) + Atari(102) + Atari(103) + Atari(104)

        Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        If Hant = 0 Then
            Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        ElseIf Hant = 1 Then
            Gokei(6) = Gokei(6) - (Shokei(28) + Shokei(29) + Shokei(30))

        ElseIf Hant = 2 Then
            Gokei(6) = Gokei(6) - (Shokei(29) + Shokei(30))
        End If

        Label6.Text = Gokei(6)
    End Sub

    Private Sub Button105_Click(sender As Object, e As EventArgs) Handles Button105.Click
        Hyo(105) = Hyo(105) + 1

        If Hyo(105) = 1 Then
            Button105.Text = "〇"
            Atari(105) = Atari(105) + 1

        ElseIf Hyo(105) = 2 Then
            Button105.Text = "×"
            Atari(105) = Atari(105) - 1

        ElseIf Hyo(105) = 3 Then
            Button105.Text = ""
            Hyo(105) = 0
        End If

        Shokei(27) = Atari(105) + Atari(106) + Atari(107) + Atari(108)

        Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        If Hant = 0 Then
            Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        ElseIf Hant = 1 Then
            Gokei(6) = Gokei(6) - (Shokei(28) + Shokei(29) + Shokei(30))

        ElseIf Hant = 2 Then
            Gokei(6) = Gokei(6) - (Shokei(29) + Shokei(30))
        End If

        Label6.Text = Gokei(6)
    End Sub
    Private Sub Button106_Click(sender As Object, e As EventArgs) Handles Button106.Click
        Hyo(106) = Hyo(106) + 1

        If Hyo(106) = 1 Then
            Button106.Text = "〇"
            Atari(106) = Atari(106) + 1

        ElseIf Hyo(106) = 2 Then
            Button106.Text = "×"
            Atari(106) = Atari(106) - 1

        ElseIf Hyo(106) = 3 Then
            Button106.Text = ""
            Hyo(106) = 0
        End If

        Shokei(27) = Atari(105) + Atari(106) + Atari(107) + Atari(108)

        Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        If Hant = 0 Then
            Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        ElseIf Hant = 1 Then
            Gokei(6) = Gokei(6) - (Shokei(28) + Shokei(29) + Shokei(30))

        ElseIf Hant = 2 Then
            Gokei(6) = Gokei(6) - (Shokei(29) + Shokei(30))
        End If

        Label6.Text = Gokei(6)
    End Sub
    Private Sub Button107_Click(sender As Object, e As EventArgs) Handles Button107.Click
        Hyo(107) = Hyo(107) + 1

        If Hyo(107) = 1 Then
            Button107.Text = "〇"
            Atari(107) = Atari(107) + 1

        ElseIf Hyo(107) = 2 Then
            Button107.Text = "×"
            Atari(107) = Atari(107) - 1

        ElseIf Hyo(107) = 3 Then
            Button107.Text = ""
            Hyo(107) = 0
        End If

        Shokei(27) = Atari(105) + Atari(106) + Atari(107) + Atari(108)

        Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        If Hant = 0 Then
            Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        ElseIf Hant = 1 Then
            Gokei(6) = Gokei(6) - (Shokei(28) + Shokei(29) + Shokei(30))

        ElseIf Hant = 2 Then
            Gokei(6) = Gokei(6) - (Shokei(29) + Shokei(30))
        End If

        Label6.Text = Gokei(6)
    End Sub
    Private Sub Button108_Click(sender As Object, e As EventArgs) Handles Button108.Click
        Hyo(108) = Hyo(108) + 1

        If Hyo(108) = 1 Then
            Button108.Text = "〇"
            Atari(108) = Atari(108) + 1

        ElseIf Hyo(108) = 2 Then
            Button108.Text = "×"
            Atari(108) = Atari(108) - 1

        ElseIf Hyo(108) = 3 Then
            Button108.Text = ""
            Hyo(108) = 0
        End If

        Shokei(27) = Atari(105) + Atari(106) + Atari(107) + Atari(108)

        Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        If Hant = 0 Then
            Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        ElseIf Hant = 1 Then
            Gokei(6) = Gokei(6) - (Shokei(28) + Shokei(29) + Shokei(30))

        ElseIf Hant = 2 Then
            Gokei(6) = Gokei(6) - (Shokei(29) + Shokei(30))
        End If

        Label6.Text = Gokei(6)
    End Sub

    Private Sub Button109_Click(sender As Object, e As EventArgs) Handles Button109.Click
        Hyo(109) = Hyo(109) + 1

        If Hyo(109) = 1 Then
            Button109.Text = "〇"
            Atari(109) = Atari(109) + 1

        ElseIf Hyo(109) = 2 Then
            Button109.Text = "×"
            Atari(109) = Atari(109) - 1

        ElseIf Hyo(109) = 3 Then
            Button109.Text = ""
            Hyo(109) = 0
        End If

        Shokei(28) = Atari(109) + Atari(110) + Atari(111) + Atari(112)

        Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        If Hant = 0 Then
            Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        ElseIf Hant = 1 Then
            Gokei(6) = Gokei(6) - (Shokei(28) + Shokei(29) + Shokei(30))

        ElseIf Hant = 2 Then
            Gokei(6) = Gokei(6) - (Shokei(29) + Shokei(30))
        End If

        Label6.Text = Gokei(6)
    End Sub
    Private Sub Button110_Click(sender As Object, e As EventArgs) Handles Button110.Click
        Hyo(110) = Hyo(110) + 1

        If Hyo(110) = 1 Then
            Button110.Text = "〇"
            Atari(110) = Atari(110) + 1

        ElseIf Hyo(110) = 2 Then
            Button110.Text = "×"
            Atari(110) = Atari(110) - 1

        ElseIf Hyo(110) = 3 Then
            Button110.Text = ""
            Hyo(110) = 0
        End If

        Shokei(28) = Atari(109) + Atari(110) + Atari(111) + Atari(112)

        Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        If Hant = 0 Then
            Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        ElseIf Hant = 1 Then
            Gokei(6) = Gokei(6) - (Shokei(28) + Shokei(29) + Shokei(30))

        ElseIf Hant = 2 Then
            Gokei(6) = Gokei(6) - (Shokei(29) + Shokei(30))
        End If

        Label6.Text = Gokei(6)
    End Sub
    Private Sub Button111_Click(sender As Object, e As EventArgs) Handles Button111.Click
        Hyo(111) = Hyo(111) + 1

        If Hyo(111) = 1 Then
            Button111.Text = "〇"
            Atari(111) = Atari(111) + 1

        ElseIf Hyo(111) = 2 Then
            Button111.Text = "×"
            Atari(111) = Atari(111) - 1

        ElseIf Hyo(111) = 3 Then
            Button111.Text = ""
            Hyo(111) = 0
        End If

        Shokei(28) = Atari(109) + Atari(110) + Atari(111) + Atari(112)

        Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        If Hant = 0 Then
            Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        ElseIf Hant = 1 Then
            Gokei(6) = Gokei(6) - (Shokei(28) + Shokei(29) + Shokei(30))

        ElseIf Hant = 2 Then
            Gokei(6) = Gokei(6) - (Shokei(29) + Shokei(30))
        End If

        Label6.Text = Gokei(6)
    End Sub
    Private Sub Button112_Click(sender As Object, e As EventArgs) Handles Button112.Click
        Hyo(112) = Hyo(112) + 1

        If Hyo(112) = 1 Then
            Button112.Text = "〇"
            Atari(112) = Atari(112) + 1

        ElseIf Hyo(112) = 2 Then
            Button112.Text = "×"
            Atari(112) = Atari(112) - 1

        ElseIf Hyo(112) = 3 Then
            Button112.Text = ""
            Hyo(112) = 0
        End If

        Shokei(28) = Atari(109) + Atari(110) + Atari(111) + Atari(112)

        Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        If Hant = 0 Then
            Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        ElseIf Hant = 1 Then
            Gokei(6) = Gokei(6) - (Shokei(28) + Shokei(29) + Shokei(30))

        ElseIf Hant = 2 Then
            Gokei(6) = Gokei(6) - (Shokei(29) + Shokei(30))
        End If

        Label6.Text = Gokei(6)
    End Sub

    Private Sub Button113_Click(sender As Object, e As EventArgs) Handles Button113.Click
        Hyo(113) = Hyo(113) + 1

        If Hyo(113) = 1 Then
            Button113.Text = "〇"
            Atari(113) = Atari(113) + 1

        ElseIf Hyo(113) = 2 Then
            Button113.Text = "×"
            Atari(113) = Atari(113) - 1

        ElseIf Hyo(113) = 3 Then
            Button113.Text = ""
            Hyo(113) = 0
        End If

        Shokei(29) = Atari(113) + Atari(114) + Atari(115) + Atari(116)

        Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        If Hant = 0 Then
            Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        ElseIf Hant = 1 Then
            Gokei(6) = Gokei(6) - (Shokei(28) + Shokei(29) + Shokei(30))

        ElseIf Hant = 2 Then
            Gokei(6) = Gokei(6) - (Shokei(29) + Shokei(30))
        End If

        Label6.Text = Gokei(6)
    End Sub
    Private Sub Button114_Click(sender As Object, e As EventArgs) Handles Button114.Click
        Hyo(114) = Hyo(114) + 1

        If Hyo(114) = 1 Then
            Button114.Text = "〇"
            Atari(114) = Atari(114) + 1

        ElseIf Hyo(114) = 2 Then
            Button114.Text = "×"
            Atari(114) = Atari(114) - 1

        ElseIf Hyo(114) = 3 Then
            Button114.Text = ""
            Hyo(114) = 0
        End If

        Shokei(29) = Atari(113) + Atari(114) + Atari(115) + Atari(116)

        Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        If Hant = 0 Then
            Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        ElseIf Hant = 1 Then
            Gokei(6) = Gokei(6) - (Shokei(28) + Shokei(29) + Shokei(30))

        ElseIf Hant = 2 Then
            Gokei(6) = Gokei(6) - (Shokei(29) + Shokei(30))
        End If

        Label6.Text = Gokei(6)
    End Sub
    Private Sub Button115_Click(sender As Object, e As EventArgs) Handles Button115.Click
        Hyo(115) = Hyo(115) + 1

        If Hyo(115) = 1 Then
            Button115.Text = "〇"
            Atari(115) = Atari(115) + 1

        ElseIf Hyo(115) = 2 Then
            Button115.Text = "×"
            Atari(115) = Atari(115) - 1

        ElseIf Hyo(115) = 3 Then
            Button115.Text = ""
            Hyo(115) = 0
        End If

        Shokei(29) = Atari(113) + Atari(114) + Atari(115) + Atari(116)

        Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        If Hant = 0 Then
            Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        ElseIf Hant = 1 Then
            Gokei(6) = Gokei(6) - (Shokei(28) + Shokei(29) + Shokei(30))

        ElseIf Hant = 2 Then
            Gokei(6) = Gokei(6) - (Shokei(29) + Shokei(30))
        End If

        Label6.Text = Gokei(6)
    End Sub
    Private Sub Button116_Click(sender As Object, e As EventArgs) Handles Button116.Click
        Hyo(116) = Hyo(116) + 1

        If Hyo(116) = 1 Then
            Button116.Text = "〇"
            Atari(116) = Atari(116) + 1

        ElseIf Hyo(116) = 2 Then
            Button116.Text = "×"
            Atari(116) = Atari(116) - 1

        ElseIf Hyo(116) = 3 Then
            Button116.Text = ""
            Hyo(116) = 0
        End If

        Shokei(29) = Atari(113) + Atari(114) + Atari(115) + Atari(116)

        Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        If Hant = 0 Then
            Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        ElseIf Hant = 1 Then
            Gokei(6) = Gokei(6) - (Shokei(28) + Shokei(29) + Shokei(30))

        ElseIf Hant = 2 Then
            Gokei(6) = Gokei(6) - (Shokei(29) + Shokei(30))
        End If

        Label6.Text = Gokei(6)
    End Sub

    Private Sub Button117_Click(sender As Object, e As EventArgs) Handles Button117.Click
        Hyo(117) = Hyo(117) + 1

        If Hyo(117) = 1 Then
            Button117.Text = "〇"
            Atari(117) = Atari(117) + 1

        ElseIf Hyo(117) = 2 Then
            Button117.Text = "×"
            Atari(117) = Atari(117) - 1

        ElseIf Hyo(117) = 3 Then
            Button117.Text = ""
            Hyo(117) = 0
        End If

        Shokei(30) = Atari(117) + Atari(118) + Atari(119) + Atari(120)

        Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        If Hant = 0 Then
            Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        ElseIf Hant = 1 Then
            Gokei(6) = Gokei(6) - (Shokei(28) + Shokei(29) + Shokei(30))

        ElseIf Hant = 2 Then
            Gokei(6) = Gokei(6) - (Shokei(29) + Shokei(30))
        End If

        Label6.Text = Gokei(6)
    End Sub
    Private Sub Button118_Click(sender As Object, e As EventArgs) Handles Button118.Click
        Hyo(118) = Hyo(118) + 1

        If Hyo(118) = 1 Then
            Button118.Text = "〇"
            Atari(118) = Atari(118) + 1

        ElseIf Hyo(118) = 2 Then
            Button118.Text = "×"
            Atari(118) = Atari(118) - 1

        ElseIf Hyo(118) = 3 Then
            Button118.Text = ""
            Hyo(118) = 0
        End If

        Shokei(30) = Atari(117) + Atari(118) + Atari(119) + Atari(120)

        Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        If Hant = 0 Then
            Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        ElseIf Hant = 1 Then
            Gokei(6) = Gokei(6) - (Shokei(28) + Shokei(29) + Shokei(30))

        ElseIf Hant = 2 Then
            Gokei(6) = Gokei(6) - (Shokei(29) + Shokei(30))
        End If

        Label6.Text = Gokei(6)
    End Sub
    Private Sub Button119_Click(sender As Object, e As EventArgs) Handles Button119.Click
        Hyo(119) = Hyo(119) + 1

        If Hyo(119) = 1 Then
            Button119.Text = "〇"
            Atari(119) = Atari(119) + 1

        ElseIf Hyo(119) = 2 Then
            Button119.Text = "×"
            Atari(119) = Atari(119) - 1

        ElseIf Hyo(119) = 3 Then
            Button119.Text = ""
            Hyo(119) = 0
        End If

        Shokei(30) = Atari(117) + Atari(118) + Atari(119) + Atari(120)

        Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        If Hant = 0 Then
            Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        ElseIf Hant = 1 Then
            Gokei(6) = Gokei(6) - (Shokei(28) + Shokei(29) + Shokei(30))

        ElseIf Hant = 2 Then
            Gokei(6) = Gokei(6) - (Shokei(29) + Shokei(30))
        End If

        Label6.Text = Gokei(6)
    End Sub
    Private Sub Button120_Click(sender As Object, e As EventArgs) Handles Button120.Click
        Hyo(120) = Hyo(120) + 1

        If Hyo(120) = 1 Then
            Button120.Text = "〇"
            Atari(120) = Atari(120) + 1

        ElseIf Hyo(120) = 2 Then
            Button120.Text = "×"
            Atari(120) = Atari(120) - 1

        ElseIf Hyo(120) = 3 Then
            Button120.Text = ""
            Hyo(120) = 0
        End If

        Shokei(30) = Atari(117) + Atari(118) + Atari(119) + Atari(120)

        Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        If Hant = 0 Then
            Gokei(6) = Shokei(26) + Shokei(27) + Shokei(28) + Shokei(29) + Shokei(30)

        ElseIf Hant = 1 Then
            Gokei(6) = Gokei(6) - (Shokei(28) + Shokei(29) + Shokei(30))

        ElseIf Hant = 2 Then
            Gokei(6) = Gokei(6) - (Shokei(29) + Shokei(30))
        End If

        Label6.Text = Gokei(6)
    End Sub



    Private Sub Button121_Click(sender As Object, e As EventArgs) Handles Button121.Click
        Hyo(121) = Hyo(121) + 1

        If Hyo(121) = 1 Then
            Button121.Text = "〇"
            Atari(121) = Atari(121) + 1

        ElseIf Hyo(121) = 2 Then
            Button121.Text = "×"
            Atari(121) = Atari(121) - 1

        ElseIf Hyo(121) = 3 Then
            Button121.Text = ""
            Hyo(121) = 0
        End If

        Shokei(31) = Atari(121) + Atari(122) + Atari(123) + Atari(124)

        Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        If Hant = 0 Then
            Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        ElseIf Hant = 1 Then
            Gokei(7) = Gokei(7) - (Shokei(33) + Shokei(34) + Shokei(35))

        ElseIf Hant = 2 Then
            Gokei(7) = Gokei(7) - (Shokei(34) + Shokei(35))
        End If

        Label7.Text = Gokei(7)
    End Sub
    Private Sub Button122_Click(sender As Object, e As EventArgs) Handles Button122.Click
        Hyo(122) = Hyo(122) + 1

        If Hyo(122) = 1 Then
            Button122.Text = "〇"
            Atari(122) = Atari(122) + 1

        ElseIf Hyo(122) = 2 Then
            Button122.Text = "×"
            Atari(122) = Atari(122) - 1

        ElseIf Hyo(122) = 3 Then
            Button122.Text = ""
            Hyo(122) = 0
        End If

        Shokei(31) = Atari(121) + Atari(122) + Atari(123) + Atari(124)

        Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        If Hant = 0 Then
            Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        ElseIf Hant = 1 Then
            Gokei(7) = Gokei(7) - (Shokei(33) + Shokei(34) + Shokei(35))

        ElseIf Hant = 2 Then
            Gokei(7) = Gokei(7) - (Shokei(34) + Shokei(35))
        End If

        Label7.Text = Gokei(7)
    End Sub
    Private Sub Button123_Click(sender As Object, e As EventArgs) Handles Button123.Click
        Hyo(123) = Hyo(123) + 1

        If Hyo(123) = 1 Then
            Button123.Text = "〇"
            Atari(123) = Atari(123) + 1

        ElseIf Hyo(123) = 2 Then
            Button123.Text = "×"
            Atari(123) = Atari(123) - 1

        ElseIf Hyo(123) = 3 Then
            Button123.Text = ""
            Hyo(123) = 0
        End If

        Shokei(31) = Atari(121) + Atari(122) + Atari(123) + Atari(124)

        Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        If Hant = 0 Then
            Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        ElseIf Hant = 1 Then
            Gokei(7) = Gokei(7) - (Shokei(33) + Shokei(34) + Shokei(35))

        ElseIf Hant = 2 Then
            Gokei(7) = Gokei(7) - (Shokei(34) + Shokei(35))
        End If

        Label7.Text = Gokei(7)
    End Sub
    Private Sub Button124_Click(sender As Object, e As EventArgs) Handles Button124.Click
        Hyo(124) = Hyo(124) + 1

        If Hyo(124) = 1 Then
            Button124.Text = "〇"
            Atari(124) = Atari(124) + 1

        ElseIf Hyo(124) = 2 Then
            Button124.Text = "×"
            Atari(124) = Atari(124) - 1

        ElseIf Hyo(124) = 3 Then
            Button124.Text = ""
            Hyo(124) = 0
        End If

        Shokei(31) = Atari(121) + Atari(122) + Atari(123) + Atari(124)

        Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        If Hant = 0 Then
            Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        ElseIf Hant = 1 Then
            Gokei(7) = Gokei(7) - (Shokei(33) + Shokei(34) + Shokei(35))

        ElseIf Hant = 2 Then
            Gokei(7) = Gokei(7) - (Shokei(34) + Shokei(35))
        End If

        Label7.Text = Gokei(7)
    End Sub

    Private Sub Button125_Click(sender As Object, e As EventArgs) Handles Button125.Click
        Hyo(125) = Hyo(125) + 1

        If Hyo(125) = 1 Then
            Button125.Text = "〇"
            Atari(125) = Atari(125) + 1

        ElseIf Hyo(125) = 2 Then
            Button125.Text = "×"
            Atari(125) = Atari(125) - 1

        ElseIf Hyo(125) = 3 Then
            Button125.Text = ""
            Hyo(125) = 0
        End If

        Shokei(32) = Atari(125) + Atari(126) + Atari(127) + Atari(128)

        Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        If Hant = 0 Then
            Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        ElseIf Hant = 1 Then
            Gokei(7) = Gokei(7) - (Shokei(33) + Shokei(34) + Shokei(35))

        ElseIf Hant = 2 Then
            Gokei(7) = Gokei(7) - (Shokei(34) + Shokei(35))
        End If

        Label7.Text = Gokei(7)
    End Sub
    Private Sub Button126_Click(sender As Object, e As EventArgs) Handles Button126.Click
        Hyo(126) = Hyo(126) + 1

        If Hyo(126) = 1 Then
            Button126.Text = "〇"
            Atari(126) = Atari(126) + 1

        ElseIf Hyo(126) = 2 Then
            Button126.Text = "×"
            Atari(126) = Atari(126) - 1

        ElseIf Hyo(126) = 3 Then
            Button126.Text = ""
            Hyo(126) = 0
        End If

        Shokei(32) = Atari(125) + Atari(126) + Atari(127) + Atari(128)

        Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        If Hant = 0 Then
            Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        ElseIf Hant = 1 Then
            Gokei(7) = Gokei(7) - (Shokei(33) + Shokei(34) + Shokei(35))

        ElseIf Hant = 2 Then
            Gokei(7) = Gokei(7) - (Shokei(34) + Shokei(35))
        End If

        Label7.Text = Gokei(7)
    End Sub
    Private Sub Button127_Click(sender As Object, e As EventArgs) Handles Button127.Click
        Hyo(127) = Hyo(127) + 1

        If Hyo(127) = 1 Then
            Button127.Text = "〇"
            Atari(127) = Atari(127) + 1

        ElseIf Hyo(127) = 2 Then
            Button127.Text = "×"
            Atari(127) = Atari(127) - 1

        ElseIf Hyo(127) = 3 Then
            Button127.Text = ""
            Hyo(127) = 0
        End If

        Shokei(32) = Atari(125) + Atari(126) + Atari(127) + Atari(128)

        Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        If Hant = 0 Then
            Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        ElseIf Hant = 1 Then
            Gokei(7) = Gokei(7) - (Shokei(33) + Shokei(34) + Shokei(35))

        ElseIf Hant = 2 Then
            Gokei(7) = Gokei(7) - (Shokei(34) + Shokei(35))
        End If

        Label7.Text = Gokei(7)
    End Sub
    Private Sub Button128_Click(sender As Object, e As EventArgs) Handles Button128.Click
        Hyo(128) = Hyo(128) + 1

        If Hyo(128) = 1 Then
            Button128.Text = "〇"
            Atari(128) = Atari(128) + 1

        ElseIf Hyo(128) = 2 Then
            Button128.Text = "×"
            Atari(128) = Atari(128) - 1

        ElseIf Hyo(128) = 3 Then
            Button128.Text = ""
            Hyo(128) = 0
        End If

        Shokei(32) = Atari(125) + Atari(126) + Atari(127) + Atari(128)

        Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        If Hant = 0 Then
            Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        ElseIf Hant = 1 Then
            Gokei(7) = Gokei(7) - (Shokei(33) + Shokei(34) + Shokei(35))

        ElseIf Hant = 2 Then
            Gokei(7) = Gokei(7) - (Shokei(34) + Shokei(35))
        End If

        Label7.Text = Gokei(7)
    End Sub

    Private Sub Button129_Click(sender As Object, e As EventArgs) Handles Button129.Click
        Hyo(129) = Hyo(129) + 1

        If Hyo(129) = 1 Then
            Button129.Text = "〇"
            Atari(129) = Atari(129) + 1

        ElseIf Hyo(129) = 2 Then
            Button129.Text = "×"
            Atari(129) = Atari(129) - 1

        ElseIf Hyo(129) = 3 Then
            Button129.Text = ""
            Hyo(129) = 0
        End If

        Shokei(33) = Atari(129) + Atari(130) + Atari(131) + Atari(132)

        Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        If Hant = 0 Then
            Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        ElseIf Hant = 1 Then
            Gokei(7) = Gokei(7) - (Shokei(33) + Shokei(34) + Shokei(35))

        ElseIf Hant = 2 Then
            Gokei(7) = Gokei(7) - (Shokei(34) + Shokei(35))
        End If

        Label7.Text = Gokei(7)
    End Sub
    Private Sub Button130_Click(sender As Object, e As EventArgs) Handles Button130.Click
        Hyo(130) = Hyo(130) + 1

        If Hyo(130) = 1 Then
            Button130.Text = "〇"
            Atari(130) = Atari(130) + 1

        ElseIf Hyo(130) = 2 Then
            Button130.Text = "×"
            Atari(130) = Atari(130) - 1

        ElseIf Hyo(130) = 3 Then
            Button130.Text = ""
            Hyo(130) = 0
        End If

        Shokei(33) = Atari(129) + Atari(130) + Atari(131) + Atari(132)

        Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        If Hant = 0 Then
            Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        ElseIf Hant = 1 Then
            Gokei(7) = Gokei(7) - (Shokei(33) + Shokei(34) + Shokei(35))

        ElseIf Hant = 2 Then
            Gokei(7) = Gokei(7) - (Shokei(34) + Shokei(35))
        End If

        Label7.Text = Gokei(7)
    End Sub
    Private Sub Button131_Click(sender As Object, e As EventArgs) Handles Button131.Click
        Hyo(131) = Hyo(131) + 1

        If Hyo(131) = 1 Then
            Button131.Text = "〇"
            Atari(131) = Atari(131) + 1

        ElseIf Hyo(131) = 2 Then
            Button131.Text = "×"
            Atari(131) = Atari(131) - 1

        ElseIf Hyo(131) = 3 Then
            Button131.Text = ""
            Hyo(131) = 0
        End If

        Shokei(33) = Atari(129) + Atari(130) + Atari(131) + Atari(132)

        Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        If Hant = 0 Then
            Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        ElseIf Hant = 1 Then
            Gokei(7) = Gokei(7) - (Shokei(33) + Shokei(34) + Shokei(35))

        ElseIf Hant = 2 Then
            Gokei(7) = Gokei(7) - (Shokei(34) + Shokei(35))
        End If

        Label7.Text = Gokei(7)
    End Sub
    Private Sub Button132_Click(sender As Object, e As EventArgs) Handles Button132.Click
        Hyo(132) = Hyo(132) + 1

        If Hyo(132) = 1 Then
            Button132.Text = "〇"
            Atari(132) = Atari(132) + 1

        ElseIf Hyo(132) = 2 Then
            Button132.Text = "×"
            Atari(132) = Atari(132) - 1

        ElseIf Hyo(132) = 3 Then
            Button132.Text = ""
            Hyo(132) = 0
        End If

        Shokei(33) = Atari(129) + Atari(130) + Atari(131) + Atari(132)

        Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        If Hant = 0 Then
            Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        ElseIf Hant = 1 Then
            Gokei(7) = Gokei(7) - (Shokei(33) + Shokei(34) + Shokei(35))

        ElseIf Hant = 2 Then
            Gokei(7) = Gokei(7) - (Shokei(34) + Shokei(35))
        End If

        Label7.Text = Gokei(7)
    End Sub

    Private Sub Button133_Click(sender As Object, e As EventArgs) Handles Button133.Click
        Hyo(133) = Hyo(133) + 1

        If Hyo(133) = 1 Then
            Button133.Text = "〇"
            Atari(133) = Atari(133) + 1

        ElseIf Hyo(133) = 2 Then
            Button133.Text = "×"
            Atari(133) = Atari(133) - 1

        ElseIf Hyo(133) = 3 Then
            Button133.Text = ""
            Hyo(133) = 0
        End If

        Shokei(34) = Atari(133) + Atari(134) + Atari(135) + Atari(136)

        Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        If Hant = 0 Then
            Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        ElseIf Hant = 1 Then
            Gokei(7) = Gokei(7) - (Shokei(33) + Shokei(34) + Shokei(35))

        ElseIf Hant = 2 Then
            Gokei(7) = Gokei(7) - (Shokei(34) + Shokei(35))
        End If

        Label7.Text = Gokei(7)
    End Sub
    Private Sub Button134_Click(sender As Object, e As EventArgs) Handles Button134.Click
        Hyo(134) = Hyo(134) + 1

        If Hyo(134) = 1 Then
            Button134.Text = "〇"
            Atari(134) = Atari(134) + 1

        ElseIf Hyo(134) = 2 Then
            Button134.Text = "×"
            Atari(134) = Atari(134) - 1

        ElseIf Hyo(134) = 3 Then
            Button134.Text = ""
            Hyo(134) = 0
        End If

        Shokei(34) = Atari(133) + Atari(134) + Atari(135) + Atari(136)

        Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        If Hant = 0 Then
            Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        ElseIf Hant = 1 Then
            Gokei(7) = Gokei(7) - (Shokei(33) + Shokei(34) + Shokei(35))

        ElseIf Hant = 2 Then
            Gokei(7) = Gokei(7) - (Shokei(34) + Shokei(35))
        End If

        Label7.Text = Gokei(7)
    End Sub
    Private Sub Button135_Click(sender As Object, e As EventArgs) Handles Button135.Click
        Hyo(135) = Hyo(135) + 1

        If Hyo(135) = 1 Then
            Button135.Text = "〇"
            Atari(135) = Atari(135) + 1

        ElseIf Hyo(135) = 2 Then
            Button135.Text = "×"
            Atari(135) = Atari(135) - 1

        ElseIf Hyo(135) = 3 Then
            Button135.Text = ""
            Hyo(135) = 0
        End If

        Shokei(34) = Atari(133) + Atari(134) + Atari(135) + Atari(136)

        Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        If Hant = 0 Then
            Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        ElseIf Hant = 1 Then
            Gokei(7) = Gokei(7) - (Shokei(33) + Shokei(34) + Shokei(35))

        ElseIf Hant = 2 Then
            Gokei(7) = Gokei(7) - (Shokei(34) + Shokei(35))
        End If

        Label7.Text = Gokei(7)
    End Sub
    Private Sub Button136_Click(sender As Object, e As EventArgs) Handles Button136.Click
        Hyo(136) = Hyo(136) + 1

        If Hyo(136) = 1 Then
            Button136.Text = "〇"
            Atari(136) = Atari(136) + 1

        ElseIf Hyo(136) = 2 Then
            Button136.Text = "×"
            Atari(136) = Atari(136) - 1

        ElseIf Hyo(136) = 3 Then
            Button136.Text = ""
            Hyo(136) = 0
        End If

        Shokei(34) = Atari(133) + Atari(134) + Atari(135) + Atari(136)

        Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        If Hant = 0 Then
            Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        ElseIf Hant = 1 Then
            Gokei(7) = Gokei(7) - (Shokei(33) + Shokei(34) + Shokei(35))

        ElseIf Hant = 2 Then
            Gokei(7) = Gokei(7) - (Shokei(34) + Shokei(35))
        End If

        Label7.Text = Gokei(7)
    End Sub

    Private Sub Button137_Click(sender As Object, e As EventArgs) Handles Button137.Click
        Hyo(137) = Hyo(137) + 1

        If Hyo(137) = 1 Then
            Button137.Text = "〇"
            Atari(137) = Atari(137) + 1

        ElseIf Hyo(137) = 2 Then
            Button137.Text = "×"
            Atari(137) = Atari(137) - 1

        ElseIf Hyo(137) = 3 Then
            Button137.Text = ""
            Hyo(137) = 0
        End If

        Shokei(35) = Atari(137) + Atari(138) + Atari(139) + Atari(140)

        Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        If Hant = 0 Then
            Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        ElseIf Hant = 1 Then
            Gokei(7) = Gokei(7) - (Shokei(33) + Shokei(34) + Shokei(35))

        ElseIf Hant = 2 Then
            Gokei(7) = Gokei(7) - (Shokei(34) + Shokei(35))
        End If

        Label7.Text = Gokei(7)
    End Sub
    Private Sub Button138_Click(sender As Object, e As EventArgs) Handles Button138.Click
        Hyo(138) = Hyo(138) + 1

        If Hyo(138) = 1 Then
            Button138.Text = "〇"
            Atari(138) = Atari(138) + 1

        ElseIf Hyo(138) = 2 Then
            Button138.Text = "×"
            Atari(138) = Atari(138) - 1

        ElseIf Hyo(138) = 3 Then
            Button138.Text = ""
            Hyo(138) = 0
        End If

        Shokei(35) = Atari(137) + Atari(138) + Atari(139) + Atari(140)

        Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        If Hant = 0 Then
            Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        ElseIf Hant = 1 Then
            Gokei(7) = Gokei(7) - (Shokei(33) + Shokei(34) + Shokei(35))

        ElseIf Hant = 2 Then
            Gokei(7) = Gokei(7) - (Shokei(34) + Shokei(35))
        End If

        Label7.Text = Gokei(7)
    End Sub
    Private Sub Button139_Click(sender As Object, e As EventArgs) Handles Button139.Click
        Hyo(139) = Hyo(139) + 1

        If Hyo(139) = 1 Then
            Button139.Text = "〇"
            Atari(139) = Atari(139) + 1

        ElseIf Hyo(139) = 2 Then
            Button139.Text = "×"
            Atari(139) = Atari(139) - 1

        ElseIf Hyo(139) = 3 Then
            Button139.Text = ""
            Hyo(139) = 0
        End If

        Shokei(35) = Atari(137) + Atari(138) + Atari(139) + Atari(140)

        Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        If Hant = 0 Then
            Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        ElseIf Hant = 1 Then
            Gokei(7) = Gokei(7) - (Shokei(33) + Shokei(34) + Shokei(35))

        ElseIf Hant = 2 Then
            Gokei(7) = Gokei(7) - (Shokei(34) + Shokei(35))
        End If

        Label7.Text = Gokei(7)
    End Sub
    Private Sub Button140_Click(sender As Object, e As EventArgs) Handles Button140.Click
        Hyo(140) = Hyo(140) + 1

        If Hyo(140) = 1 Then
            Button140.Text = "〇"
            Atari(140) = Atari(140) + 1

        ElseIf Hyo(140) = 2 Then
            Button140.Text = "×"
            Atari(140) = Atari(140) - 1

        ElseIf Hyo(140) = 3 Then
            Button140.Text = ""
            Hyo(140) = 0
        End If

        Shokei(35) = Atari(137) + Atari(138) + Atari(139) + Atari(140)

        Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        If Hant = 0 Then
            Gokei(7) = Shokei(31) + Shokei(32) + Shokei(33) + Shokei(34) + Shokei(35)

        ElseIf Hant = 1 Then
            Gokei(7) = Gokei(7) - (Shokei(33) + Shokei(34) + Shokei(35))

        ElseIf Hant = 2 Then
            Gokei(7) = Gokei(7) - (Shokei(34) + Shokei(35))
        End If

        Label7.Text = Gokei(7)
    End Sub



    Private Sub Button141_Click(sender As Object, e As EventArgs) Handles Button141.Click
        Hyo(141) = Hyo(141) + 1

        If Hyo(141) = 1 Then
            Button141.Text = "〇"
            Atari(141) = Atari(141) + 1

        ElseIf Hyo(141) = 2 Then
            Button141.Text = "×"
            Atari(141) = Atari(141) - 1

        ElseIf Hyo(141) = 3 Then
            Button141.Text = ""
            Hyo(141) = 0
        End If

        Shokei(36) = Atari(141) + Atari(142) + Atari(143) + Atari(144)

        Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        If Hant = 0 Then
            Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        ElseIf Hant = 1 Then
            Gokei(8) = Gokei(8) - (Shokei(38) + Shokei(39) + Shokei(40))

        ElseIf Hant = 2 Then
            Gokei(8) = Gokei(8) - (Shokei(39) + Shokei(40))
        End If

        Label8.Text = Gokei(8)
    End Sub
    Private Sub Button142_Click(sender As Object, e As EventArgs) Handles Button142.Click
        Hyo(142) = Hyo(142) + 1

        If Hyo(142) = 1 Then
            Button142.Text = "〇"
            Atari(142) = Atari(142) + 1

        ElseIf Hyo(142) = 2 Then
            Button142.Text = "×"
            Atari(142) = Atari(142) - 1

        ElseIf Hyo(142) = 3 Then
            Button142.Text = ""
            Hyo(142) = 0
        End If

        Shokei(36) = Atari(141) + Atari(142) + Atari(143) + Atari(144)

        Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        If Hant = 0 Then
            Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        ElseIf Hant = 1 Then
            Gokei(8) = Gokei(8) - (Shokei(38) + Shokei(39) + Shokei(40))

        ElseIf Hant = 2 Then
            Gokei(8) = Gokei(8) - (Shokei(39) + Shokei(40))
        End If

        Label8.Text = Gokei(8)
    End Sub
    Private Sub Button143_Click(sender As Object, e As EventArgs) Handles Button143.Click
        Hyo(143) = Hyo(143) + 1

        If Hyo(143) = 1 Then
            Button143.Text = "〇"
            Atari(143) = Atari(143) + 1

        ElseIf Hyo(143) = 2 Then
            Button143.Text = "×"
            Atari(143) = Atari(143) - 1

        ElseIf Hyo(143) = 3 Then
            Button143.Text = ""
            Hyo(143) = 0
        End If

        Shokei(36) = Atari(141) + Atari(142) + Atari(143) + Atari(144)

        Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        If Hant = 0 Then
            Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        ElseIf Hant = 1 Then
            Gokei(8) = Gokei(8) - (Shokei(38) + Shokei(39) + Shokei(40))

        ElseIf Hant = 2 Then
            Gokei(8) = Gokei(8) - (Shokei(39) + Shokei(40))
        End If

        Label8.Text = Gokei(8)
    End Sub
    Private Sub Button144_Click(sender As Object, e As EventArgs) Handles Button144.Click
        Hyo(144) = Hyo(144) + 1

        If Hyo(144) = 1 Then
            Button144.Text = "〇"
            Atari(144) = Atari(144) + 1

        ElseIf Hyo(144) = 2 Then
            Button144.Text = "×"
            Atari(144) = Atari(144) - 1

        ElseIf Hyo(144) = 3 Then
            Button144.Text = ""
            Hyo(144) = 0
        End If

        Shokei(36) = Atari(141) + Atari(142) + Atari(143) + Atari(144)

        Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        If Hant = 0 Then
            Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        ElseIf Hant = 1 Then
            Gokei(8) = Gokei(8) - (Shokei(38) + Shokei(39) + Shokei(40))

        ElseIf Hant = 2 Then
            Gokei(8) = Gokei(8) - (Shokei(39) + Shokei(40))
        End If

        Label8.Text = Gokei(8)
    End Sub

    Private Sub Button145_Click(sender As Object, e As EventArgs) Handles Button145.Click
        Hyo(145) = Hyo(145) + 1

        If Hyo(145) = 1 Then
            Button145.Text = "〇"
            Atari(145) = Atari(145) + 1

        ElseIf Hyo(145) = 2 Then
            Button145.Text = "×"
            Atari(145) = Atari(145) - 1

        ElseIf Hyo(145) = 3 Then
            Button145.Text = ""
            Hyo(145) = 0
        End If

        Shokei(37) = Atari(145) + Atari(146) + Atari(147) + Atari(148)

        Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        If Hant = 0 Then
            Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        ElseIf Hant = 1 Then
            Gokei(8) = Gokei(8) - (Shokei(38) + Shokei(39) + Shokei(40))

        ElseIf Hant = 2 Then
            Gokei(8) = Gokei(8) - (Shokei(39) + Shokei(40))
        End If

        Label8.Text = Gokei(8)
    End Sub
    Private Sub Button146_Click(sender As Object, e As EventArgs) Handles Button146.Click
        Hyo(146) = Hyo(146) + 1

        If Hyo(146) = 1 Then
            Button146.Text = "〇"
            Atari(146) = Atari(146) + 1

        ElseIf Hyo(146) = 2 Then
            Button146.Text = "×"
            Atari(146) = Atari(146) - 1

        ElseIf Hyo(146) = 3 Then
            Button146.Text = ""
            Hyo(146) = 0
        End If

        Shokei(37) = Atari(145) + Atari(146) + Atari(147) + Atari(148)

        Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        If Hant = 0 Then
            Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        ElseIf Hant = 1 Then
            Gokei(8) = Gokei(8) - (Shokei(38) + Shokei(39) + Shokei(40))

        ElseIf Hant = 2 Then
            Gokei(8) = Gokei(8) - (Shokei(39) + Shokei(40))
        End If

        Label8.Text = Gokei(8)
    End Sub
    Private Sub Button147_Click(sender As Object, e As EventArgs) Handles Button147.Click
        Hyo(147) = Hyo(147) + 1

        If Hyo(147) = 1 Then
            Button147.Text = "〇"
            Atari(147) = Atari(147) + 1

        ElseIf Hyo(147) = 2 Then
            Button147.Text = "×"
            Atari(147) = Atari(147) - 1

        ElseIf Hyo(147) = 3 Then
            Button147.Text = ""
            Hyo(147) = 0
        End If

        Shokei(37) = Atari(145) + Atari(146) + Atari(147) + Atari(148)

        Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        If Hant = 0 Then
            Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        ElseIf Hant = 1 Then
            Gokei(8) = Gokei(8) - (Shokei(38) + Shokei(39) + Shokei(40))

        ElseIf Hant = 2 Then
            Gokei(8) = Gokei(8) - (Shokei(39) + Shokei(40))
        End If

        Label8.Text = Gokei(8)
    End Sub
    Private Sub Button148_Click(sender As Object, e As EventArgs) Handles Button148.Click
        Hyo(148) = Hyo(148) + 1

        If Hyo(148) = 1 Then
            Button148.Text = "〇"
            Atari(148) = Atari(148) + 1

        ElseIf Hyo(148) = 2 Then
            Button148.Text = "×"
            Atari(148) = Atari(148) - 1

        ElseIf Hyo(148) = 3 Then
            Button148.Text = ""
            Hyo(148) = 0
        End If

        Shokei(37) = Atari(145) + Atari(146) + Atari(147) + Atari(148)

        Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        If Hant = 0 Then
            Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        ElseIf Hant = 1 Then
            Gokei(8) = Gokei(8) - (Shokei(38) + Shokei(39) + Shokei(40))

        ElseIf Hant = 2 Then
            Gokei(8) = Gokei(8) - (Shokei(39) + Shokei(40))
        End If

        Label8.Text = Gokei(8)
    End Sub

    Private Sub Button149_Click(sender As Object, e As EventArgs) Handles Button149.Click
        Hyo(149) = Hyo(149) + 1

        If Hyo(149) = 1 Then
            Button149.Text = "〇"
            Atari(149) = Atari(149) + 1

        ElseIf Hyo(149) = 2 Then
            Button149.Text = "×"
            Atari(149) = Atari(149) - 1

        ElseIf Hyo(149) = 3 Then
            Button149.Text = ""
            Hyo(149) = 0
        End If

        Shokei(38) = Atari(149) + Atari(150) + Atari(151) + Atari(152)

        Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        If Hant = 0 Then
            Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        ElseIf Hant = 1 Then
            Gokei(8) = Gokei(8) - (Shokei(38) + Shokei(39) + Shokei(40))

        ElseIf Hant = 2 Then
            Gokei(8) = Gokei(8) - (Shokei(39) + Shokei(40))
        End If

        Label8.Text = Gokei(8)
    End Sub
    Private Sub Button150_Click(sender As Object, e As EventArgs) Handles Button150.Click
        Hyo(150) = Hyo(150) + 1

        If Hyo(150) = 1 Then
            Button150.Text = "〇"
            Atari(150) = Atari(150) + 1

        ElseIf Hyo(150) = 2 Then
            Button150.Text = "×"
            Atari(150) = Atari(150) - 1

        ElseIf Hyo(150) = 3 Then
            Button150.Text = ""
            Hyo(150) = 0
        End If

        Shokei(38) = Atari(149) + Atari(150) + Atari(151) + Atari(152)

        Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        If Hant = 0 Then
            Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        ElseIf Hant = 1 Then
            Gokei(8) = Gokei(8) - (Shokei(38) + Shokei(39) + Shokei(40))

        ElseIf Hant = 2 Then
            Gokei(8) = Gokei(8) - (Shokei(39) + Shokei(40))
        End If

        Label8.Text = Gokei(8)
    End Sub
    Private Sub Button151_Click(sender As Object, e As EventArgs) Handles Button151.Click
        Hyo(151) = Hyo(151) + 1

        If Hyo(151) = 1 Then
            Button151.Text = "〇"
            Atari(151) = Atari(151) + 1

        ElseIf Hyo(151) = 2 Then
            Button151.Text = "×"
            Atari(151) = Atari(151) - 1

        ElseIf Hyo(151) = 3 Then
            Button151.Text = ""
            Hyo(151) = 0
        End If

        Shokei(38) = Atari(149) + Atari(150) + Atari(151) + Atari(152)

        Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        If Hant = 0 Then
            Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        ElseIf Hant = 1 Then
            Gokei(8) = Gokei(8) - (Shokei(38) + Shokei(39) + Shokei(40))

        ElseIf Hant = 2 Then
            Gokei(8) = Gokei(8) - (Shokei(39) + Shokei(40))
        End If

        Label8.Text = Gokei(8)
    End Sub
    Private Sub Button152_Click(sender As Object, e As EventArgs) Handles Button152.Click
        Hyo(152) = Hyo(152) + 1

        If Hyo(152) = 1 Then
            Button152.Text = "〇"
            Atari(152) = Atari(152) + 1

        ElseIf Hyo(152) = 2 Then
            Button152.Text = "×"
            Atari(152) = Atari(152) - 1

        ElseIf Hyo(152) = 3 Then
            Button152.Text = ""
            Hyo(152) = 0
        End If

        Shokei(38) = Atari(149) + Atari(150) + Atari(151) + Atari(152)

        Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        If Hant = 0 Then
            Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        ElseIf Hant = 1 Then
            Gokei(8) = Gokei(8) - (Shokei(38) + Shokei(39) + Shokei(40))

        ElseIf Hant = 2 Then
            Gokei(8) = Gokei(8) - (Shokei(39) + Shokei(40))
        End If

        Label8.Text = Gokei(8)
    End Sub

    Private Sub Button153_Click(sender As Object, e As EventArgs) Handles Button153.Click
        Hyo(153) = Hyo(153) + 1

        If Hyo(153) = 1 Then
            Button153.Text = "〇"
            Atari(153) = Atari(153) + 1

        ElseIf Hyo(153) = 2 Then
            Button153.Text = "×"
            Atari(153) = Atari(153) - 1

        ElseIf Hyo(153) = 3 Then
            Button153.Text = ""
            Hyo(153) = 0
        End If

        Shokei(39) = Atari(153) + Atari(154) + Atari(155) + Atari(156)

        Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        If Hant = 0 Then
            Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        ElseIf Hant = 1 Then
            Gokei(8) = Gokei(8) - (Shokei(38) + Shokei(39) + Shokei(40))

        ElseIf Hant = 2 Then
            Gokei(8) = Gokei(8) - (Shokei(39) + Shokei(40))
        End If

        Label8.Text = Gokei(8)
    End Sub
    Private Sub Button154_Click(sender As Object, e As EventArgs) Handles Button154.Click
        Hyo(154) = Hyo(154) + 1

        If Hyo(154) = 1 Then
            Button154.Text = "〇"
            Atari(154) = Atari(154) + 1

        ElseIf Hyo(154) = 2 Then
            Button154.Text = "×"
            Atari(154) = Atari(154) - 1

        ElseIf Hyo(154) = 3 Then
            Button154.Text = ""
            Hyo(154) = 0
        End If

        Shokei(39) = Atari(153) + Atari(154) + Atari(155) + Atari(156)

        Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        If Hant = 0 Then
            Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        ElseIf Hant = 1 Then
            Gokei(8) = Gokei(8) - (Shokei(38) + Shokei(39) + Shokei(40))

        ElseIf Hant = 2 Then
            Gokei(8) = Gokei(8) - (Shokei(39) + Shokei(40))
        End If

        Label8.Text = Gokei(8)
    End Sub
    Private Sub Button155_Click(sender As Object, e As EventArgs) Handles Button155.Click
        Hyo(155) = Hyo(155) + 1

        If Hyo(155) = 1 Then
            Button155.Text = "〇"
            Atari(155) = Atari(155) + 1

        ElseIf Hyo(155) = 2 Then
            Button155.Text = "×"
            Atari(155) = Atari(155) - 1

        ElseIf Hyo(155) = 3 Then
            Button155.Text = ""
            Hyo(155) = 0
        End If

        Shokei(39) = Atari(153) + Atari(154) + Atari(155) + Atari(156)

        Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        If Hant = 0 Then
            Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        ElseIf Hant = 1 Then
            Gokei(8) = Gokei(8) - (Shokei(38) + Shokei(39) + Shokei(40))

        ElseIf Hant = 2 Then
            Gokei(8) = Gokei(8) - (Shokei(39) + Shokei(40))
        End If

        Label8.Text = Gokei(8)
    End Sub
    Private Sub Button156_Click(sender As Object, e As EventArgs) Handles Button156.Click
        Hyo(156) = Hyo(156) + 1

        If Hyo(156) = 1 Then
            Button156.Text = "〇"
            Atari(156) = Atari(156) + 1

        ElseIf Hyo(156) = 2 Then
            Button156.Text = "×"
            Atari(156) = Atari(156) - 1

        ElseIf Hyo(156) = 3 Then
            Button156.Text = ""
            Hyo(156) = 0
        End If

        Shokei(39) = Atari(153) + Atari(154) + Atari(155) + Atari(156)

        Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        If Hant = 0 Then
            Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        ElseIf Hant = 1 Then
            Gokei(8) = Gokei(8) - (Shokei(38) + Shokei(39) + Shokei(40))

        ElseIf Hant = 2 Then
            Gokei(8) = Gokei(8) - (Shokei(39) + Shokei(40))
        End If

        Label8.Text = Gokei(8)
    End Sub

    Private Sub Button157_Click(sender As Object, e As EventArgs) Handles Button157.Click
        Hyo(157) = Hyo(157) + 1

        If Hyo(157) = 1 Then
            Button157.Text = "〇"
            Atari(157) = Atari(157) + 1

        ElseIf Hyo(157) = 2 Then
            Button157.Text = "×"
            Atari(157) = Atari(157) - 1

        ElseIf Hyo(157) = 3 Then
            Button157.Text = ""
            Hyo(157) = 0
        End If

        Shokei(40) = Atari(157) + Atari(158) + Atari(159) + Atari(160)

        Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        If Hant = 0 Then
            Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        ElseIf Hant = 1 Then
            Gokei(8) = Gokei(8) - (Shokei(38) + Shokei(39) + Shokei(40))

        ElseIf Hant = 2 Then
            Gokei(8) = Gokei(8) - (Shokei(39) + Shokei(40))
        End If

        Label8.Text = Gokei(8)
    End Sub
    Private Sub Button158_Click(sender As Object, e As EventArgs) Handles Button158.Click
        Hyo(158) = Hyo(158) + 1

        If Hyo(158) = 1 Then
            Button158.Text = "〇"
            Atari(158) = Atari(158) + 1

        ElseIf Hyo(158) = 2 Then
            Button158.Text = "×"
            Atari(158) = Atari(158) - 1

        ElseIf Hyo(158) = 3 Then
            Button158.Text = ""
            Hyo(158) = 0
        End If

        Shokei(40) = Atari(157) + Atari(158) + Atari(159) + Atari(160)

        Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        If Hant = 0 Then
            Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        ElseIf Hant = 1 Then
            Gokei(8) = Gokei(8) - (Shokei(38) + Shokei(39) + Shokei(40))

        ElseIf Hant = 2 Then
            Gokei(8) = Gokei(8) - (Shokei(39) + Shokei(40))
        End If

        Label8.Text = Gokei(8)
    End Sub
    Private Sub Button159_Click(sender As Object, e As EventArgs) Handles Button159.Click
        Hyo(159) = Hyo(159) + 1

        If Hyo(159) = 1 Then
            Button159.Text = "〇"
            Atari(159) = Atari(159) + 1

        ElseIf Hyo(159) = 2 Then
            Button159.Text = "×"
            Atari(159) = Atari(159) - 1

        ElseIf Hyo(159) = 3 Then
            Button159.Text = ""
            Hyo(159) = 0
        End If

        Shokei(40) = Atari(157) + Atari(158) + Atari(159) + Atari(160)

        Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        If Hant = 0 Then
            Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        ElseIf Hant = 1 Then
            Gokei(8) = Gokei(8) - (Shokei(38) + Shokei(39) + Shokei(40))

        ElseIf Hant = 2 Then
            Gokei(8) = Gokei(8) - (Shokei(39) + Shokei(40))
        End If

        Label8.Text = Gokei(8)
    End Sub
    Private Sub Button160_Click(sender As Object, e As EventArgs) Handles Button160.Click
        Hyo(160) = Hyo(160) + 1

        If Hyo(160) = 1 Then
            Button160.Text = "〇"
            Atari(160) = Atari(160) + 1

        ElseIf Hyo(160) = 2 Then
            Button160.Text = "×"
            Atari(160) = Atari(160) - 1

        ElseIf Hyo(160) = 3 Then
            Button160.Text = ""
            Hyo(160) = 0
        End If

        Shokei(40) = Atari(157) + Atari(158) + Atari(159) + Atari(160)

        Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        If Hant = 0 Then
            Gokei(8) = Shokei(36) + Shokei(37) + Shokei(38) + Shokei(39) + Shokei(40)

        ElseIf Hant = 1 Then
            Gokei(8) = Gokei(8) - (Shokei(38) + Shokei(39) + Shokei(40))

        ElseIf Hant = 2 Then
            Gokei(8) = Gokei(8) - (Shokei(39) + Shokei(40))
        End If

        Label8.Text = Gokei(8)
    End Sub



    Private Sub Button161_Click(sender As Object, e As EventArgs) Handles Button161.Click
        Hyo(161) = Hyo(161) + 1

        If Hyo(161) = 1 Then
            Button161.Text = "〇"
            Atari(161) = Atari(161) + 1

        ElseIf Hyo(161) = 2 Then
            Button161.Text = "×"
            Atari(161) = Atari(161) - 1

        ElseIf Hyo(161) = 3 Then
            Button161.Text = ""
            Hyo(161) = 0
        End If

        Shokei(41) = Atari(161) + Atari(162) + Atari(163) + Atari(164)

        Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        If Hant = 0 Then
            Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        ElseIf Hant = 1 Then
            Gokei(9) = Gokei(9) - (Shokei(43) + Shokei(44) + Shokei(45))

        ElseIf Hant = 2 Then
            Gokei(9) = Gokei(9) - (Shokei(44) + Shokei(45))
        End If

        Label9.Text = Gokei(9)
    End Sub
    Private Sub Button162_Click(sender As Object, e As EventArgs) Handles Button162.Click
        Hyo(162) = Hyo(162) + 1

        If Hyo(162) = 1 Then
            Button162.Text = "〇"
            Atari(162) = Atari(162) + 1

        ElseIf Hyo(162) = 2 Then
            Button162.Text = "×"
            Atari(162) = Atari(162) - 1

        ElseIf Hyo(162) = 3 Then
            Button162.Text = ""
            Hyo(162) = 0
        End If

        Shokei(41) = Atari(161) + Atari(162) + Atari(163) + Atari(164)

        Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        If Hant = 0 Then
            Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        ElseIf Hant = 1 Then
            Gokei(9) = Gokei(9) - (Shokei(43) + Shokei(44) + Shokei(45))

        ElseIf Hant = 2 Then
            Gokei(9) = Gokei(9) - (Shokei(44) + Shokei(45))
        End If

        Label9.Text = Gokei(9)
    End Sub
    Private Sub Button163_Click(sender As Object, e As EventArgs) Handles Button163.Click
        Hyo(163) = Hyo(163) + 1

        If Hyo(163) = 1 Then
            Button163.Text = "〇"
            Atari(163) = Atari(163) + 1

        ElseIf Hyo(163) = 2 Then
            Button163.Text = "×"
            Atari(163) = Atari(163) - 1

        ElseIf Hyo(163) = 3 Then
            Button163.Text = ""
            Hyo(163) = 0
        End If

        Shokei(41) = Atari(161) + Atari(162) + Atari(163) + Atari(164)

        Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        If Hant = 0 Then
            Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        ElseIf Hant = 1 Then
            Gokei(9) = Gokei(9) - (Shokei(43) + Shokei(44) + Shokei(45))

        ElseIf Hant = 2 Then
            Gokei(9) = Gokei(9) - (Shokei(44) + Shokei(45))
        End If

        Label9.Text = Gokei(9)
    End Sub
    Private Sub Button164_Click(sender As Object, e As EventArgs) Handles Button164.Click
        Hyo(164) = Hyo(164) + 1

        If Hyo(164) = 1 Then
            Button164.Text = "〇"
            Atari(164) = Atari(164) + 1

        ElseIf Hyo(164) = 2 Then
            Button164.Text = "×"
            Atari(164) = Atari(164) - 1

        ElseIf Hyo(164) = 3 Then
            Button164.Text = ""
            Hyo(164) = 0
        End If

        Shokei(41) = Atari(161) + Atari(162) + Atari(163) + Atari(164)

        Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        If Hant = 0 Then
            Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        ElseIf Hant = 1 Then
            Gokei(9) = Gokei(9) - (Shokei(43) + Shokei(44) + Shokei(45))

        ElseIf Hant = 2 Then
            Gokei(9) = Gokei(9) - (Shokei(44) + Shokei(45))
        End If

        Label9.Text = Gokei(9)
    End Sub

    Private Sub Button165_Click(sender As Object, e As EventArgs) Handles Button165.Click
        Hyo(165) = Hyo(165) + 1

        If Hyo(165) = 1 Then
            Button165.Text = "〇"
            Atari(165) = Atari(165) + 1

        ElseIf Hyo(165) = 2 Then
            Button165.Text = "×"
            Atari(165) = Atari(165) - 1

        ElseIf Hyo(165) = 3 Then
            Button165.Text = ""
            Hyo(165) = 0
        End If

        Shokei(42) = Atari(165) + Atari(166) + Atari(167) + Atari(168)

        Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        If Hant = 0 Then
            Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        ElseIf Hant = 1 Then
            Gokei(9) = Gokei(9) - (Shokei(43) + Shokei(44) + Shokei(45))

        ElseIf Hant = 2 Then
            Gokei(9) = Gokei(9) - (Shokei(44) + Shokei(45))
        End If

        Label9.Text = Gokei(9)
    End Sub



    Private Sub Button166_Click(sender As Object, e As EventArgs) Handles Button166.Click
        Hyo(166) = Hyo(166) + 1

        If Hyo(166) = 1 Then
            Button166.Text = "〇"
            Atari(166) = Atari(166) + 1

        ElseIf Hyo(166) = 2 Then
            Button166.Text = "×"
            Atari(166) = Atari(166) - 1

        ElseIf Hyo(166) = 3 Then
            Button166.Text = ""
            Hyo(166) = 0
        End If

        Shokei(42) = Atari(165) + Atari(166) + Atari(167) + Atari(168)

        Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        If Hant = 0 Then
            Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        ElseIf Hant = 1 Then
            Gokei(9) = Gokei(9) - (Shokei(43) + Shokei(44) + Shokei(45))

        ElseIf Hant = 2 Then
            Gokei(9) = Gokei(9) - (Shokei(44) + Shokei(45))
        End If

        Label9.Text = Gokei(9)
    End Sub
    Private Sub Button167_Click(sender As Object, e As EventArgs) Handles Button167.Click
        Hyo(167) = Hyo(167) + 1

        If Hyo(167) = 1 Then
            Button167.Text = "〇"
            Atari(167) = Atari(167) + 1

        ElseIf Hyo(167) = 2 Then
            Button167.Text = "×"
            Atari(167) = Atari(167) - 1

        ElseIf Hyo(167) = 3 Then
            Button167.Text = ""
            Hyo(167) = 0
        End If

        Shokei(42) = Atari(165) + Atari(166) + Atari(167) + Atari(168)

        Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        If Hant = 0 Then
            Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        ElseIf Hant = 1 Then
            Gokei(9) = Gokei(9) - (Shokei(43) + Shokei(44) + Shokei(45))

        ElseIf Hant = 2 Then
            Gokei(9) = Gokei(9) - (Shokei(44) + Shokei(45))
        End If

        Label9.Text = Gokei(9)
    End Sub
    Private Sub Button168_Click(sender As Object, e As EventArgs) Handles Button168.Click
        Hyo(168) = Hyo(168) + 1

        If Hyo(168) = 1 Then
            Button168.Text = "〇"
            Atari(168) = Atari(168) + 1

        ElseIf Hyo(168) = 2 Then
            Button168.Text = "×"
            Atari(168) = Atari(168) - 1

        ElseIf Hyo(168) = 3 Then
            Button168.Text = ""
            Hyo(168) = 0
        End If

        Shokei(42) = Atari(165) + Atari(166) + Atari(167) + Atari(168)

        Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        If Hant = 0 Then
            Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        ElseIf Hant = 1 Then
            Gokei(9) = Gokei(9) - (Shokei(43) + Shokei(44) + Shokei(45))

        ElseIf Hant = 2 Then
            Gokei(9) = Gokei(9) - (Shokei(44) + Shokei(45))
        End If

        Label9.Text = Gokei(9)
    End Sub



    Private Sub Button169_Click(sender As Object, e As EventArgs) Handles Button169.Click
        Hyo(169) = Hyo(169) + 1

        If Hyo(169) = 1 Then
            Button169.Text = "〇"
            Atari(169) = Atari(169) + 1

        ElseIf Hyo(169) = 2 Then
            Button169.Text = "×"
            Atari(169) = Atari(169) - 1

        ElseIf Hyo(169) = 3 Then
            Button169.Text = ""
            Hyo(169) = 0
        End If

        Shokei(43) = Atari(169) + Atari(170) + Atari(171) + Atari(172)

        Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        If Hant = 0 Then
            Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        ElseIf Hant = 1 Then
            Gokei(9) = Gokei(9) - (Shokei(43) + Shokei(44) + Shokei(45))

        ElseIf Hant = 2 Then
            Gokei(9) = Gokei(9) - (Shokei(44) + Shokei(45))
        End If

        Label9.Text = Gokei(9)
    End Sub



    Private Sub Button170_Click(sender As Object, e As EventArgs) Handles Button170.Click
        Hyo(170) = Hyo(170) + 1

        If Hyo(170) = 1 Then
            Button170.Text = "〇"
            Atari(170) = Atari(170) + 1

        ElseIf Hyo(170) = 2 Then
            Button170.Text = "×"
            Atari(170) = Atari(170) - 1

        ElseIf Hyo(170) = 3 Then
            Button170.Text = ""
            Hyo(170) = 0
        End If

        Shokei(43) = Atari(169) + Atari(170) + Atari(171) + Atari(172)

        Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        If Hant = 0 Then
            Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        ElseIf Hant = 1 Then
            Gokei(9) = Gokei(9) - (Shokei(43) + Shokei(44) + Shokei(45))

        ElseIf Hant = 2 Then
            Gokei(9) = Gokei(9) - (Shokei(44) + Shokei(45))
        End If

        Label9.Text = Gokei(9)
    End Sub



    Private Sub Button171_Click(sender As Object, e As EventArgs) Handles Button171.Click
        Hyo(171) = Hyo(171) + 1

        If Hyo(171) = 1 Then
            Button171.Text = "〇"
            Atari(171) = Atari(171) + 1

        ElseIf Hyo(171) = 2 Then
            Button171.Text = "×"
            Atari(171) = Atari(171) - 1

        ElseIf Hyo(171) = 3 Then
            Button171.Text = ""
            Hyo(171) = 0
        End If

        Shokei(43) = Atari(169) + Atari(170) + Atari(171) + Atari(172)

        Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        If Hant = 0 Then
            Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        ElseIf Hant = 1 Then
            Gokei(9) = Gokei(9) - (Shokei(43) + Shokei(44) + Shokei(45))

        ElseIf Hant = 2 Then
            Gokei(9) = Gokei(9) - (Shokei(44) + Shokei(45))
        End If

        Label9.Text = Gokei(9)
    End Sub
    Private Sub Button172_Click(sender As Object, e As EventArgs) Handles Button172.Click
        Hyo(172) = Hyo(172) + 1

        If Hyo(172) = 1 Then
            Button172.Text = "〇"
            Atari(172) = Atari(172) + 1

        ElseIf Hyo(172) = 2 Then
            Button172.Text = "×"
            Atari(172) = Atari(172) - 1

        ElseIf Hyo(172) = 3 Then
            Button172.Text = ""
            Hyo(172) = 0
        End If

        Shokei(43) = Atari(169) + Atari(170) + Atari(171) + Atari(172)

        Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        If Hant = 0 Then
            Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        ElseIf Hant = 1 Then
            Gokei(9) = Gokei(9) - (Shokei(43) + Shokei(44) + Shokei(45))

        ElseIf Hant = 2 Then
            Gokei(9) = Gokei(9) - (Shokei(44) + Shokei(45))
        End If

        Label9.Text = Gokei(9)
    End Sub

    Private Sub Button173_Click(sender As Object, e As EventArgs) Handles Button173.Click
        Hyo(173) = Hyo(173) + 1

        If Hyo(173) = 1 Then
            Button173.Text = "〇"
            Atari(173) = Atari(173) + 1

        ElseIf Hyo(173) = 2 Then
            Button173.Text = "×"
            Atari(173) = Atari(173) - 1

        ElseIf Hyo(173) = 3 Then
            Button173.Text = ""
            Hyo(173) = 0
        End If

        Shokei(44) = Atari(173) + Atari(174) + Atari(175) + Atari(176)

        Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        If Hant = 0 Then
            Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        ElseIf Hant = 1 Then
            Gokei(9) = Gokei(9) - (Shokei(43) + Shokei(44) + Shokei(45))

        ElseIf Hant = 2 Then
            Gokei(9) = Gokei(9) - (Shokei(44) + Shokei(45))
        End If

        Label9.Text = Gokei(9)
    End Sub
    Private Sub Button174_Click(sender As Object, e As EventArgs) Handles Button174.Click
        Hyo(174) = Hyo(174) + 1

        If Hyo(174) = 1 Then
            Button174.Text = "〇"
            Atari(174) = Atari(174) + 1

        ElseIf Hyo(174) = 2 Then
            Button174.Text = "×"
            Atari(174) = Atari(174) - 1

        ElseIf Hyo(174) = 3 Then
            Button174.Text = ""
            Hyo(174) = 0
        End If

        Shokei(44) = Atari(173) + Atari(174) + Atari(175) + Atari(176)

        Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        If Hant = 0 Then
            Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        ElseIf Hant = 1 Then
            Gokei(9) = Gokei(9) - (Shokei(43) + Shokei(44) + Shokei(45))

        ElseIf Hant = 2 Then
            Gokei(9) = Gokei(9) - (Shokei(44) + Shokei(45))
        End If

        Label9.Text = Gokei(9)
    End Sub
    Private Sub Button175_Click(sender As Object, e As EventArgs) Handles Button175.Click
        Hyo(175) = Hyo(175) + 1

        If Hyo(175) = 1 Then
            Button175.Text = "〇"
            Atari(175) = Atari(175) + 1

        ElseIf Hyo(175) = 2 Then
            Button175.Text = "×"
            Atari(175) = Atari(175) - 1

        ElseIf Hyo(175) = 3 Then
            Button175.Text = ""
            Hyo(175) = 0
        End If

        Shokei(44) = Atari(173) + Atari(174) + Atari(175) + Atari(176)

        Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        If Hant = 0 Then
            Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        ElseIf Hant = 1 Then
            Gokei(9) = Gokei(9) - (Shokei(43) + Shokei(44) + Shokei(45))

        ElseIf Hant = 2 Then
            Gokei(9) = Gokei(9) - (Shokei(44) + Shokei(45))
        End If

        Label9.Text = Gokei(9)
    End Sub
    Private Sub Button176_Click(sender As Object, e As EventArgs) Handles Button176.Click
        Hyo(176) = Hyo(176) + 1

        If Hyo(176) = 1 Then
            Button176.Text = "〇"
            Atari(176) = Atari(176) + 1

        ElseIf Hyo(176) = 2 Then
            Button176.Text = "×"
            Atari(176) = Atari(176) - 1

        ElseIf Hyo(176) = 3 Then
            Button176.Text = ""
            Hyo(176) = 0
        End If

        Shokei(44) = Atari(173) + Atari(174) + Atari(175) + Atari(176)

        Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        If Hant = 0 Then
            Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        ElseIf Hant = 1 Then
            Gokei(9) = Gokei(9) - (Shokei(43) + Shokei(44) + Shokei(45))

        ElseIf Hant = 2 Then
            Gokei(9) = Gokei(9) - (Shokei(44) + Shokei(45))
        End If

        Label9.Text = Gokei(9)
    End Sub

    Private Sub Button177_Click(sender As Object, e As EventArgs) Handles Button177.Click
        Hyo(177) = Hyo(177) + 1

        If Hyo(177) = 1 Then
            Button177.Text = "〇"
            Atari(177) = Atari(177) + 1

        ElseIf Hyo(177) = 2 Then
            Button177.Text = "×"
            Atari(177) = Atari(177) - 1

        ElseIf Hyo(177) = 3 Then
            Button177.Text = ""
            Hyo(177) = 0
        End If

        Shokei(45) = Atari(177) + Atari(178) + Atari(179) + Atari(180)

        Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        If Hant = 0 Then
            Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        ElseIf Hant = 1 Then
            Gokei(9) = Gokei(9) - (Shokei(43) + Shokei(44) + Shokei(45))

        ElseIf Hant = 2 Then
            Gokei(9) = Gokei(9) - (Shokei(44) + Shokei(45))
        End If

        Label9.Text = Gokei(9)
    End Sub
    Private Sub Button178_Click(sender As Object, e As EventArgs) Handles Button178.Click
        Hyo(178) = Hyo(178) + 1

        If Hyo(178) = 1 Then
            Button178.Text = "〇"
            Atari(178) = Atari(178) + 1

        ElseIf Hyo(178) = 2 Then
            Button178.Text = "×"
            Atari(178) = Atari(178) - 1

        ElseIf Hyo(178) = 3 Then
            Button178.Text = ""
            Hyo(178) = 0
        End If

        Shokei(45) = Atari(177) + Atari(178) + Atari(179) + Atari(180)

        Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        If Hant = 0 Then
            Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        ElseIf Hant = 1 Then
            Gokei(9) = Gokei(9) - (Shokei(43) + Shokei(44) + Shokei(45))

        ElseIf Hant = 2 Then
            Gokei(9) = Gokei(9) - (Shokei(44) + Shokei(45))
        End If

        Label9.Text = Gokei(9)
    End Sub
    Private Sub Button179_Click(sender As Object, e As EventArgs) Handles Button179.Click
        Hyo(179) = Hyo(179) + 1

        If Hyo(179) = 1 Then
            Button179.Text = "〇"
            Atari(179) = Atari(179) + 1

        ElseIf Hyo(179) = 2 Then
            Button179.Text = "×"
            Atari(179) = Atari(179) - 1

        ElseIf Hyo(179) = 3 Then
            Button179.Text = ""
            Hyo(179) = 0
        End If

        Shokei(45) = Atari(177) + Atari(178) + Atari(179) + Atari(180)

        Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        If Hant = 0 Then
            Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        ElseIf Hant = 1 Then
            Gokei(9) = Gokei(9) - (Shokei(43) + Shokei(44) + Shokei(45))

        ElseIf Hant = 2 Then
            Gokei(9) = Gokei(9) - (Shokei(44) + Shokei(45))
        End If

        Label9.Text = Gokei(9)
    End Sub
    Private Sub Button180_Click(sender As Object, e As EventArgs) Handles Button180.Click
        Hyo(180) = Hyo(180) + 1

        If Hyo(180) = 1 Then
            Button180.Text = "〇"
            Atari(180) = Atari(180) + 1

        ElseIf Hyo(180) = 2 Then
            Button180.Text = "×"
            Atari(180) = Atari(180) - 1

        ElseIf Hyo(180) = 3 Then
            Button180.Text = ""
            Hyo(180) = 0
        End If

        Shokei(45) = Atari(177) + Atari(178) + Atari(179) + Atari(180)

        Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        If Hant = 0 Then
            Gokei(9) = Shokei(41) + Shokei(42) + Shokei(43) + Shokei(44) + Shokei(45)

        ElseIf Hant = 1 Then
            Gokei(9) = Gokei(9) - (Shokei(43) + Shokei(44) + Shokei(45))

        ElseIf Hant = 2 Then
            Gokei(9) = Gokei(9) - (Shokei(44) + Shokei(45))
        End If

        Label9.Text = Gokei(9)
    End Sub


End Class