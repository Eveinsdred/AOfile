﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form6
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form6))
        Me.Atri_Clear = New System.Windows.Forms.Button()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.Save = New System.Windows.Forms.Button()
        Me.Syuryo = New System.Windows.Forms.Button()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Sort_Reverse = New System.Windows.Forms.Button()
        Me.Gokei_2 = New System.Windows.Forms.Button()
        Me.Goke_3 = New System.Windows.Forms.Button()
        Me.Gokei_All = New System.Windows.Forms.Button()
        Me.Back = New System.Windows.Forms.Button()
        Me.Button181 = New System.Windows.Forms.Button()
        Me.Button182 = New System.Windows.Forms.Button()
        Me.Button183 = New System.Windows.Forms.Button()
        Me.Button184 = New System.Windows.Forms.Button()
        Me.Button185 = New System.Windows.Forms.Button()
        Me.Button186 = New System.Windows.Forms.Button()
        Me.Button187 = New System.Windows.Forms.Button()
        Me.Button188 = New System.Windows.Forms.Button()
        Me.Button189 = New System.Windows.Forms.Button()
        Me.Button190 = New System.Windows.Forms.Button()
        Me.Button191 = New System.Windows.Forms.Button()
        Me.Button192 = New System.Windows.Forms.Button()
        Me.Button193 = New System.Windows.Forms.Button()
        Me.Button194 = New System.Windows.Forms.Button()
        Me.Button195 = New System.Windows.Forms.Button()
        Me.Button196 = New System.Windows.Forms.Button()
        Me.Button197 = New System.Windows.Forms.Button()
        Me.Button198 = New System.Windows.Forms.Button()
        Me.Button199 = New System.Windows.Forms.Button()
        Me.Button200 = New System.Windows.Forms.Button()
        Me.Button161 = New System.Windows.Forms.Button()
        Me.Button162 = New System.Windows.Forms.Button()
        Me.Button163 = New System.Windows.Forms.Button()
        Me.Button164 = New System.Windows.Forms.Button()
        Me.Button165 = New System.Windows.Forms.Button()
        Me.Button166 = New System.Windows.Forms.Button()
        Me.Button167 = New System.Windows.Forms.Button()
        Me.Button168 = New System.Windows.Forms.Button()
        Me.Button169 = New System.Windows.Forms.Button()
        Me.Button170 = New System.Windows.Forms.Button()
        Me.Button171 = New System.Windows.Forms.Button()
        Me.Button172 = New System.Windows.Forms.Button()
        Me.Button173 = New System.Windows.Forms.Button()
        Me.Button174 = New System.Windows.Forms.Button()
        Me.Button175 = New System.Windows.Forms.Button()
        Me.Button176 = New System.Windows.Forms.Button()
        Me.Button177 = New System.Windows.Forms.Button()
        Me.Button178 = New System.Windows.Forms.Button()
        Me.Button179 = New System.Windows.Forms.Button()
        Me.Button180 = New System.Windows.Forms.Button()
        Me.Button141 = New System.Windows.Forms.Button()
        Me.Button142 = New System.Windows.Forms.Button()
        Me.Button143 = New System.Windows.Forms.Button()
        Me.Button144 = New System.Windows.Forms.Button()
        Me.Button145 = New System.Windows.Forms.Button()
        Me.Button146 = New System.Windows.Forms.Button()
        Me.Button147 = New System.Windows.Forms.Button()
        Me.Button148 = New System.Windows.Forms.Button()
        Me.Button149 = New System.Windows.Forms.Button()
        Me.Button150 = New System.Windows.Forms.Button()
        Me.Button151 = New System.Windows.Forms.Button()
        Me.Button152 = New System.Windows.Forms.Button()
        Me.Button153 = New System.Windows.Forms.Button()
        Me.Button154 = New System.Windows.Forms.Button()
        Me.Button155 = New System.Windows.Forms.Button()
        Me.Button156 = New System.Windows.Forms.Button()
        Me.Button157 = New System.Windows.Forms.Button()
        Me.Button158 = New System.Windows.Forms.Button()
        Me.Button159 = New System.Windows.Forms.Button()
        Me.Button160 = New System.Windows.Forms.Button()
        Me.Button121 = New System.Windows.Forms.Button()
        Me.Button122 = New System.Windows.Forms.Button()
        Me.Button123 = New System.Windows.Forms.Button()
        Me.Button124 = New System.Windows.Forms.Button()
        Me.Button125 = New System.Windows.Forms.Button()
        Me.Button126 = New System.Windows.Forms.Button()
        Me.Button127 = New System.Windows.Forms.Button()
        Me.Button128 = New System.Windows.Forms.Button()
        Me.Button129 = New System.Windows.Forms.Button()
        Me.Button130 = New System.Windows.Forms.Button()
        Me.Button131 = New System.Windows.Forms.Button()
        Me.Button132 = New System.Windows.Forms.Button()
        Me.Button133 = New System.Windows.Forms.Button()
        Me.Button134 = New System.Windows.Forms.Button()
        Me.Button135 = New System.Windows.Forms.Button()
        Me.Button136 = New System.Windows.Forms.Button()
        Me.Button137 = New System.Windows.Forms.Button()
        Me.Button138 = New System.Windows.Forms.Button()
        Me.Button139 = New System.Windows.Forms.Button()
        Me.Button140 = New System.Windows.Forms.Button()
        Me.Button101 = New System.Windows.Forms.Button()
        Me.Button102 = New System.Windows.Forms.Button()
        Me.Button103 = New System.Windows.Forms.Button()
        Me.Button104 = New System.Windows.Forms.Button()
        Me.Button105 = New System.Windows.Forms.Button()
        Me.Button106 = New System.Windows.Forms.Button()
        Me.Button107 = New System.Windows.Forms.Button()
        Me.Button108 = New System.Windows.Forms.Button()
        Me.Button109 = New System.Windows.Forms.Button()
        Me.Button110 = New System.Windows.Forms.Button()
        Me.Button111 = New System.Windows.Forms.Button()
        Me.Button112 = New System.Windows.Forms.Button()
        Me.Button113 = New System.Windows.Forms.Button()
        Me.Button114 = New System.Windows.Forms.Button()
        Me.Button115 = New System.Windows.Forms.Button()
        Me.Button116 = New System.Windows.Forms.Button()
        Me.Button117 = New System.Windows.Forms.Button()
        Me.Button118 = New System.Windows.Forms.Button()
        Me.Button119 = New System.Windows.Forms.Button()
        Me.Button120 = New System.Windows.Forms.Button()
        Me.Button81 = New System.Windows.Forms.Button()
        Me.Button82 = New System.Windows.Forms.Button()
        Me.Button83 = New System.Windows.Forms.Button()
        Me.Button84 = New System.Windows.Forms.Button()
        Me.Button85 = New System.Windows.Forms.Button()
        Me.Button86 = New System.Windows.Forms.Button()
        Me.Button87 = New System.Windows.Forms.Button()
        Me.Button88 = New System.Windows.Forms.Button()
        Me.Button89 = New System.Windows.Forms.Button()
        Me.Button90 = New System.Windows.Forms.Button()
        Me.Button91 = New System.Windows.Forms.Button()
        Me.Button92 = New System.Windows.Forms.Button()
        Me.Button93 = New System.Windows.Forms.Button()
        Me.Button94 = New System.Windows.Forms.Button()
        Me.Button95 = New System.Windows.Forms.Button()
        Me.Button96 = New System.Windows.Forms.Button()
        Me.Button97 = New System.Windows.Forms.Button()
        Me.Button98 = New System.Windows.Forms.Button()
        Me.Button99 = New System.Windows.Forms.Button()
        Me.Button100 = New System.Windows.Forms.Button()
        Me.Button61 = New System.Windows.Forms.Button()
        Me.Button62 = New System.Windows.Forms.Button()
        Me.Button63 = New System.Windows.Forms.Button()
        Me.Button64 = New System.Windows.Forms.Button()
        Me.Button65 = New System.Windows.Forms.Button()
        Me.Button66 = New System.Windows.Forms.Button()
        Me.Button67 = New System.Windows.Forms.Button()
        Me.Button68 = New System.Windows.Forms.Button()
        Me.Button69 = New System.Windows.Forms.Button()
        Me.Button70 = New System.Windows.Forms.Button()
        Me.Button71 = New System.Windows.Forms.Button()
        Me.Button72 = New System.Windows.Forms.Button()
        Me.Button73 = New System.Windows.Forms.Button()
        Me.Button74 = New System.Windows.Forms.Button()
        Me.Button75 = New System.Windows.Forms.Button()
        Me.Button76 = New System.Windows.Forms.Button()
        Me.Button77 = New System.Windows.Forms.Button()
        Me.Button78 = New System.Windows.Forms.Button()
        Me.Button79 = New System.Windows.Forms.Button()
        Me.Button80 = New System.Windows.Forms.Button()
        Me.Button41 = New System.Windows.Forms.Button()
        Me.Button42 = New System.Windows.Forms.Button()
        Me.Button43 = New System.Windows.Forms.Button()
        Me.Button44 = New System.Windows.Forms.Button()
        Me.Button45 = New System.Windows.Forms.Button()
        Me.Button46 = New System.Windows.Forms.Button()
        Me.Button47 = New System.Windows.Forms.Button()
        Me.Button48 = New System.Windows.Forms.Button()
        Me.Button49 = New System.Windows.Forms.Button()
        Me.Button50 = New System.Windows.Forms.Button()
        Me.Button51 = New System.Windows.Forms.Button()
        Me.Button52 = New System.Windows.Forms.Button()
        Me.Button53 = New System.Windows.Forms.Button()
        Me.Button54 = New System.Windows.Forms.Button()
        Me.Button55 = New System.Windows.Forms.Button()
        Me.Button56 = New System.Windows.Forms.Button()
        Me.Button57 = New System.Windows.Forms.Button()
        Me.Button58 = New System.Windows.Forms.Button()
        Me.Button59 = New System.Windows.Forms.Button()
        Me.Button60 = New System.Windows.Forms.Button()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.Button24 = New System.Windows.Forms.Button()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.Button26 = New System.Windows.Forms.Button()
        Me.Button27 = New System.Windows.Forms.Button()
        Me.Button28 = New System.Windows.Forms.Button()
        Me.Button29 = New System.Windows.Forms.Button()
        Me.Button30 = New System.Windows.Forms.Button()
        Me.Button31 = New System.Windows.Forms.Button()
        Me.Button32 = New System.Windows.Forms.Button()
        Me.Button33 = New System.Windows.Forms.Button()
        Me.Button34 = New System.Windows.Forms.Button()
        Me.Button35 = New System.Windows.Forms.Button()
        Me.Button36 = New System.Windows.Forms.Button()
        Me.Button37 = New System.Windows.Forms.Button()
        Me.Button38 = New System.Windows.Forms.Button()
        Me.Button39 = New System.Windows.Forms.Button()
        Me.Button40 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Tekityu6 = New System.Windows.Forms.Label()
        Me.Tekityu7 = New System.Windows.Forms.Label()
        Me.Tekityu8 = New System.Windows.Forms.Label()
        Me.Tekityu9 = New System.Windows.Forms.Label()
        Me.Tekityu10 = New System.Windows.Forms.Label()
        Me.Tekityu5 = New System.Windows.Forms.Label()
        Me.Tekityu4 = New System.Windows.Forms.Label()
        Me.Tekityu3 = New System.Windows.Forms.Label()
        Me.Tekityu2 = New System.Windows.Forms.Label()
        Me.Tekityu1 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.DataHiraku = New System.Windows.Forms.Button()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.TClear = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Atri_Clear
        '
        Me.Atri_Clear.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Atri_Clear.Location = New System.Drawing.Point(920, 16)
        Me.Atri_Clear.Name = "Atri_Clear"
        Me.Atri_Clear.Size = New System.Drawing.Size(80, 32)
        Me.Atri_Clear.TabIndex = 1024
        Me.Atri_Clear.Text = "All Clear"
        Me.Atri_Clear.UseVisualStyleBackColor = True
        '
        'TextBox10
        '
        Me.TextBox10.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.TextBox10.Location = New System.Drawing.Point(24, 504)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(88, 22)
        Me.TextBox10.TabIndex = 999
        '
        'TextBox9
        '
        Me.TextBox9.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.TextBox9.Location = New System.Drawing.Point(24, 464)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(88, 22)
        Me.TextBox9.TabIndex = 998
        '
        'TextBox8
        '
        Me.TextBox8.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.TextBox8.Location = New System.Drawing.Point(24, 424)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(88, 22)
        Me.TextBox8.TabIndex = 997
        '
        'TextBox7
        '
        Me.TextBox7.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.TextBox7.Location = New System.Drawing.Point(24, 384)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(88, 22)
        Me.TextBox7.TabIndex = 996
        '
        'TextBox6
        '
        Me.TextBox6.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.TextBox6.Location = New System.Drawing.Point(24, 344)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(88, 22)
        Me.TextBox6.TabIndex = 995
        '
        'TextBox5
        '
        Me.TextBox5.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.TextBox5.Location = New System.Drawing.Point(24, 296)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(88, 22)
        Me.TextBox5.TabIndex = 994
        '
        'TextBox4
        '
        Me.TextBox4.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.TextBox4.Location = New System.Drawing.Point(24, 256)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(88, 22)
        Me.TextBox4.TabIndex = 993
        '
        'TextBox3
        '
        Me.TextBox3.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.TextBox3.Location = New System.Drawing.Point(24, 216)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(88, 22)
        Me.TextBox3.TabIndex = 992
        '
        'TextBox2
        '
        Me.TextBox2.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.TextBox2.Location = New System.Drawing.Point(24, 176)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(88, 22)
        Me.TextBox2.TabIndex = 991
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(24, 136)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(88, 22)
        Me.TextBox1.TabIndex = 990
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(16, 64)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(160, 19)
        Me.DateTimePicker1.TabIndex = 988
        '
        'Save
        '
        Me.Save.BackColor = System.Drawing.Color.LightSkyBlue
        Me.Save.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Save.Location = New System.Drawing.Point(336, 56)
        Me.Save.Name = "Save"
        Me.Save.Size = New System.Drawing.Size(56, 32)
        Me.Save.TabIndex = 987
        Me.Save.Text = "保存"
        Me.Save.UseVisualStyleBackColor = False
        '
        'Syuryo
        '
        Me.Syuryo.BackColor = System.Drawing.Color.OrangeRed
        Me.Syuryo.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Syuryo.ForeColor = System.Drawing.Color.Black
        Me.Syuryo.Location = New System.Drawing.Point(1136, 16)
        Me.Syuryo.Name = "Syuryo"
        Me.Syuryo.Size = New System.Drawing.Size(56, 32)
        Me.Syuryo.TabIndex = 986
        Me.Syuryo.Text = "終了"
        Me.Syuryo.UseVisualStyleBackColor = False
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("ＭＳ 明朝", 27.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(16, 8)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(134, 37)
        Me.Label16.TabIndex = 985
        Me.Label16.Text = "個人表"
        '
        'Sort_Reverse
        '
        Me.Sort_Reverse.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Sort_Reverse.Location = New System.Drawing.Point(440, 32)
        Me.Sort_Reverse.Name = "Sort_Reverse"
        Me.Sort_Reverse.Size = New System.Drawing.Size(88, 32)
        Me.Sort_Reverse.TabIndex = 984
        Me.Sort_Reverse.Text = "的中順"
        Me.Sort_Reverse.UseVisualStyleBackColor = True
        '
        'Gokei_2
        '
        Me.Gokei_2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Gokei_2.Location = New System.Drawing.Point(568, 32)
        Me.Gokei_2.Name = "Gokei_2"
        Me.Gokei_2.Size = New System.Drawing.Size(80, 32)
        Me.Gokei_2.TabIndex = 983
        Me.Gokei_2.Text = "２立合計"
        Me.Gokei_2.UseVisualStyleBackColor = True
        '
        'Goke_3
        '
        Me.Goke_3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Goke_3.Location = New System.Drawing.Point(672, 32)
        Me.Goke_3.Name = "Goke_3"
        Me.Goke_3.Size = New System.Drawing.Size(80, 32)
        Me.Goke_3.TabIndex = 982
        Me.Goke_3.Text = "３立合計"
        Me.Goke_3.UseVisualStyleBackColor = True
        '
        'Gokei_All
        '
        Me.Gokei_All.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Gokei_All.Location = New System.Drawing.Point(776, 32)
        Me.Gokei_All.Name = "Gokei_All"
        Me.Gokei_All.Size = New System.Drawing.Size(80, 32)
        Me.Gokei_All.TabIndex = 981
        Me.Gokei_All.Text = "全立合計"
        Me.Gokei_All.UseVisualStyleBackColor = True
        '
        'Back
        '
        Me.Back.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Back.Location = New System.Drawing.Point(1136, 56)
        Me.Back.Name = "Back"
        Me.Back.Size = New System.Drawing.Size(56, 32)
        Me.Back.TabIndex = 980
        Me.Back.Text = "戻る"
        Me.Back.UseVisualStyleBackColor = True
        '
        'Button181
        '
        Me.Button181.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button181.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button181.Location = New System.Drawing.Point(224, 504)
        Me.Button181.Margin = New System.Windows.Forms.Padding(4)
        Me.Button181.Name = "Button181"
        Me.Button181.Size = New System.Drawing.Size(40, 24)
        Me.Button181.TabIndex = 979
        Me.Button181.UseVisualStyleBackColor = False
        '
        'Button182
        '
        Me.Button182.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button182.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button182.Location = New System.Drawing.Point(272, 504)
        Me.Button182.Margin = New System.Windows.Forms.Padding(4)
        Me.Button182.Name = "Button182"
        Me.Button182.Size = New System.Drawing.Size(40, 24)
        Me.Button182.TabIndex = 978
        Me.Button182.UseVisualStyleBackColor = False
        '
        'Button183
        '
        Me.Button183.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button183.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button183.Location = New System.Drawing.Point(320, 504)
        Me.Button183.Margin = New System.Windows.Forms.Padding(4)
        Me.Button183.Name = "Button183"
        Me.Button183.Size = New System.Drawing.Size(40, 24)
        Me.Button183.TabIndex = 977
        Me.Button183.UseVisualStyleBackColor = False
        '
        'Button184
        '
        Me.Button184.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button184.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button184.Location = New System.Drawing.Point(368, 504)
        Me.Button184.Margin = New System.Windows.Forms.Padding(4)
        Me.Button184.Name = "Button184"
        Me.Button184.Size = New System.Drawing.Size(40, 24)
        Me.Button184.TabIndex = 976
        Me.Button184.UseVisualStyleBackColor = False
        '
        'Button185
        '
        Me.Button185.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button185.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button185.Location = New System.Drawing.Point(432, 504)
        Me.Button185.Margin = New System.Windows.Forms.Padding(4)
        Me.Button185.Name = "Button185"
        Me.Button185.Size = New System.Drawing.Size(40, 24)
        Me.Button185.TabIndex = 975
        Me.Button185.UseVisualStyleBackColor = False
        '
        'Button186
        '
        Me.Button186.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button186.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button186.Location = New System.Drawing.Point(480, 504)
        Me.Button186.Margin = New System.Windows.Forms.Padding(4)
        Me.Button186.Name = "Button186"
        Me.Button186.Size = New System.Drawing.Size(40, 24)
        Me.Button186.TabIndex = 974
        Me.Button186.UseVisualStyleBackColor = False
        '
        'Button187
        '
        Me.Button187.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button187.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button187.Location = New System.Drawing.Point(528, 504)
        Me.Button187.Margin = New System.Windows.Forms.Padding(4)
        Me.Button187.Name = "Button187"
        Me.Button187.Size = New System.Drawing.Size(40, 24)
        Me.Button187.TabIndex = 973
        Me.Button187.UseVisualStyleBackColor = False
        '
        'Button188
        '
        Me.Button188.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button188.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button188.Location = New System.Drawing.Point(576, 504)
        Me.Button188.Margin = New System.Windows.Forms.Padding(4)
        Me.Button188.Name = "Button188"
        Me.Button188.Size = New System.Drawing.Size(40, 24)
        Me.Button188.TabIndex = 972
        Me.Button188.UseVisualStyleBackColor = False
        '
        'Button189
        '
        Me.Button189.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button189.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button189.Location = New System.Drawing.Point(648, 504)
        Me.Button189.Margin = New System.Windows.Forms.Padding(4)
        Me.Button189.Name = "Button189"
        Me.Button189.Size = New System.Drawing.Size(40, 24)
        Me.Button189.TabIndex = 971
        Me.Button189.UseVisualStyleBackColor = False
        '
        'Button190
        '
        Me.Button190.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button190.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button190.Location = New System.Drawing.Point(696, 504)
        Me.Button190.Margin = New System.Windows.Forms.Padding(4)
        Me.Button190.Name = "Button190"
        Me.Button190.Size = New System.Drawing.Size(40, 24)
        Me.Button190.TabIndex = 970
        Me.Button190.UseVisualStyleBackColor = False
        '
        'Button191
        '
        Me.Button191.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button191.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button191.Location = New System.Drawing.Point(744, 504)
        Me.Button191.Margin = New System.Windows.Forms.Padding(4)
        Me.Button191.Name = "Button191"
        Me.Button191.Size = New System.Drawing.Size(40, 24)
        Me.Button191.TabIndex = 969
        Me.Button191.UseVisualStyleBackColor = False
        '
        'Button192
        '
        Me.Button192.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button192.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button192.Location = New System.Drawing.Point(792, 504)
        Me.Button192.Margin = New System.Windows.Forms.Padding(4)
        Me.Button192.Name = "Button192"
        Me.Button192.Size = New System.Drawing.Size(40, 24)
        Me.Button192.TabIndex = 968
        Me.Button192.UseVisualStyleBackColor = False
        '
        'Button193
        '
        Me.Button193.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button193.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button193.Location = New System.Drawing.Point(864, 504)
        Me.Button193.Margin = New System.Windows.Forms.Padding(4)
        Me.Button193.Name = "Button193"
        Me.Button193.Size = New System.Drawing.Size(40, 24)
        Me.Button193.TabIndex = 967
        Me.Button193.UseVisualStyleBackColor = False
        '
        'Button194
        '
        Me.Button194.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button194.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button194.Location = New System.Drawing.Point(912, 504)
        Me.Button194.Margin = New System.Windows.Forms.Padding(4)
        Me.Button194.Name = "Button194"
        Me.Button194.Size = New System.Drawing.Size(40, 24)
        Me.Button194.TabIndex = 966
        Me.Button194.UseVisualStyleBackColor = False
        '
        'Button195
        '
        Me.Button195.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button195.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button195.Location = New System.Drawing.Point(960, 504)
        Me.Button195.Margin = New System.Windows.Forms.Padding(4)
        Me.Button195.Name = "Button195"
        Me.Button195.Size = New System.Drawing.Size(40, 24)
        Me.Button195.TabIndex = 965
        Me.Button195.UseVisualStyleBackColor = False
        '
        'Button196
        '
        Me.Button196.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button196.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button196.Location = New System.Drawing.Point(1008, 504)
        Me.Button196.Margin = New System.Windows.Forms.Padding(4)
        Me.Button196.Name = "Button196"
        Me.Button196.Size = New System.Drawing.Size(40, 24)
        Me.Button196.TabIndex = 964
        Me.Button196.UseVisualStyleBackColor = False
        '
        'Button197
        '
        Me.Button197.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button197.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button197.Location = New System.Drawing.Point(1072, 504)
        Me.Button197.Margin = New System.Windows.Forms.Padding(4)
        Me.Button197.Name = "Button197"
        Me.Button197.Size = New System.Drawing.Size(40, 24)
        Me.Button197.TabIndex = 963
        Me.Button197.UseVisualStyleBackColor = False
        '
        'Button198
        '
        Me.Button198.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button198.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button198.Location = New System.Drawing.Point(1120, 504)
        Me.Button198.Margin = New System.Windows.Forms.Padding(4)
        Me.Button198.Name = "Button198"
        Me.Button198.Size = New System.Drawing.Size(40, 24)
        Me.Button198.TabIndex = 962
        Me.Button198.UseVisualStyleBackColor = False
        '
        'Button199
        '
        Me.Button199.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button199.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button199.Location = New System.Drawing.Point(1168, 504)
        Me.Button199.Margin = New System.Windows.Forms.Padding(4)
        Me.Button199.Name = "Button199"
        Me.Button199.Size = New System.Drawing.Size(40, 24)
        Me.Button199.TabIndex = 961
        Me.Button199.UseVisualStyleBackColor = False
        '
        'Button200
        '
        Me.Button200.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button200.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button200.Location = New System.Drawing.Point(1216, 504)
        Me.Button200.Margin = New System.Windows.Forms.Padding(4)
        Me.Button200.Name = "Button200"
        Me.Button200.Size = New System.Drawing.Size(40, 24)
        Me.Button200.TabIndex = 960
        Me.Button200.UseVisualStyleBackColor = False
        '
        'Button161
        '
        Me.Button161.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button161.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button161.Location = New System.Drawing.Point(224, 464)
        Me.Button161.Margin = New System.Windows.Forms.Padding(4)
        Me.Button161.Name = "Button161"
        Me.Button161.Size = New System.Drawing.Size(40, 24)
        Me.Button161.TabIndex = 959
        Me.Button161.UseVisualStyleBackColor = False
        '
        'Button162
        '
        Me.Button162.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button162.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button162.Location = New System.Drawing.Point(272, 464)
        Me.Button162.Margin = New System.Windows.Forms.Padding(4)
        Me.Button162.Name = "Button162"
        Me.Button162.Size = New System.Drawing.Size(40, 24)
        Me.Button162.TabIndex = 958
        Me.Button162.UseVisualStyleBackColor = False
        '
        'Button163
        '
        Me.Button163.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button163.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button163.Location = New System.Drawing.Point(320, 464)
        Me.Button163.Margin = New System.Windows.Forms.Padding(4)
        Me.Button163.Name = "Button163"
        Me.Button163.Size = New System.Drawing.Size(40, 24)
        Me.Button163.TabIndex = 957
        Me.Button163.UseVisualStyleBackColor = False
        '
        'Button164
        '
        Me.Button164.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button164.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button164.Location = New System.Drawing.Point(368, 464)
        Me.Button164.Margin = New System.Windows.Forms.Padding(4)
        Me.Button164.Name = "Button164"
        Me.Button164.Size = New System.Drawing.Size(40, 24)
        Me.Button164.TabIndex = 956
        Me.Button164.UseVisualStyleBackColor = False
        '
        'Button165
        '
        Me.Button165.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button165.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button165.Location = New System.Drawing.Point(432, 464)
        Me.Button165.Margin = New System.Windows.Forms.Padding(4)
        Me.Button165.Name = "Button165"
        Me.Button165.Size = New System.Drawing.Size(40, 24)
        Me.Button165.TabIndex = 955
        Me.Button165.UseVisualStyleBackColor = False
        '
        'Button166
        '
        Me.Button166.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button166.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button166.Location = New System.Drawing.Point(480, 464)
        Me.Button166.Margin = New System.Windows.Forms.Padding(4)
        Me.Button166.Name = "Button166"
        Me.Button166.Size = New System.Drawing.Size(40, 24)
        Me.Button166.TabIndex = 954
        Me.Button166.UseVisualStyleBackColor = False
        '
        'Button167
        '
        Me.Button167.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button167.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button167.Location = New System.Drawing.Point(528, 464)
        Me.Button167.Margin = New System.Windows.Forms.Padding(4)
        Me.Button167.Name = "Button167"
        Me.Button167.Size = New System.Drawing.Size(40, 24)
        Me.Button167.TabIndex = 953
        Me.Button167.UseVisualStyleBackColor = False
        '
        'Button168
        '
        Me.Button168.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button168.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button168.Location = New System.Drawing.Point(576, 464)
        Me.Button168.Margin = New System.Windows.Forms.Padding(4)
        Me.Button168.Name = "Button168"
        Me.Button168.Size = New System.Drawing.Size(40, 24)
        Me.Button168.TabIndex = 952
        Me.Button168.UseVisualStyleBackColor = False
        '
        'Button169
        '
        Me.Button169.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button169.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button169.Location = New System.Drawing.Point(648, 464)
        Me.Button169.Margin = New System.Windows.Forms.Padding(4)
        Me.Button169.Name = "Button169"
        Me.Button169.Size = New System.Drawing.Size(40, 24)
        Me.Button169.TabIndex = 951
        Me.Button169.UseVisualStyleBackColor = False
        '
        'Button170
        '
        Me.Button170.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button170.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button170.Location = New System.Drawing.Point(696, 464)
        Me.Button170.Margin = New System.Windows.Forms.Padding(4)
        Me.Button170.Name = "Button170"
        Me.Button170.Size = New System.Drawing.Size(40, 24)
        Me.Button170.TabIndex = 950
        Me.Button170.UseVisualStyleBackColor = False
        '
        'Button171
        '
        Me.Button171.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button171.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button171.Location = New System.Drawing.Point(744, 464)
        Me.Button171.Margin = New System.Windows.Forms.Padding(4)
        Me.Button171.Name = "Button171"
        Me.Button171.Size = New System.Drawing.Size(40, 24)
        Me.Button171.TabIndex = 949
        Me.Button171.UseVisualStyleBackColor = False
        '
        'Button172
        '
        Me.Button172.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button172.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button172.Location = New System.Drawing.Point(792, 464)
        Me.Button172.Margin = New System.Windows.Forms.Padding(4)
        Me.Button172.Name = "Button172"
        Me.Button172.Size = New System.Drawing.Size(40, 24)
        Me.Button172.TabIndex = 948
        Me.Button172.UseVisualStyleBackColor = False
        '
        'Button173
        '
        Me.Button173.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button173.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button173.Location = New System.Drawing.Point(864, 464)
        Me.Button173.Margin = New System.Windows.Forms.Padding(4)
        Me.Button173.Name = "Button173"
        Me.Button173.Size = New System.Drawing.Size(40, 24)
        Me.Button173.TabIndex = 947
        Me.Button173.UseVisualStyleBackColor = False
        '
        'Button174
        '
        Me.Button174.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button174.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button174.Location = New System.Drawing.Point(912, 464)
        Me.Button174.Margin = New System.Windows.Forms.Padding(4)
        Me.Button174.Name = "Button174"
        Me.Button174.Size = New System.Drawing.Size(40, 24)
        Me.Button174.TabIndex = 946
        Me.Button174.UseVisualStyleBackColor = False
        '
        'Button175
        '
        Me.Button175.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button175.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button175.Location = New System.Drawing.Point(960, 464)
        Me.Button175.Margin = New System.Windows.Forms.Padding(4)
        Me.Button175.Name = "Button175"
        Me.Button175.Size = New System.Drawing.Size(40, 24)
        Me.Button175.TabIndex = 945
        Me.Button175.UseVisualStyleBackColor = False
        '
        'Button176
        '
        Me.Button176.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button176.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button176.Location = New System.Drawing.Point(1008, 464)
        Me.Button176.Margin = New System.Windows.Forms.Padding(4)
        Me.Button176.Name = "Button176"
        Me.Button176.Size = New System.Drawing.Size(40, 24)
        Me.Button176.TabIndex = 944
        Me.Button176.UseVisualStyleBackColor = False
        '
        'Button177
        '
        Me.Button177.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button177.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button177.Location = New System.Drawing.Point(1072, 464)
        Me.Button177.Margin = New System.Windows.Forms.Padding(4)
        Me.Button177.Name = "Button177"
        Me.Button177.Size = New System.Drawing.Size(40, 24)
        Me.Button177.TabIndex = 943
        Me.Button177.UseVisualStyleBackColor = False
        '
        'Button178
        '
        Me.Button178.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button178.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button178.Location = New System.Drawing.Point(1120, 464)
        Me.Button178.Margin = New System.Windows.Forms.Padding(4)
        Me.Button178.Name = "Button178"
        Me.Button178.Size = New System.Drawing.Size(40, 24)
        Me.Button178.TabIndex = 942
        Me.Button178.UseVisualStyleBackColor = False
        '
        'Button179
        '
        Me.Button179.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button179.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button179.Location = New System.Drawing.Point(1168, 464)
        Me.Button179.Margin = New System.Windows.Forms.Padding(4)
        Me.Button179.Name = "Button179"
        Me.Button179.Size = New System.Drawing.Size(40, 24)
        Me.Button179.TabIndex = 941
        Me.Button179.UseVisualStyleBackColor = False
        '
        'Button180
        '
        Me.Button180.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button180.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button180.Location = New System.Drawing.Point(1216, 464)
        Me.Button180.Margin = New System.Windows.Forms.Padding(4)
        Me.Button180.Name = "Button180"
        Me.Button180.Size = New System.Drawing.Size(40, 24)
        Me.Button180.TabIndex = 940
        Me.Button180.UseVisualStyleBackColor = False
        '
        'Button141
        '
        Me.Button141.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button141.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button141.Location = New System.Drawing.Point(224, 424)
        Me.Button141.Margin = New System.Windows.Forms.Padding(4)
        Me.Button141.Name = "Button141"
        Me.Button141.Size = New System.Drawing.Size(40, 24)
        Me.Button141.TabIndex = 939
        Me.Button141.UseVisualStyleBackColor = False
        '
        'Button142
        '
        Me.Button142.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button142.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button142.Location = New System.Drawing.Point(272, 424)
        Me.Button142.Margin = New System.Windows.Forms.Padding(4)
        Me.Button142.Name = "Button142"
        Me.Button142.Size = New System.Drawing.Size(40, 24)
        Me.Button142.TabIndex = 938
        Me.Button142.UseVisualStyleBackColor = False
        '
        'Button143
        '
        Me.Button143.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button143.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button143.Location = New System.Drawing.Point(320, 424)
        Me.Button143.Margin = New System.Windows.Forms.Padding(4)
        Me.Button143.Name = "Button143"
        Me.Button143.Size = New System.Drawing.Size(40, 24)
        Me.Button143.TabIndex = 937
        Me.Button143.UseVisualStyleBackColor = False
        '
        'Button144
        '
        Me.Button144.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button144.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button144.Location = New System.Drawing.Point(368, 424)
        Me.Button144.Margin = New System.Windows.Forms.Padding(4)
        Me.Button144.Name = "Button144"
        Me.Button144.Size = New System.Drawing.Size(40, 24)
        Me.Button144.TabIndex = 936
        Me.Button144.UseVisualStyleBackColor = False
        '
        'Button145
        '
        Me.Button145.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button145.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button145.Location = New System.Drawing.Point(432, 424)
        Me.Button145.Margin = New System.Windows.Forms.Padding(4)
        Me.Button145.Name = "Button145"
        Me.Button145.Size = New System.Drawing.Size(40, 24)
        Me.Button145.TabIndex = 935
        Me.Button145.UseVisualStyleBackColor = False
        '
        'Button146
        '
        Me.Button146.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button146.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button146.Location = New System.Drawing.Point(480, 424)
        Me.Button146.Margin = New System.Windows.Forms.Padding(4)
        Me.Button146.Name = "Button146"
        Me.Button146.Size = New System.Drawing.Size(40, 24)
        Me.Button146.TabIndex = 934
        Me.Button146.UseVisualStyleBackColor = False
        '
        'Button147
        '
        Me.Button147.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button147.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button147.Location = New System.Drawing.Point(528, 424)
        Me.Button147.Margin = New System.Windows.Forms.Padding(4)
        Me.Button147.Name = "Button147"
        Me.Button147.Size = New System.Drawing.Size(40, 24)
        Me.Button147.TabIndex = 933
        Me.Button147.UseVisualStyleBackColor = False
        '
        'Button148
        '
        Me.Button148.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button148.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button148.Location = New System.Drawing.Point(576, 424)
        Me.Button148.Margin = New System.Windows.Forms.Padding(4)
        Me.Button148.Name = "Button148"
        Me.Button148.Size = New System.Drawing.Size(40, 24)
        Me.Button148.TabIndex = 932
        Me.Button148.UseVisualStyleBackColor = False
        '
        'Button149
        '
        Me.Button149.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button149.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button149.Location = New System.Drawing.Point(648, 424)
        Me.Button149.Margin = New System.Windows.Forms.Padding(4)
        Me.Button149.Name = "Button149"
        Me.Button149.Size = New System.Drawing.Size(40, 24)
        Me.Button149.TabIndex = 931
        Me.Button149.UseVisualStyleBackColor = False
        '
        'Button150
        '
        Me.Button150.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button150.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button150.Location = New System.Drawing.Point(696, 424)
        Me.Button150.Margin = New System.Windows.Forms.Padding(4)
        Me.Button150.Name = "Button150"
        Me.Button150.Size = New System.Drawing.Size(40, 24)
        Me.Button150.TabIndex = 930
        Me.Button150.UseVisualStyleBackColor = False
        '
        'Button151
        '
        Me.Button151.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button151.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button151.Location = New System.Drawing.Point(744, 424)
        Me.Button151.Margin = New System.Windows.Forms.Padding(4)
        Me.Button151.Name = "Button151"
        Me.Button151.Size = New System.Drawing.Size(40, 24)
        Me.Button151.TabIndex = 929
        Me.Button151.UseVisualStyleBackColor = False
        '
        'Button152
        '
        Me.Button152.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button152.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button152.Location = New System.Drawing.Point(792, 424)
        Me.Button152.Margin = New System.Windows.Forms.Padding(4)
        Me.Button152.Name = "Button152"
        Me.Button152.Size = New System.Drawing.Size(40, 24)
        Me.Button152.TabIndex = 928
        Me.Button152.UseVisualStyleBackColor = False
        '
        'Button153
        '
        Me.Button153.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button153.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button153.Location = New System.Drawing.Point(864, 424)
        Me.Button153.Margin = New System.Windows.Forms.Padding(4)
        Me.Button153.Name = "Button153"
        Me.Button153.Size = New System.Drawing.Size(40, 24)
        Me.Button153.TabIndex = 927
        Me.Button153.UseVisualStyleBackColor = False
        '
        'Button154
        '
        Me.Button154.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button154.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button154.Location = New System.Drawing.Point(912, 424)
        Me.Button154.Margin = New System.Windows.Forms.Padding(4)
        Me.Button154.Name = "Button154"
        Me.Button154.Size = New System.Drawing.Size(40, 24)
        Me.Button154.TabIndex = 926
        Me.Button154.UseVisualStyleBackColor = False
        '
        'Button155
        '
        Me.Button155.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button155.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button155.Location = New System.Drawing.Point(960, 424)
        Me.Button155.Margin = New System.Windows.Forms.Padding(4)
        Me.Button155.Name = "Button155"
        Me.Button155.Size = New System.Drawing.Size(40, 24)
        Me.Button155.TabIndex = 925
        Me.Button155.UseVisualStyleBackColor = False
        '
        'Button156
        '
        Me.Button156.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button156.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button156.Location = New System.Drawing.Point(1008, 424)
        Me.Button156.Margin = New System.Windows.Forms.Padding(4)
        Me.Button156.Name = "Button156"
        Me.Button156.Size = New System.Drawing.Size(40, 24)
        Me.Button156.TabIndex = 924
        Me.Button156.UseVisualStyleBackColor = False
        '
        'Button157
        '
        Me.Button157.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button157.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button157.Location = New System.Drawing.Point(1072, 424)
        Me.Button157.Margin = New System.Windows.Forms.Padding(4)
        Me.Button157.Name = "Button157"
        Me.Button157.Size = New System.Drawing.Size(40, 24)
        Me.Button157.TabIndex = 923
        Me.Button157.UseVisualStyleBackColor = False
        '
        'Button158
        '
        Me.Button158.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button158.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button158.Location = New System.Drawing.Point(1120, 424)
        Me.Button158.Margin = New System.Windows.Forms.Padding(4)
        Me.Button158.Name = "Button158"
        Me.Button158.Size = New System.Drawing.Size(40, 24)
        Me.Button158.TabIndex = 922
        Me.Button158.UseVisualStyleBackColor = False
        '
        'Button159
        '
        Me.Button159.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button159.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button159.Location = New System.Drawing.Point(1168, 424)
        Me.Button159.Margin = New System.Windows.Forms.Padding(4)
        Me.Button159.Name = "Button159"
        Me.Button159.Size = New System.Drawing.Size(40, 24)
        Me.Button159.TabIndex = 921
        Me.Button159.UseVisualStyleBackColor = False
        '
        'Button160
        '
        Me.Button160.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button160.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button160.Location = New System.Drawing.Point(1216, 424)
        Me.Button160.Margin = New System.Windows.Forms.Padding(4)
        Me.Button160.Name = "Button160"
        Me.Button160.Size = New System.Drawing.Size(40, 24)
        Me.Button160.TabIndex = 920
        Me.Button160.UseVisualStyleBackColor = False
        '
        'Button121
        '
        Me.Button121.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button121.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button121.Location = New System.Drawing.Point(224, 384)
        Me.Button121.Margin = New System.Windows.Forms.Padding(4)
        Me.Button121.Name = "Button121"
        Me.Button121.Size = New System.Drawing.Size(40, 24)
        Me.Button121.TabIndex = 919
        Me.Button121.UseVisualStyleBackColor = False
        '
        'Button122
        '
        Me.Button122.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button122.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button122.Location = New System.Drawing.Point(272, 384)
        Me.Button122.Margin = New System.Windows.Forms.Padding(4)
        Me.Button122.Name = "Button122"
        Me.Button122.Size = New System.Drawing.Size(40, 24)
        Me.Button122.TabIndex = 918
        Me.Button122.UseVisualStyleBackColor = False
        '
        'Button123
        '
        Me.Button123.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button123.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button123.Location = New System.Drawing.Point(320, 384)
        Me.Button123.Margin = New System.Windows.Forms.Padding(4)
        Me.Button123.Name = "Button123"
        Me.Button123.Size = New System.Drawing.Size(40, 24)
        Me.Button123.TabIndex = 917
        Me.Button123.UseVisualStyleBackColor = False
        '
        'Button124
        '
        Me.Button124.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button124.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button124.Location = New System.Drawing.Point(368, 384)
        Me.Button124.Margin = New System.Windows.Forms.Padding(4)
        Me.Button124.Name = "Button124"
        Me.Button124.Size = New System.Drawing.Size(40, 24)
        Me.Button124.TabIndex = 916
        Me.Button124.UseVisualStyleBackColor = False
        '
        'Button125
        '
        Me.Button125.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button125.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button125.Location = New System.Drawing.Point(432, 384)
        Me.Button125.Margin = New System.Windows.Forms.Padding(4)
        Me.Button125.Name = "Button125"
        Me.Button125.Size = New System.Drawing.Size(40, 24)
        Me.Button125.TabIndex = 915
        Me.Button125.UseVisualStyleBackColor = False
        '
        'Button126
        '
        Me.Button126.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button126.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button126.Location = New System.Drawing.Point(480, 384)
        Me.Button126.Margin = New System.Windows.Forms.Padding(4)
        Me.Button126.Name = "Button126"
        Me.Button126.Size = New System.Drawing.Size(40, 24)
        Me.Button126.TabIndex = 914
        Me.Button126.UseVisualStyleBackColor = False
        '
        'Button127
        '
        Me.Button127.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button127.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button127.Location = New System.Drawing.Point(528, 384)
        Me.Button127.Margin = New System.Windows.Forms.Padding(4)
        Me.Button127.Name = "Button127"
        Me.Button127.Size = New System.Drawing.Size(40, 24)
        Me.Button127.TabIndex = 913
        Me.Button127.UseVisualStyleBackColor = False
        '
        'Button128
        '
        Me.Button128.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button128.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button128.Location = New System.Drawing.Point(576, 384)
        Me.Button128.Margin = New System.Windows.Forms.Padding(4)
        Me.Button128.Name = "Button128"
        Me.Button128.Size = New System.Drawing.Size(40, 24)
        Me.Button128.TabIndex = 912
        Me.Button128.UseVisualStyleBackColor = False
        '
        'Button129
        '
        Me.Button129.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button129.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button129.Location = New System.Drawing.Point(648, 384)
        Me.Button129.Margin = New System.Windows.Forms.Padding(4)
        Me.Button129.Name = "Button129"
        Me.Button129.Size = New System.Drawing.Size(40, 24)
        Me.Button129.TabIndex = 911
        Me.Button129.UseVisualStyleBackColor = False
        '
        'Button130
        '
        Me.Button130.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button130.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button130.Location = New System.Drawing.Point(696, 384)
        Me.Button130.Margin = New System.Windows.Forms.Padding(4)
        Me.Button130.Name = "Button130"
        Me.Button130.Size = New System.Drawing.Size(40, 24)
        Me.Button130.TabIndex = 910
        Me.Button130.UseVisualStyleBackColor = False
        '
        'Button131
        '
        Me.Button131.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button131.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button131.Location = New System.Drawing.Point(744, 384)
        Me.Button131.Margin = New System.Windows.Forms.Padding(4)
        Me.Button131.Name = "Button131"
        Me.Button131.Size = New System.Drawing.Size(40, 24)
        Me.Button131.TabIndex = 909
        Me.Button131.UseVisualStyleBackColor = False
        '
        'Button132
        '
        Me.Button132.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button132.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button132.Location = New System.Drawing.Point(792, 384)
        Me.Button132.Margin = New System.Windows.Forms.Padding(4)
        Me.Button132.Name = "Button132"
        Me.Button132.Size = New System.Drawing.Size(40, 24)
        Me.Button132.TabIndex = 908
        Me.Button132.UseVisualStyleBackColor = False
        '
        'Button133
        '
        Me.Button133.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button133.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button133.Location = New System.Drawing.Point(864, 384)
        Me.Button133.Margin = New System.Windows.Forms.Padding(4)
        Me.Button133.Name = "Button133"
        Me.Button133.Size = New System.Drawing.Size(40, 24)
        Me.Button133.TabIndex = 907
        Me.Button133.UseVisualStyleBackColor = False
        '
        'Button134
        '
        Me.Button134.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button134.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button134.Location = New System.Drawing.Point(912, 384)
        Me.Button134.Margin = New System.Windows.Forms.Padding(4)
        Me.Button134.Name = "Button134"
        Me.Button134.Size = New System.Drawing.Size(40, 24)
        Me.Button134.TabIndex = 906
        Me.Button134.UseVisualStyleBackColor = False
        '
        'Button135
        '
        Me.Button135.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button135.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button135.Location = New System.Drawing.Point(960, 384)
        Me.Button135.Margin = New System.Windows.Forms.Padding(4)
        Me.Button135.Name = "Button135"
        Me.Button135.Size = New System.Drawing.Size(40, 24)
        Me.Button135.TabIndex = 905
        Me.Button135.UseVisualStyleBackColor = False
        '
        'Button136
        '
        Me.Button136.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button136.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button136.Location = New System.Drawing.Point(1008, 384)
        Me.Button136.Margin = New System.Windows.Forms.Padding(4)
        Me.Button136.Name = "Button136"
        Me.Button136.Size = New System.Drawing.Size(40, 24)
        Me.Button136.TabIndex = 904
        Me.Button136.UseVisualStyleBackColor = False
        '
        'Button137
        '
        Me.Button137.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button137.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button137.Location = New System.Drawing.Point(1072, 384)
        Me.Button137.Margin = New System.Windows.Forms.Padding(4)
        Me.Button137.Name = "Button137"
        Me.Button137.Size = New System.Drawing.Size(40, 24)
        Me.Button137.TabIndex = 903
        Me.Button137.UseVisualStyleBackColor = False
        '
        'Button138
        '
        Me.Button138.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button138.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button138.Location = New System.Drawing.Point(1120, 384)
        Me.Button138.Margin = New System.Windows.Forms.Padding(4)
        Me.Button138.Name = "Button138"
        Me.Button138.Size = New System.Drawing.Size(40, 24)
        Me.Button138.TabIndex = 902
        Me.Button138.UseVisualStyleBackColor = False
        '
        'Button139
        '
        Me.Button139.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button139.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button139.Location = New System.Drawing.Point(1168, 384)
        Me.Button139.Margin = New System.Windows.Forms.Padding(4)
        Me.Button139.Name = "Button139"
        Me.Button139.Size = New System.Drawing.Size(40, 24)
        Me.Button139.TabIndex = 901
        Me.Button139.UseVisualStyleBackColor = False
        '
        'Button140
        '
        Me.Button140.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button140.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button140.Location = New System.Drawing.Point(1216, 384)
        Me.Button140.Margin = New System.Windows.Forms.Padding(4)
        Me.Button140.Name = "Button140"
        Me.Button140.Size = New System.Drawing.Size(40, 24)
        Me.Button140.TabIndex = 900
        Me.Button140.UseVisualStyleBackColor = False
        '
        'Button101
        '
        Me.Button101.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button101.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button101.Location = New System.Drawing.Point(224, 344)
        Me.Button101.Margin = New System.Windows.Forms.Padding(4)
        Me.Button101.Name = "Button101"
        Me.Button101.Size = New System.Drawing.Size(40, 24)
        Me.Button101.TabIndex = 899
        Me.Button101.UseVisualStyleBackColor = False
        '
        'Button102
        '
        Me.Button102.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button102.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button102.Location = New System.Drawing.Point(272, 344)
        Me.Button102.Margin = New System.Windows.Forms.Padding(4)
        Me.Button102.Name = "Button102"
        Me.Button102.Size = New System.Drawing.Size(40, 24)
        Me.Button102.TabIndex = 898
        Me.Button102.UseVisualStyleBackColor = False
        '
        'Button103
        '
        Me.Button103.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button103.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button103.Location = New System.Drawing.Point(320, 344)
        Me.Button103.Margin = New System.Windows.Forms.Padding(4)
        Me.Button103.Name = "Button103"
        Me.Button103.Size = New System.Drawing.Size(40, 24)
        Me.Button103.TabIndex = 897
        Me.Button103.UseVisualStyleBackColor = False
        '
        'Button104
        '
        Me.Button104.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button104.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button104.Location = New System.Drawing.Point(368, 344)
        Me.Button104.Margin = New System.Windows.Forms.Padding(4)
        Me.Button104.Name = "Button104"
        Me.Button104.Size = New System.Drawing.Size(40, 24)
        Me.Button104.TabIndex = 896
        Me.Button104.UseVisualStyleBackColor = False
        '
        'Button105
        '
        Me.Button105.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button105.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button105.Location = New System.Drawing.Point(432, 344)
        Me.Button105.Margin = New System.Windows.Forms.Padding(4)
        Me.Button105.Name = "Button105"
        Me.Button105.Size = New System.Drawing.Size(40, 24)
        Me.Button105.TabIndex = 895
        Me.Button105.UseVisualStyleBackColor = False
        '
        'Button106
        '
        Me.Button106.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button106.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button106.Location = New System.Drawing.Point(480, 344)
        Me.Button106.Margin = New System.Windows.Forms.Padding(4)
        Me.Button106.Name = "Button106"
        Me.Button106.Size = New System.Drawing.Size(40, 24)
        Me.Button106.TabIndex = 894
        Me.Button106.UseVisualStyleBackColor = False
        '
        'Button107
        '
        Me.Button107.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button107.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button107.Location = New System.Drawing.Point(528, 344)
        Me.Button107.Margin = New System.Windows.Forms.Padding(4)
        Me.Button107.Name = "Button107"
        Me.Button107.Size = New System.Drawing.Size(40, 24)
        Me.Button107.TabIndex = 893
        Me.Button107.UseVisualStyleBackColor = False
        '
        'Button108
        '
        Me.Button108.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button108.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button108.Location = New System.Drawing.Point(576, 344)
        Me.Button108.Margin = New System.Windows.Forms.Padding(4)
        Me.Button108.Name = "Button108"
        Me.Button108.Size = New System.Drawing.Size(40, 24)
        Me.Button108.TabIndex = 892
        Me.Button108.UseVisualStyleBackColor = False
        '
        'Button109
        '
        Me.Button109.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button109.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button109.Location = New System.Drawing.Point(648, 344)
        Me.Button109.Margin = New System.Windows.Forms.Padding(4)
        Me.Button109.Name = "Button109"
        Me.Button109.Size = New System.Drawing.Size(40, 24)
        Me.Button109.TabIndex = 891
        Me.Button109.UseVisualStyleBackColor = False
        '
        'Button110
        '
        Me.Button110.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button110.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button110.Location = New System.Drawing.Point(696, 344)
        Me.Button110.Margin = New System.Windows.Forms.Padding(4)
        Me.Button110.Name = "Button110"
        Me.Button110.Size = New System.Drawing.Size(40, 24)
        Me.Button110.TabIndex = 890
        Me.Button110.UseVisualStyleBackColor = False
        '
        'Button111
        '
        Me.Button111.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button111.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button111.Location = New System.Drawing.Point(744, 344)
        Me.Button111.Margin = New System.Windows.Forms.Padding(4)
        Me.Button111.Name = "Button111"
        Me.Button111.Size = New System.Drawing.Size(40, 24)
        Me.Button111.TabIndex = 889
        Me.Button111.UseVisualStyleBackColor = False
        '
        'Button112
        '
        Me.Button112.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button112.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button112.Location = New System.Drawing.Point(792, 344)
        Me.Button112.Margin = New System.Windows.Forms.Padding(4)
        Me.Button112.Name = "Button112"
        Me.Button112.Size = New System.Drawing.Size(40, 24)
        Me.Button112.TabIndex = 888
        Me.Button112.UseVisualStyleBackColor = False
        '
        'Button113
        '
        Me.Button113.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button113.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button113.Location = New System.Drawing.Point(864, 344)
        Me.Button113.Margin = New System.Windows.Forms.Padding(4)
        Me.Button113.Name = "Button113"
        Me.Button113.Size = New System.Drawing.Size(40, 24)
        Me.Button113.TabIndex = 887
        Me.Button113.UseVisualStyleBackColor = False
        '
        'Button114
        '
        Me.Button114.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button114.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button114.Location = New System.Drawing.Point(912, 344)
        Me.Button114.Margin = New System.Windows.Forms.Padding(4)
        Me.Button114.Name = "Button114"
        Me.Button114.Size = New System.Drawing.Size(40, 24)
        Me.Button114.TabIndex = 886
        Me.Button114.UseVisualStyleBackColor = False
        '
        'Button115
        '
        Me.Button115.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button115.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button115.Location = New System.Drawing.Point(960, 344)
        Me.Button115.Margin = New System.Windows.Forms.Padding(4)
        Me.Button115.Name = "Button115"
        Me.Button115.Size = New System.Drawing.Size(40, 24)
        Me.Button115.TabIndex = 885
        Me.Button115.UseVisualStyleBackColor = False
        '
        'Button116
        '
        Me.Button116.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button116.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button116.Location = New System.Drawing.Point(1008, 344)
        Me.Button116.Margin = New System.Windows.Forms.Padding(4)
        Me.Button116.Name = "Button116"
        Me.Button116.Size = New System.Drawing.Size(40, 24)
        Me.Button116.TabIndex = 884
        Me.Button116.UseVisualStyleBackColor = False
        '
        'Button117
        '
        Me.Button117.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button117.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button117.Location = New System.Drawing.Point(1072, 344)
        Me.Button117.Margin = New System.Windows.Forms.Padding(4)
        Me.Button117.Name = "Button117"
        Me.Button117.Size = New System.Drawing.Size(40, 24)
        Me.Button117.TabIndex = 883
        Me.Button117.UseVisualStyleBackColor = False
        '
        'Button118
        '
        Me.Button118.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button118.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button118.Location = New System.Drawing.Point(1120, 344)
        Me.Button118.Margin = New System.Windows.Forms.Padding(4)
        Me.Button118.Name = "Button118"
        Me.Button118.Size = New System.Drawing.Size(40, 24)
        Me.Button118.TabIndex = 882
        Me.Button118.UseVisualStyleBackColor = False
        '
        'Button119
        '
        Me.Button119.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button119.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button119.Location = New System.Drawing.Point(1168, 344)
        Me.Button119.Margin = New System.Windows.Forms.Padding(4)
        Me.Button119.Name = "Button119"
        Me.Button119.Size = New System.Drawing.Size(40, 24)
        Me.Button119.TabIndex = 881
        Me.Button119.UseVisualStyleBackColor = False
        '
        'Button120
        '
        Me.Button120.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button120.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button120.Location = New System.Drawing.Point(1216, 344)
        Me.Button120.Margin = New System.Windows.Forms.Padding(4)
        Me.Button120.Name = "Button120"
        Me.Button120.Size = New System.Drawing.Size(40, 24)
        Me.Button120.TabIndex = 880
        Me.Button120.UseVisualStyleBackColor = False
        '
        'Button81
        '
        Me.Button81.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button81.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button81.Location = New System.Drawing.Point(224, 296)
        Me.Button81.Margin = New System.Windows.Forms.Padding(4)
        Me.Button81.Name = "Button81"
        Me.Button81.Size = New System.Drawing.Size(40, 24)
        Me.Button81.TabIndex = 879
        Me.Button81.UseVisualStyleBackColor = False
        '
        'Button82
        '
        Me.Button82.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button82.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button82.Location = New System.Drawing.Point(272, 296)
        Me.Button82.Margin = New System.Windows.Forms.Padding(4)
        Me.Button82.Name = "Button82"
        Me.Button82.Size = New System.Drawing.Size(40, 24)
        Me.Button82.TabIndex = 878
        Me.Button82.UseVisualStyleBackColor = False
        '
        'Button83
        '
        Me.Button83.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button83.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button83.Location = New System.Drawing.Point(320, 296)
        Me.Button83.Margin = New System.Windows.Forms.Padding(4)
        Me.Button83.Name = "Button83"
        Me.Button83.Size = New System.Drawing.Size(40, 24)
        Me.Button83.TabIndex = 877
        Me.Button83.UseVisualStyleBackColor = False
        '
        'Button84
        '
        Me.Button84.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button84.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button84.Location = New System.Drawing.Point(368, 296)
        Me.Button84.Margin = New System.Windows.Forms.Padding(4)
        Me.Button84.Name = "Button84"
        Me.Button84.Size = New System.Drawing.Size(40, 24)
        Me.Button84.TabIndex = 876
        Me.Button84.UseVisualStyleBackColor = False
        '
        'Button85
        '
        Me.Button85.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button85.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button85.Location = New System.Drawing.Point(432, 296)
        Me.Button85.Margin = New System.Windows.Forms.Padding(4)
        Me.Button85.Name = "Button85"
        Me.Button85.Size = New System.Drawing.Size(40, 24)
        Me.Button85.TabIndex = 875
        Me.Button85.UseVisualStyleBackColor = False
        '
        'Button86
        '
        Me.Button86.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button86.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button86.Location = New System.Drawing.Point(480, 296)
        Me.Button86.Margin = New System.Windows.Forms.Padding(4)
        Me.Button86.Name = "Button86"
        Me.Button86.Size = New System.Drawing.Size(40, 24)
        Me.Button86.TabIndex = 874
        Me.Button86.UseVisualStyleBackColor = False
        '
        'Button87
        '
        Me.Button87.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button87.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button87.Location = New System.Drawing.Point(528, 296)
        Me.Button87.Margin = New System.Windows.Forms.Padding(4)
        Me.Button87.Name = "Button87"
        Me.Button87.Size = New System.Drawing.Size(40, 24)
        Me.Button87.TabIndex = 873
        Me.Button87.UseVisualStyleBackColor = False
        '
        'Button88
        '
        Me.Button88.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button88.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button88.Location = New System.Drawing.Point(576, 296)
        Me.Button88.Margin = New System.Windows.Forms.Padding(4)
        Me.Button88.Name = "Button88"
        Me.Button88.Size = New System.Drawing.Size(40, 24)
        Me.Button88.TabIndex = 872
        Me.Button88.UseVisualStyleBackColor = False
        '
        'Button89
        '
        Me.Button89.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button89.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button89.Location = New System.Drawing.Point(648, 296)
        Me.Button89.Margin = New System.Windows.Forms.Padding(4)
        Me.Button89.Name = "Button89"
        Me.Button89.Size = New System.Drawing.Size(40, 24)
        Me.Button89.TabIndex = 871
        Me.Button89.UseVisualStyleBackColor = False
        '
        'Button90
        '
        Me.Button90.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button90.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button90.Location = New System.Drawing.Point(696, 296)
        Me.Button90.Margin = New System.Windows.Forms.Padding(4)
        Me.Button90.Name = "Button90"
        Me.Button90.Size = New System.Drawing.Size(40, 24)
        Me.Button90.TabIndex = 870
        Me.Button90.UseVisualStyleBackColor = False
        '
        'Button91
        '
        Me.Button91.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button91.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button91.Location = New System.Drawing.Point(744, 296)
        Me.Button91.Margin = New System.Windows.Forms.Padding(4)
        Me.Button91.Name = "Button91"
        Me.Button91.Size = New System.Drawing.Size(40, 24)
        Me.Button91.TabIndex = 869
        Me.Button91.UseVisualStyleBackColor = False
        '
        'Button92
        '
        Me.Button92.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button92.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button92.Location = New System.Drawing.Point(792, 296)
        Me.Button92.Margin = New System.Windows.Forms.Padding(4)
        Me.Button92.Name = "Button92"
        Me.Button92.Size = New System.Drawing.Size(40, 24)
        Me.Button92.TabIndex = 868
        Me.Button92.UseVisualStyleBackColor = False
        '
        'Button93
        '
        Me.Button93.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button93.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button93.Location = New System.Drawing.Point(864, 296)
        Me.Button93.Margin = New System.Windows.Forms.Padding(4)
        Me.Button93.Name = "Button93"
        Me.Button93.Size = New System.Drawing.Size(40, 24)
        Me.Button93.TabIndex = 867
        Me.Button93.UseVisualStyleBackColor = False
        '
        'Button94
        '
        Me.Button94.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button94.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button94.Location = New System.Drawing.Point(912, 296)
        Me.Button94.Margin = New System.Windows.Forms.Padding(4)
        Me.Button94.Name = "Button94"
        Me.Button94.Size = New System.Drawing.Size(40, 24)
        Me.Button94.TabIndex = 866
        Me.Button94.UseVisualStyleBackColor = False
        '
        'Button95
        '
        Me.Button95.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button95.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button95.Location = New System.Drawing.Point(960, 296)
        Me.Button95.Margin = New System.Windows.Forms.Padding(4)
        Me.Button95.Name = "Button95"
        Me.Button95.Size = New System.Drawing.Size(40, 24)
        Me.Button95.TabIndex = 865
        Me.Button95.UseVisualStyleBackColor = False
        '
        'Button96
        '
        Me.Button96.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button96.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button96.Location = New System.Drawing.Point(1008, 296)
        Me.Button96.Margin = New System.Windows.Forms.Padding(4)
        Me.Button96.Name = "Button96"
        Me.Button96.Size = New System.Drawing.Size(40, 24)
        Me.Button96.TabIndex = 864
        Me.Button96.UseVisualStyleBackColor = False
        '
        'Button97
        '
        Me.Button97.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button97.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button97.Location = New System.Drawing.Point(1072, 296)
        Me.Button97.Margin = New System.Windows.Forms.Padding(4)
        Me.Button97.Name = "Button97"
        Me.Button97.Size = New System.Drawing.Size(40, 24)
        Me.Button97.TabIndex = 863
        Me.Button97.UseVisualStyleBackColor = False
        '
        'Button98
        '
        Me.Button98.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button98.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button98.Location = New System.Drawing.Point(1120, 296)
        Me.Button98.Margin = New System.Windows.Forms.Padding(4)
        Me.Button98.Name = "Button98"
        Me.Button98.Size = New System.Drawing.Size(40, 24)
        Me.Button98.TabIndex = 862
        Me.Button98.UseVisualStyleBackColor = False
        '
        'Button99
        '
        Me.Button99.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button99.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button99.Location = New System.Drawing.Point(1168, 296)
        Me.Button99.Margin = New System.Windows.Forms.Padding(4)
        Me.Button99.Name = "Button99"
        Me.Button99.Size = New System.Drawing.Size(40, 24)
        Me.Button99.TabIndex = 861
        Me.Button99.UseVisualStyleBackColor = False
        '
        'Button100
        '
        Me.Button100.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button100.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button100.Location = New System.Drawing.Point(1216, 296)
        Me.Button100.Margin = New System.Windows.Forms.Padding(4)
        Me.Button100.Name = "Button100"
        Me.Button100.Size = New System.Drawing.Size(40, 24)
        Me.Button100.TabIndex = 860
        Me.Button100.UseVisualStyleBackColor = False
        '
        'Button61
        '
        Me.Button61.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button61.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button61.Location = New System.Drawing.Point(224, 256)
        Me.Button61.Margin = New System.Windows.Forms.Padding(4)
        Me.Button61.Name = "Button61"
        Me.Button61.Size = New System.Drawing.Size(40, 24)
        Me.Button61.TabIndex = 859
        Me.Button61.UseVisualStyleBackColor = False
        '
        'Button62
        '
        Me.Button62.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button62.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button62.Location = New System.Drawing.Point(272, 256)
        Me.Button62.Margin = New System.Windows.Forms.Padding(4)
        Me.Button62.Name = "Button62"
        Me.Button62.Size = New System.Drawing.Size(40, 24)
        Me.Button62.TabIndex = 858
        Me.Button62.UseVisualStyleBackColor = False
        '
        'Button63
        '
        Me.Button63.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button63.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button63.Location = New System.Drawing.Point(320, 256)
        Me.Button63.Margin = New System.Windows.Forms.Padding(4)
        Me.Button63.Name = "Button63"
        Me.Button63.Size = New System.Drawing.Size(40, 24)
        Me.Button63.TabIndex = 857
        Me.Button63.UseVisualStyleBackColor = False
        '
        'Button64
        '
        Me.Button64.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button64.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button64.Location = New System.Drawing.Point(368, 256)
        Me.Button64.Margin = New System.Windows.Forms.Padding(4)
        Me.Button64.Name = "Button64"
        Me.Button64.Size = New System.Drawing.Size(40, 24)
        Me.Button64.TabIndex = 856
        Me.Button64.UseVisualStyleBackColor = False
        '
        'Button65
        '
        Me.Button65.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button65.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button65.Location = New System.Drawing.Point(432, 256)
        Me.Button65.Margin = New System.Windows.Forms.Padding(4)
        Me.Button65.Name = "Button65"
        Me.Button65.Size = New System.Drawing.Size(40, 24)
        Me.Button65.TabIndex = 855
        Me.Button65.UseVisualStyleBackColor = False
        '
        'Button66
        '
        Me.Button66.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button66.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button66.Location = New System.Drawing.Point(480, 256)
        Me.Button66.Margin = New System.Windows.Forms.Padding(4)
        Me.Button66.Name = "Button66"
        Me.Button66.Size = New System.Drawing.Size(40, 24)
        Me.Button66.TabIndex = 854
        Me.Button66.UseVisualStyleBackColor = False
        '
        'Button67
        '
        Me.Button67.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button67.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button67.Location = New System.Drawing.Point(528, 256)
        Me.Button67.Margin = New System.Windows.Forms.Padding(4)
        Me.Button67.Name = "Button67"
        Me.Button67.Size = New System.Drawing.Size(40, 24)
        Me.Button67.TabIndex = 853
        Me.Button67.UseVisualStyleBackColor = False
        '
        'Button68
        '
        Me.Button68.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button68.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button68.Location = New System.Drawing.Point(576, 256)
        Me.Button68.Margin = New System.Windows.Forms.Padding(4)
        Me.Button68.Name = "Button68"
        Me.Button68.Size = New System.Drawing.Size(40, 24)
        Me.Button68.TabIndex = 852
        Me.Button68.UseVisualStyleBackColor = False
        '
        'Button69
        '
        Me.Button69.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button69.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button69.Location = New System.Drawing.Point(648, 256)
        Me.Button69.Margin = New System.Windows.Forms.Padding(4)
        Me.Button69.Name = "Button69"
        Me.Button69.Size = New System.Drawing.Size(40, 24)
        Me.Button69.TabIndex = 851
        Me.Button69.UseVisualStyleBackColor = False
        '
        'Button70
        '
        Me.Button70.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button70.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button70.Location = New System.Drawing.Point(696, 256)
        Me.Button70.Margin = New System.Windows.Forms.Padding(4)
        Me.Button70.Name = "Button70"
        Me.Button70.Size = New System.Drawing.Size(40, 24)
        Me.Button70.TabIndex = 850
        Me.Button70.UseVisualStyleBackColor = False
        '
        'Button71
        '
        Me.Button71.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button71.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button71.Location = New System.Drawing.Point(744, 256)
        Me.Button71.Margin = New System.Windows.Forms.Padding(4)
        Me.Button71.Name = "Button71"
        Me.Button71.Size = New System.Drawing.Size(40, 24)
        Me.Button71.TabIndex = 849
        Me.Button71.UseVisualStyleBackColor = False
        '
        'Button72
        '
        Me.Button72.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button72.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button72.Location = New System.Drawing.Point(792, 256)
        Me.Button72.Margin = New System.Windows.Forms.Padding(4)
        Me.Button72.Name = "Button72"
        Me.Button72.Size = New System.Drawing.Size(40, 24)
        Me.Button72.TabIndex = 848
        Me.Button72.UseVisualStyleBackColor = False
        '
        'Button73
        '
        Me.Button73.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button73.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button73.Location = New System.Drawing.Point(864, 256)
        Me.Button73.Margin = New System.Windows.Forms.Padding(4)
        Me.Button73.Name = "Button73"
        Me.Button73.Size = New System.Drawing.Size(40, 24)
        Me.Button73.TabIndex = 847
        Me.Button73.UseVisualStyleBackColor = False
        '
        'Button74
        '
        Me.Button74.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button74.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button74.Location = New System.Drawing.Point(912, 256)
        Me.Button74.Margin = New System.Windows.Forms.Padding(4)
        Me.Button74.Name = "Button74"
        Me.Button74.Size = New System.Drawing.Size(40, 24)
        Me.Button74.TabIndex = 846
        Me.Button74.UseVisualStyleBackColor = False
        '
        'Button75
        '
        Me.Button75.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button75.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button75.Location = New System.Drawing.Point(960, 256)
        Me.Button75.Margin = New System.Windows.Forms.Padding(4)
        Me.Button75.Name = "Button75"
        Me.Button75.Size = New System.Drawing.Size(40, 24)
        Me.Button75.TabIndex = 845
        Me.Button75.UseVisualStyleBackColor = False
        '
        'Button76
        '
        Me.Button76.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button76.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button76.Location = New System.Drawing.Point(1008, 256)
        Me.Button76.Margin = New System.Windows.Forms.Padding(4)
        Me.Button76.Name = "Button76"
        Me.Button76.Size = New System.Drawing.Size(40, 24)
        Me.Button76.TabIndex = 844
        Me.Button76.UseVisualStyleBackColor = False
        '
        'Button77
        '
        Me.Button77.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button77.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button77.Location = New System.Drawing.Point(1072, 256)
        Me.Button77.Margin = New System.Windows.Forms.Padding(4)
        Me.Button77.Name = "Button77"
        Me.Button77.Size = New System.Drawing.Size(40, 24)
        Me.Button77.TabIndex = 843
        Me.Button77.UseVisualStyleBackColor = False
        '
        'Button78
        '
        Me.Button78.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button78.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button78.Location = New System.Drawing.Point(1120, 256)
        Me.Button78.Margin = New System.Windows.Forms.Padding(4)
        Me.Button78.Name = "Button78"
        Me.Button78.Size = New System.Drawing.Size(40, 24)
        Me.Button78.TabIndex = 842
        Me.Button78.UseVisualStyleBackColor = False
        '
        'Button79
        '
        Me.Button79.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button79.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button79.Location = New System.Drawing.Point(1168, 256)
        Me.Button79.Margin = New System.Windows.Forms.Padding(4)
        Me.Button79.Name = "Button79"
        Me.Button79.Size = New System.Drawing.Size(40, 24)
        Me.Button79.TabIndex = 841
        Me.Button79.UseVisualStyleBackColor = False
        '
        'Button80
        '
        Me.Button80.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button80.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button80.Location = New System.Drawing.Point(1216, 256)
        Me.Button80.Margin = New System.Windows.Forms.Padding(4)
        Me.Button80.Name = "Button80"
        Me.Button80.Size = New System.Drawing.Size(40, 24)
        Me.Button80.TabIndex = 840
        Me.Button80.UseVisualStyleBackColor = False
        '
        'Button41
        '
        Me.Button41.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button41.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button41.Location = New System.Drawing.Point(224, 216)
        Me.Button41.Margin = New System.Windows.Forms.Padding(4)
        Me.Button41.Name = "Button41"
        Me.Button41.Size = New System.Drawing.Size(40, 24)
        Me.Button41.TabIndex = 839
        Me.Button41.UseVisualStyleBackColor = False
        '
        'Button42
        '
        Me.Button42.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button42.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button42.Location = New System.Drawing.Point(272, 216)
        Me.Button42.Margin = New System.Windows.Forms.Padding(4)
        Me.Button42.Name = "Button42"
        Me.Button42.Size = New System.Drawing.Size(40, 24)
        Me.Button42.TabIndex = 838
        Me.Button42.UseVisualStyleBackColor = False
        '
        'Button43
        '
        Me.Button43.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button43.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button43.Location = New System.Drawing.Point(320, 216)
        Me.Button43.Margin = New System.Windows.Forms.Padding(4)
        Me.Button43.Name = "Button43"
        Me.Button43.Size = New System.Drawing.Size(40, 24)
        Me.Button43.TabIndex = 837
        Me.Button43.UseVisualStyleBackColor = False
        '
        'Button44
        '
        Me.Button44.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button44.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button44.Location = New System.Drawing.Point(368, 216)
        Me.Button44.Margin = New System.Windows.Forms.Padding(4)
        Me.Button44.Name = "Button44"
        Me.Button44.Size = New System.Drawing.Size(40, 24)
        Me.Button44.TabIndex = 836
        Me.Button44.UseVisualStyleBackColor = False
        '
        'Button45
        '
        Me.Button45.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button45.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button45.Location = New System.Drawing.Point(432, 216)
        Me.Button45.Margin = New System.Windows.Forms.Padding(4)
        Me.Button45.Name = "Button45"
        Me.Button45.Size = New System.Drawing.Size(40, 24)
        Me.Button45.TabIndex = 835
        Me.Button45.UseVisualStyleBackColor = False
        '
        'Button46
        '
        Me.Button46.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button46.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button46.Location = New System.Drawing.Point(480, 216)
        Me.Button46.Margin = New System.Windows.Forms.Padding(4)
        Me.Button46.Name = "Button46"
        Me.Button46.Size = New System.Drawing.Size(40, 24)
        Me.Button46.TabIndex = 834
        Me.Button46.UseVisualStyleBackColor = False
        '
        'Button47
        '
        Me.Button47.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button47.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button47.Location = New System.Drawing.Point(528, 216)
        Me.Button47.Margin = New System.Windows.Forms.Padding(4)
        Me.Button47.Name = "Button47"
        Me.Button47.Size = New System.Drawing.Size(40, 24)
        Me.Button47.TabIndex = 833
        Me.Button47.UseVisualStyleBackColor = False
        '
        'Button48
        '
        Me.Button48.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button48.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button48.Location = New System.Drawing.Point(576, 216)
        Me.Button48.Margin = New System.Windows.Forms.Padding(4)
        Me.Button48.Name = "Button48"
        Me.Button48.Size = New System.Drawing.Size(40, 24)
        Me.Button48.TabIndex = 832
        Me.Button48.UseVisualStyleBackColor = False
        '
        'Button49
        '
        Me.Button49.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button49.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button49.Location = New System.Drawing.Point(648, 216)
        Me.Button49.Margin = New System.Windows.Forms.Padding(4)
        Me.Button49.Name = "Button49"
        Me.Button49.Size = New System.Drawing.Size(40, 24)
        Me.Button49.TabIndex = 831
        Me.Button49.UseVisualStyleBackColor = False
        '
        'Button50
        '
        Me.Button50.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button50.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button50.Location = New System.Drawing.Point(696, 216)
        Me.Button50.Margin = New System.Windows.Forms.Padding(4)
        Me.Button50.Name = "Button50"
        Me.Button50.Size = New System.Drawing.Size(40, 24)
        Me.Button50.TabIndex = 830
        Me.Button50.UseVisualStyleBackColor = False
        '
        'Button51
        '
        Me.Button51.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button51.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button51.Location = New System.Drawing.Point(744, 216)
        Me.Button51.Margin = New System.Windows.Forms.Padding(4)
        Me.Button51.Name = "Button51"
        Me.Button51.Size = New System.Drawing.Size(40, 24)
        Me.Button51.TabIndex = 829
        Me.Button51.UseVisualStyleBackColor = False
        '
        'Button52
        '
        Me.Button52.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button52.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button52.Location = New System.Drawing.Point(792, 216)
        Me.Button52.Margin = New System.Windows.Forms.Padding(4)
        Me.Button52.Name = "Button52"
        Me.Button52.Size = New System.Drawing.Size(40, 24)
        Me.Button52.TabIndex = 828
        Me.Button52.UseVisualStyleBackColor = False
        '
        'Button53
        '
        Me.Button53.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button53.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button53.Location = New System.Drawing.Point(864, 216)
        Me.Button53.Margin = New System.Windows.Forms.Padding(4)
        Me.Button53.Name = "Button53"
        Me.Button53.Size = New System.Drawing.Size(40, 24)
        Me.Button53.TabIndex = 827
        Me.Button53.UseVisualStyleBackColor = False
        '
        'Button54
        '
        Me.Button54.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button54.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button54.Location = New System.Drawing.Point(912, 216)
        Me.Button54.Margin = New System.Windows.Forms.Padding(4)
        Me.Button54.Name = "Button54"
        Me.Button54.Size = New System.Drawing.Size(40, 24)
        Me.Button54.TabIndex = 826
        Me.Button54.UseVisualStyleBackColor = False
        '
        'Button55
        '
        Me.Button55.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button55.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button55.Location = New System.Drawing.Point(960, 216)
        Me.Button55.Margin = New System.Windows.Forms.Padding(4)
        Me.Button55.Name = "Button55"
        Me.Button55.Size = New System.Drawing.Size(40, 24)
        Me.Button55.TabIndex = 825
        Me.Button55.UseVisualStyleBackColor = False
        '
        'Button56
        '
        Me.Button56.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button56.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button56.Location = New System.Drawing.Point(1008, 216)
        Me.Button56.Margin = New System.Windows.Forms.Padding(4)
        Me.Button56.Name = "Button56"
        Me.Button56.Size = New System.Drawing.Size(40, 24)
        Me.Button56.TabIndex = 824
        Me.Button56.UseVisualStyleBackColor = False
        '
        'Button57
        '
        Me.Button57.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button57.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button57.Location = New System.Drawing.Point(1072, 216)
        Me.Button57.Margin = New System.Windows.Forms.Padding(4)
        Me.Button57.Name = "Button57"
        Me.Button57.Size = New System.Drawing.Size(40, 24)
        Me.Button57.TabIndex = 823
        Me.Button57.UseVisualStyleBackColor = False
        '
        'Button58
        '
        Me.Button58.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button58.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button58.Location = New System.Drawing.Point(1120, 216)
        Me.Button58.Margin = New System.Windows.Forms.Padding(4)
        Me.Button58.Name = "Button58"
        Me.Button58.Size = New System.Drawing.Size(40, 24)
        Me.Button58.TabIndex = 822
        Me.Button58.UseVisualStyleBackColor = False
        '
        'Button59
        '
        Me.Button59.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button59.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button59.Location = New System.Drawing.Point(1168, 216)
        Me.Button59.Margin = New System.Windows.Forms.Padding(4)
        Me.Button59.Name = "Button59"
        Me.Button59.Size = New System.Drawing.Size(40, 24)
        Me.Button59.TabIndex = 821
        Me.Button59.UseVisualStyleBackColor = False
        '
        'Button60
        '
        Me.Button60.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button60.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button60.Location = New System.Drawing.Point(1216, 216)
        Me.Button60.Margin = New System.Windows.Forms.Padding(4)
        Me.Button60.Name = "Button60"
        Me.Button60.Size = New System.Drawing.Size(40, 24)
        Me.Button60.TabIndex = 820
        Me.Button60.UseVisualStyleBackColor = False
        '
        'Button21
        '
        Me.Button21.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button21.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button21.Location = New System.Drawing.Point(224, 176)
        Me.Button21.Margin = New System.Windows.Forms.Padding(4)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(40, 24)
        Me.Button21.TabIndex = 819
        Me.Button21.UseVisualStyleBackColor = False
        '
        'Button22
        '
        Me.Button22.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button22.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button22.Location = New System.Drawing.Point(272, 176)
        Me.Button22.Margin = New System.Windows.Forms.Padding(4)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(40, 24)
        Me.Button22.TabIndex = 818
        Me.Button22.UseVisualStyleBackColor = False
        '
        'Button23
        '
        Me.Button23.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button23.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button23.Location = New System.Drawing.Point(320, 176)
        Me.Button23.Margin = New System.Windows.Forms.Padding(4)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(40, 24)
        Me.Button23.TabIndex = 817
        Me.Button23.UseVisualStyleBackColor = False
        '
        'Button24
        '
        Me.Button24.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button24.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button24.Location = New System.Drawing.Point(368, 176)
        Me.Button24.Margin = New System.Windows.Forms.Padding(4)
        Me.Button24.Name = "Button24"
        Me.Button24.Size = New System.Drawing.Size(40, 24)
        Me.Button24.TabIndex = 816
        Me.Button24.UseVisualStyleBackColor = False
        '
        'Button25
        '
        Me.Button25.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button25.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button25.Location = New System.Drawing.Point(432, 176)
        Me.Button25.Margin = New System.Windows.Forms.Padding(4)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(40, 24)
        Me.Button25.TabIndex = 815
        Me.Button25.UseVisualStyleBackColor = False
        '
        'Button26
        '
        Me.Button26.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button26.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button26.Location = New System.Drawing.Point(480, 176)
        Me.Button26.Margin = New System.Windows.Forms.Padding(4)
        Me.Button26.Name = "Button26"
        Me.Button26.Size = New System.Drawing.Size(40, 24)
        Me.Button26.TabIndex = 814
        Me.Button26.UseVisualStyleBackColor = False
        '
        'Button27
        '
        Me.Button27.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button27.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button27.Location = New System.Drawing.Point(528, 176)
        Me.Button27.Margin = New System.Windows.Forms.Padding(4)
        Me.Button27.Name = "Button27"
        Me.Button27.Size = New System.Drawing.Size(40, 24)
        Me.Button27.TabIndex = 813
        Me.Button27.UseVisualStyleBackColor = False
        '
        'Button28
        '
        Me.Button28.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button28.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button28.Location = New System.Drawing.Point(576, 176)
        Me.Button28.Margin = New System.Windows.Forms.Padding(4)
        Me.Button28.Name = "Button28"
        Me.Button28.Size = New System.Drawing.Size(40, 24)
        Me.Button28.TabIndex = 812
        Me.Button28.UseVisualStyleBackColor = False
        '
        'Button29
        '
        Me.Button29.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button29.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button29.Location = New System.Drawing.Point(648, 176)
        Me.Button29.Margin = New System.Windows.Forms.Padding(4)
        Me.Button29.Name = "Button29"
        Me.Button29.Size = New System.Drawing.Size(40, 24)
        Me.Button29.TabIndex = 811
        Me.Button29.UseVisualStyleBackColor = False
        '
        'Button30
        '
        Me.Button30.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button30.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button30.Location = New System.Drawing.Point(696, 176)
        Me.Button30.Margin = New System.Windows.Forms.Padding(4)
        Me.Button30.Name = "Button30"
        Me.Button30.Size = New System.Drawing.Size(40, 24)
        Me.Button30.TabIndex = 810
        Me.Button30.UseVisualStyleBackColor = False
        '
        'Button31
        '
        Me.Button31.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button31.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button31.Location = New System.Drawing.Point(744, 176)
        Me.Button31.Margin = New System.Windows.Forms.Padding(4)
        Me.Button31.Name = "Button31"
        Me.Button31.Size = New System.Drawing.Size(40, 24)
        Me.Button31.TabIndex = 809
        Me.Button31.UseVisualStyleBackColor = False
        '
        'Button32
        '
        Me.Button32.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button32.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button32.Location = New System.Drawing.Point(792, 176)
        Me.Button32.Margin = New System.Windows.Forms.Padding(4)
        Me.Button32.Name = "Button32"
        Me.Button32.Size = New System.Drawing.Size(40, 24)
        Me.Button32.TabIndex = 808
        Me.Button32.UseVisualStyleBackColor = False
        '
        'Button33
        '
        Me.Button33.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button33.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button33.Location = New System.Drawing.Point(864, 176)
        Me.Button33.Margin = New System.Windows.Forms.Padding(4)
        Me.Button33.Name = "Button33"
        Me.Button33.Size = New System.Drawing.Size(40, 24)
        Me.Button33.TabIndex = 807
        Me.Button33.UseVisualStyleBackColor = False
        '
        'Button34
        '
        Me.Button34.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button34.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button34.Location = New System.Drawing.Point(912, 176)
        Me.Button34.Margin = New System.Windows.Forms.Padding(4)
        Me.Button34.Name = "Button34"
        Me.Button34.Size = New System.Drawing.Size(40, 24)
        Me.Button34.TabIndex = 806
        Me.Button34.UseVisualStyleBackColor = False
        '
        'Button35
        '
        Me.Button35.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button35.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button35.Location = New System.Drawing.Point(960, 176)
        Me.Button35.Margin = New System.Windows.Forms.Padding(4)
        Me.Button35.Name = "Button35"
        Me.Button35.Size = New System.Drawing.Size(40, 24)
        Me.Button35.TabIndex = 805
        Me.Button35.UseVisualStyleBackColor = False
        '
        'Button36
        '
        Me.Button36.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button36.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button36.Location = New System.Drawing.Point(1008, 176)
        Me.Button36.Margin = New System.Windows.Forms.Padding(4)
        Me.Button36.Name = "Button36"
        Me.Button36.Size = New System.Drawing.Size(40, 24)
        Me.Button36.TabIndex = 804
        Me.Button36.UseVisualStyleBackColor = False
        '
        'Button37
        '
        Me.Button37.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button37.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button37.Location = New System.Drawing.Point(1072, 176)
        Me.Button37.Margin = New System.Windows.Forms.Padding(4)
        Me.Button37.Name = "Button37"
        Me.Button37.Size = New System.Drawing.Size(40, 24)
        Me.Button37.TabIndex = 803
        Me.Button37.UseVisualStyleBackColor = False
        '
        'Button38
        '
        Me.Button38.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button38.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button38.Location = New System.Drawing.Point(1120, 176)
        Me.Button38.Margin = New System.Windows.Forms.Padding(4)
        Me.Button38.Name = "Button38"
        Me.Button38.Size = New System.Drawing.Size(40, 24)
        Me.Button38.TabIndex = 802
        Me.Button38.UseVisualStyleBackColor = False
        '
        'Button39
        '
        Me.Button39.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button39.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button39.Location = New System.Drawing.Point(1168, 176)
        Me.Button39.Margin = New System.Windows.Forms.Padding(4)
        Me.Button39.Name = "Button39"
        Me.Button39.Size = New System.Drawing.Size(40, 24)
        Me.Button39.TabIndex = 801
        Me.Button39.UseVisualStyleBackColor = False
        '
        'Button40
        '
        Me.Button40.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button40.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button40.Location = New System.Drawing.Point(1216, 176)
        Me.Button40.Margin = New System.Windows.Forms.Padding(4)
        Me.Button40.Name = "Button40"
        Me.Button40.Size = New System.Drawing.Size(40, 24)
        Me.Button40.TabIndex = 800
        Me.Button40.UseVisualStyleBackColor = False
        '
        'Button13
        '
        Me.Button13.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button13.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button13.Location = New System.Drawing.Point(864, 136)
        Me.Button13.Margin = New System.Windows.Forms.Padding(4)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(40, 24)
        Me.Button13.TabIndex = 799
        Me.Button13.UseVisualStyleBackColor = False
        '
        'Button14
        '
        Me.Button14.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button14.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button14.Location = New System.Drawing.Point(912, 136)
        Me.Button14.Margin = New System.Windows.Forms.Padding(4)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(40, 24)
        Me.Button14.TabIndex = 798
        Me.Button14.UseVisualStyleBackColor = False
        '
        'Button15
        '
        Me.Button15.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button15.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button15.Location = New System.Drawing.Point(960, 136)
        Me.Button15.Margin = New System.Windows.Forms.Padding(4)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(40, 24)
        Me.Button15.TabIndex = 797
        Me.Button15.UseVisualStyleBackColor = False
        '
        'Button16
        '
        Me.Button16.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button16.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button16.Location = New System.Drawing.Point(1008, 136)
        Me.Button16.Margin = New System.Windows.Forms.Padding(4)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(40, 24)
        Me.Button16.TabIndex = 796
        Me.Button16.UseVisualStyleBackColor = False
        '
        'Button17
        '
        Me.Button17.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button17.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button17.Location = New System.Drawing.Point(1072, 136)
        Me.Button17.Margin = New System.Windows.Forms.Padding(4)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(40, 24)
        Me.Button17.TabIndex = 795
        Me.Button17.UseVisualStyleBackColor = False
        '
        'Button18
        '
        Me.Button18.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button18.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button18.Location = New System.Drawing.Point(1120, 136)
        Me.Button18.Margin = New System.Windows.Forms.Padding(4)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(40, 24)
        Me.Button18.TabIndex = 794
        Me.Button18.UseVisualStyleBackColor = False
        '
        'Button19
        '
        Me.Button19.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button19.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button19.Location = New System.Drawing.Point(1168, 136)
        Me.Button19.Margin = New System.Windows.Forms.Padding(4)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(40, 24)
        Me.Button19.TabIndex = 793
        Me.Button19.UseVisualStyleBackColor = False
        '
        'Button20
        '
        Me.Button20.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button20.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button20.Location = New System.Drawing.Point(1216, 136)
        Me.Button20.Margin = New System.Windows.Forms.Padding(4)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(40, 24)
        Me.Button20.TabIndex = 792
        Me.Button20.UseVisualStyleBackColor = False
        '
        'Button9
        '
        Me.Button9.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button9.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button9.Location = New System.Drawing.Point(648, 136)
        Me.Button9.Margin = New System.Windows.Forms.Padding(4)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(40, 24)
        Me.Button9.TabIndex = 791
        Me.Button9.UseVisualStyleBackColor = False
        '
        'Button10
        '
        Me.Button10.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button10.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button10.Location = New System.Drawing.Point(696, 136)
        Me.Button10.Margin = New System.Windows.Forms.Padding(4)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(40, 24)
        Me.Button10.TabIndex = 790
        Me.Button10.UseVisualStyleBackColor = False
        '
        'Button11
        '
        Me.Button11.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button11.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button11.Location = New System.Drawing.Point(744, 136)
        Me.Button11.Margin = New System.Windows.Forms.Padding(4)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(40, 24)
        Me.Button11.TabIndex = 789
        Me.Button11.UseVisualStyleBackColor = False
        '
        'Button12
        '
        Me.Button12.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button12.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button12.Location = New System.Drawing.Point(792, 136)
        Me.Button12.Margin = New System.Windows.Forms.Padding(4)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(40, 24)
        Me.Button12.TabIndex = 788
        Me.Button12.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button5.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button5.Location = New System.Drawing.Point(432, 136)
        Me.Button5.Margin = New System.Windows.Forms.Padding(4)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(40, 24)
        Me.Button5.TabIndex = 787
        Me.Button5.UseVisualStyleBackColor = False
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button6.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button6.Location = New System.Drawing.Point(480, 136)
        Me.Button6.Margin = New System.Windows.Forms.Padding(4)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(40, 24)
        Me.Button6.TabIndex = 786
        Me.Button6.UseVisualStyleBackColor = False
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button7.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button7.Location = New System.Drawing.Point(528, 136)
        Me.Button7.Margin = New System.Windows.Forms.Padding(4)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(40, 24)
        Me.Button7.TabIndex = 785
        Me.Button7.UseVisualStyleBackColor = False
        '
        'Button8
        '
        Me.Button8.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button8.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button8.Location = New System.Drawing.Point(576, 136)
        Me.Button8.Margin = New System.Windows.Forms.Padding(4)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(40, 24)
        Me.Button8.TabIndex = 784
        Me.Button8.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button4.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button4.Location = New System.Drawing.Point(368, 136)
        Me.Button4.Margin = New System.Windows.Forms.Padding(4)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(40, 24)
        Me.Button4.TabIndex = 783
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button3.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button3.Location = New System.Drawing.Point(320, 136)
        Me.Button3.Margin = New System.Windows.Forms.Padding(4)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(40, 24)
        Me.Button3.TabIndex = 782
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button1.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button1.Location = New System.Drawing.Point(224, 136)
        Me.Button1.Margin = New System.Windows.Forms.Padding(4)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(40, 24)
        Me.Button1.TabIndex = 781
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Label14
        '
        Me.Label14.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label14.Location = New System.Drawing.Point(592, 112)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(16, 15)
        Me.Label14.TabIndex = 779
        Me.Label14.Text = "8"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label13.Location = New System.Drawing.Point(800, 112)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(25, 15)
        Me.Label13.TabIndex = 778
        Me.Label13.Text = "12"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label12.Location = New System.Drawing.Point(1016, 112)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(25, 15)
        Me.Label12.TabIndex = 777
        Me.Label12.Text = "16"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label11.Location = New System.Drawing.Point(1224, 112)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(25, 15)
        Me.Label11.TabIndex = 776
        Me.Label11.Text = "20"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label6.Location = New System.Drawing.Point(128, 344)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(16, 15)
        Me.Label6.TabIndex = 775
        Me.Label6.Text = "0"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label7.Location = New System.Drawing.Point(128, 384)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(16, 15)
        Me.Label7.TabIndex = 774
        Me.Label7.Text = "0"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label8.Location = New System.Drawing.Point(128, 424)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(16, 15)
        Me.Label8.TabIndex = 773
        Me.Label8.Text = "0"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label9.Location = New System.Drawing.Point(128, 464)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(16, 15)
        Me.Label9.TabIndex = 772
        Me.Label9.Text = "0"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label10.Location = New System.Drawing.Point(128, 504)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(16, 15)
        Me.Label10.TabIndex = 771
        Me.Label10.Text = "0"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label5.Location = New System.Drawing.Point(128, 296)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(16, 15)
        Me.Label5.TabIndex = 770
        Me.Label5.Text = "0"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label4.Location = New System.Drawing.Point(128, 256)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(16, 15)
        Me.Label4.TabIndex = 769
        Me.Label4.Text = "0"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label3.Location = New System.Drawing.Point(128, 216)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(16, 15)
        Me.Label3.TabIndex = 768
        Me.Label3.Text = "0"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label2.Location = New System.Drawing.Point(128, 176)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(16, 15)
        Me.Label2.TabIndex = 767
        Me.Label2.Text = "0"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label1.Location = New System.Drawing.Point(128, 136)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(16, 15)
        Me.Label1.TabIndex = 766
        Me.Label1.Text = "0"
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button2.Font = New System.Drawing.Font("MS UI Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button2.Location = New System.Drawing.Point(272, 136)
        Me.Button2.Margin = New System.Windows.Forms.Padding(4)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(40, 24)
        Me.Button2.TabIndex = 765
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Label15
        '
        Me.Label15.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label15.Location = New System.Drawing.Point(384, 112)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(16, 15)
        Me.Label15.TabIndex = 1025
        Me.Label15.Text = "4"
        '
        'Tekityu6
        '
        Me.Tekityu6.AutoSize = True
        Me.Tekityu6.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Tekityu6.Location = New System.Drawing.Point(176, 344)
        Me.Tekityu6.Name = "Tekityu6"
        Me.Tekityu6.Size = New System.Drawing.Size(25, 15)
        Me.Tekityu6.TabIndex = 1035
        Me.Tekityu6.Text = "0%"
        '
        'Tekityu7
        '
        Me.Tekityu7.AutoSize = True
        Me.Tekityu7.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Tekityu7.Location = New System.Drawing.Point(176, 384)
        Me.Tekityu7.Name = "Tekityu7"
        Me.Tekityu7.Size = New System.Drawing.Size(25, 15)
        Me.Tekityu7.TabIndex = 1034
        Me.Tekityu7.Text = "0%"
        '
        'Tekityu8
        '
        Me.Tekityu8.AutoSize = True
        Me.Tekityu8.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Tekityu8.Location = New System.Drawing.Point(176, 424)
        Me.Tekityu8.Name = "Tekityu8"
        Me.Tekityu8.Size = New System.Drawing.Size(25, 15)
        Me.Tekityu8.TabIndex = 1033
        Me.Tekityu8.Text = "0%"
        '
        'Tekityu9
        '
        Me.Tekityu9.AutoSize = True
        Me.Tekityu9.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Tekityu9.Location = New System.Drawing.Point(176, 464)
        Me.Tekityu9.Name = "Tekityu9"
        Me.Tekityu9.Size = New System.Drawing.Size(25, 15)
        Me.Tekityu9.TabIndex = 1032
        Me.Tekityu9.Text = "0%"
        '
        'Tekityu10
        '
        Me.Tekityu10.AutoSize = True
        Me.Tekityu10.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Tekityu10.Location = New System.Drawing.Point(176, 504)
        Me.Tekityu10.Name = "Tekityu10"
        Me.Tekityu10.Size = New System.Drawing.Size(25, 15)
        Me.Tekityu10.TabIndex = 1031
        Me.Tekityu10.Text = "0%"
        '
        'Tekityu5
        '
        Me.Tekityu5.AutoSize = True
        Me.Tekityu5.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Tekityu5.Location = New System.Drawing.Point(176, 296)
        Me.Tekityu5.Name = "Tekityu5"
        Me.Tekityu5.Size = New System.Drawing.Size(25, 15)
        Me.Tekityu5.TabIndex = 1030
        Me.Tekityu5.Text = "0%"
        '
        'Tekityu4
        '
        Me.Tekityu4.AutoSize = True
        Me.Tekityu4.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Tekityu4.Location = New System.Drawing.Point(176, 256)
        Me.Tekityu4.Name = "Tekityu4"
        Me.Tekityu4.Size = New System.Drawing.Size(25, 15)
        Me.Tekityu4.TabIndex = 1029
        Me.Tekityu4.Text = "0%"
        '
        'Tekityu3
        '
        Me.Tekityu3.AutoSize = True
        Me.Tekityu3.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Tekityu3.Location = New System.Drawing.Point(176, 216)
        Me.Tekityu3.Name = "Tekityu3"
        Me.Tekityu3.Size = New System.Drawing.Size(25, 15)
        Me.Tekityu3.TabIndex = 1028
        Me.Tekityu3.Text = "0%"
        '
        'Tekityu2
        '
        Me.Tekityu2.AutoSize = True
        Me.Tekityu2.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Tekityu2.Location = New System.Drawing.Point(176, 176)
        Me.Tekityu2.Name = "Tekityu2"
        Me.Tekityu2.Size = New System.Drawing.Size(25, 15)
        Me.Tekityu2.TabIndex = 1027
        Me.Tekityu2.Text = "0%"
        '
        'Tekityu1
        '
        Me.Tekityu1.AutoSize = True
        Me.Tekityu1.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Tekityu1.Location = New System.Drawing.Point(176, 136)
        Me.Tekityu1.Name = "Tekityu1"
        Me.Tekityu1.Size = New System.Drawing.Size(25, 15)
        Me.Tekityu1.TabIndex = 1026
        Me.Tekityu1.Text = "0%"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label27.Location = New System.Drawing.Point(120, 112)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(39, 15)
        Me.Label27.TabIndex = 1036
        Me.Label27.Text = "合計"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label28.Location = New System.Drawing.Point(160, 112)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(55, 15)
        Me.Label28.TabIndex = 1037
        Me.Label28.Text = "的中率"
        '
        'DataHiraku
        '
        Me.DataHiraku.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.DataHiraku.Location = New System.Drawing.Point(336, 16)
        Me.DataHiraku.Name = "DataHiraku"
        Me.DataHiraku.Size = New System.Drawing.Size(56, 32)
        Me.DataHiraku.TabIndex = 1038
        Me.DataHiraku.Text = "開く"
        Me.DataHiraku.UseVisualStyleBackColor = True
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label17.Location = New System.Drawing.Point(48, 112)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(39, 15)
        Me.Label17.TabIndex = 1039
        Me.Label17.Text = "氏名"
        '
        'TClear
        '
        Me.TClear.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.TClear.Location = New System.Drawing.Point(904, 56)
        Me.TClear.Name = "TClear"
        Me.TClear.Size = New System.Drawing.Size(96, 32)
        Me.TClear.TabIndex = 1057
        Me.TClear.Text = "的中 Clear"
        Me.TClear.UseVisualStyleBackColor = True
        '
        'Form6
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1276, 546)
        Me.Controls.Add(Me.TClear)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.DataHiraku)
        Me.Controls.Add(Me.Label28)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.Tekityu6)
        Me.Controls.Add(Me.Tekityu7)
        Me.Controls.Add(Me.Tekityu8)
        Me.Controls.Add(Me.Tekityu9)
        Me.Controls.Add(Me.Tekityu10)
        Me.Controls.Add(Me.Tekityu5)
        Me.Controls.Add(Me.Tekityu4)
        Me.Controls.Add(Me.Tekityu3)
        Me.Controls.Add(Me.Tekityu2)
        Me.Controls.Add(Me.Tekityu1)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Atri_Clear)
        Me.Controls.Add(Me.TextBox10)
        Me.Controls.Add(Me.TextBox9)
        Me.Controls.Add(Me.TextBox8)
        Me.Controls.Add(Me.TextBox7)
        Me.Controls.Add(Me.TextBox6)
        Me.Controls.Add(Me.TextBox5)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.Save)
        Me.Controls.Add(Me.Syuryo)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Sort_Reverse)
        Me.Controls.Add(Me.Gokei_2)
        Me.Controls.Add(Me.Goke_3)
        Me.Controls.Add(Me.Gokei_All)
        Me.Controls.Add(Me.Back)
        Me.Controls.Add(Me.Button181)
        Me.Controls.Add(Me.Button182)
        Me.Controls.Add(Me.Button183)
        Me.Controls.Add(Me.Button184)
        Me.Controls.Add(Me.Button185)
        Me.Controls.Add(Me.Button186)
        Me.Controls.Add(Me.Button187)
        Me.Controls.Add(Me.Button188)
        Me.Controls.Add(Me.Button189)
        Me.Controls.Add(Me.Button190)
        Me.Controls.Add(Me.Button191)
        Me.Controls.Add(Me.Button192)
        Me.Controls.Add(Me.Button193)
        Me.Controls.Add(Me.Button194)
        Me.Controls.Add(Me.Button195)
        Me.Controls.Add(Me.Button196)
        Me.Controls.Add(Me.Button197)
        Me.Controls.Add(Me.Button198)
        Me.Controls.Add(Me.Button199)
        Me.Controls.Add(Me.Button200)
        Me.Controls.Add(Me.Button161)
        Me.Controls.Add(Me.Button162)
        Me.Controls.Add(Me.Button163)
        Me.Controls.Add(Me.Button164)
        Me.Controls.Add(Me.Button165)
        Me.Controls.Add(Me.Button166)
        Me.Controls.Add(Me.Button167)
        Me.Controls.Add(Me.Button168)
        Me.Controls.Add(Me.Button169)
        Me.Controls.Add(Me.Button170)
        Me.Controls.Add(Me.Button171)
        Me.Controls.Add(Me.Button172)
        Me.Controls.Add(Me.Button173)
        Me.Controls.Add(Me.Button174)
        Me.Controls.Add(Me.Button175)
        Me.Controls.Add(Me.Button176)
        Me.Controls.Add(Me.Button177)
        Me.Controls.Add(Me.Button178)
        Me.Controls.Add(Me.Button179)
        Me.Controls.Add(Me.Button180)
        Me.Controls.Add(Me.Button141)
        Me.Controls.Add(Me.Button142)
        Me.Controls.Add(Me.Button143)
        Me.Controls.Add(Me.Button144)
        Me.Controls.Add(Me.Button145)
        Me.Controls.Add(Me.Button146)
        Me.Controls.Add(Me.Button147)
        Me.Controls.Add(Me.Button148)
        Me.Controls.Add(Me.Button149)
        Me.Controls.Add(Me.Button150)
        Me.Controls.Add(Me.Button151)
        Me.Controls.Add(Me.Button152)
        Me.Controls.Add(Me.Button153)
        Me.Controls.Add(Me.Button154)
        Me.Controls.Add(Me.Button155)
        Me.Controls.Add(Me.Button156)
        Me.Controls.Add(Me.Button157)
        Me.Controls.Add(Me.Button158)
        Me.Controls.Add(Me.Button159)
        Me.Controls.Add(Me.Button160)
        Me.Controls.Add(Me.Button121)
        Me.Controls.Add(Me.Button122)
        Me.Controls.Add(Me.Button123)
        Me.Controls.Add(Me.Button124)
        Me.Controls.Add(Me.Button125)
        Me.Controls.Add(Me.Button126)
        Me.Controls.Add(Me.Button127)
        Me.Controls.Add(Me.Button128)
        Me.Controls.Add(Me.Button129)
        Me.Controls.Add(Me.Button130)
        Me.Controls.Add(Me.Button131)
        Me.Controls.Add(Me.Button132)
        Me.Controls.Add(Me.Button133)
        Me.Controls.Add(Me.Button134)
        Me.Controls.Add(Me.Button135)
        Me.Controls.Add(Me.Button136)
        Me.Controls.Add(Me.Button137)
        Me.Controls.Add(Me.Button138)
        Me.Controls.Add(Me.Button139)
        Me.Controls.Add(Me.Button140)
        Me.Controls.Add(Me.Button101)
        Me.Controls.Add(Me.Button102)
        Me.Controls.Add(Me.Button103)
        Me.Controls.Add(Me.Button104)
        Me.Controls.Add(Me.Button105)
        Me.Controls.Add(Me.Button106)
        Me.Controls.Add(Me.Button107)
        Me.Controls.Add(Me.Button108)
        Me.Controls.Add(Me.Button109)
        Me.Controls.Add(Me.Button110)
        Me.Controls.Add(Me.Button111)
        Me.Controls.Add(Me.Button112)
        Me.Controls.Add(Me.Button113)
        Me.Controls.Add(Me.Button114)
        Me.Controls.Add(Me.Button115)
        Me.Controls.Add(Me.Button116)
        Me.Controls.Add(Me.Button117)
        Me.Controls.Add(Me.Button118)
        Me.Controls.Add(Me.Button119)
        Me.Controls.Add(Me.Button120)
        Me.Controls.Add(Me.Button81)
        Me.Controls.Add(Me.Button82)
        Me.Controls.Add(Me.Button83)
        Me.Controls.Add(Me.Button84)
        Me.Controls.Add(Me.Button85)
        Me.Controls.Add(Me.Button86)
        Me.Controls.Add(Me.Button87)
        Me.Controls.Add(Me.Button88)
        Me.Controls.Add(Me.Button89)
        Me.Controls.Add(Me.Button90)
        Me.Controls.Add(Me.Button91)
        Me.Controls.Add(Me.Button92)
        Me.Controls.Add(Me.Button93)
        Me.Controls.Add(Me.Button94)
        Me.Controls.Add(Me.Button95)
        Me.Controls.Add(Me.Button96)
        Me.Controls.Add(Me.Button97)
        Me.Controls.Add(Me.Button98)
        Me.Controls.Add(Me.Button99)
        Me.Controls.Add(Me.Button100)
        Me.Controls.Add(Me.Button61)
        Me.Controls.Add(Me.Button62)
        Me.Controls.Add(Me.Button63)
        Me.Controls.Add(Me.Button64)
        Me.Controls.Add(Me.Button65)
        Me.Controls.Add(Me.Button66)
        Me.Controls.Add(Me.Button67)
        Me.Controls.Add(Me.Button68)
        Me.Controls.Add(Me.Button69)
        Me.Controls.Add(Me.Button70)
        Me.Controls.Add(Me.Button71)
        Me.Controls.Add(Me.Button72)
        Me.Controls.Add(Me.Button73)
        Me.Controls.Add(Me.Button74)
        Me.Controls.Add(Me.Button75)
        Me.Controls.Add(Me.Button76)
        Me.Controls.Add(Me.Button77)
        Me.Controls.Add(Me.Button78)
        Me.Controls.Add(Me.Button79)
        Me.Controls.Add(Me.Button80)
        Me.Controls.Add(Me.Button41)
        Me.Controls.Add(Me.Button42)
        Me.Controls.Add(Me.Button43)
        Me.Controls.Add(Me.Button44)
        Me.Controls.Add(Me.Button45)
        Me.Controls.Add(Me.Button46)
        Me.Controls.Add(Me.Button47)
        Me.Controls.Add(Me.Button48)
        Me.Controls.Add(Me.Button49)
        Me.Controls.Add(Me.Button50)
        Me.Controls.Add(Me.Button51)
        Me.Controls.Add(Me.Button52)
        Me.Controls.Add(Me.Button53)
        Me.Controls.Add(Me.Button54)
        Me.Controls.Add(Me.Button55)
        Me.Controls.Add(Me.Button56)
        Me.Controls.Add(Me.Button57)
        Me.Controls.Add(Me.Button58)
        Me.Controls.Add(Me.Button59)
        Me.Controls.Add(Me.Button60)
        Me.Controls.Add(Me.Button21)
        Me.Controls.Add(Me.Button22)
        Me.Controls.Add(Me.Button23)
        Me.Controls.Add(Me.Button24)
        Me.Controls.Add(Me.Button25)
        Me.Controls.Add(Me.Button26)
        Me.Controls.Add(Me.Button27)
        Me.Controls.Add(Me.Button28)
        Me.Controls.Add(Me.Button29)
        Me.Controls.Add(Me.Button30)
        Me.Controls.Add(Me.Button31)
        Me.Controls.Add(Me.Button32)
        Me.Controls.Add(Me.Button33)
        Me.Controls.Add(Me.Button34)
        Me.Controls.Add(Me.Button35)
        Me.Controls.Add(Me.Button36)
        Me.Controls.Add(Me.Button37)
        Me.Controls.Add(Me.Button38)
        Me.Controls.Add(Me.Button39)
        Me.Controls.Add(Me.Button40)
        Me.Controls.Add(Me.Button13)
        Me.Controls.Add(Me.Button14)
        Me.Controls.Add(Me.Button15)
        Me.Controls.Add(Me.Button16)
        Me.Controls.Add(Me.Button17)
        Me.Controls.Add(Me.Button18)
        Me.Controls.Add(Me.Button19)
        Me.Controls.Add(Me.Button20)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.Button11)
        Me.Controls.Add(Me.Button12)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button2)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form6"
        Me.Text = "弓道的中表ソフト"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Atri_Clear As Button
    Friend WithEvents TextBox10 As TextBox
    Friend WithEvents TextBox9 As TextBox
    Friend WithEvents TextBox8 As TextBox
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents Save As Button
    Friend WithEvents Syuryo As Button
    Friend WithEvents Label16 As Label
    Friend WithEvents Sort_Reverse As Button
    Friend WithEvents Gokei_2 As Button
    Friend WithEvents Goke_3 As Button
    Friend WithEvents Gokei_All As Button
    Friend WithEvents Back As Button
    Friend WithEvents Button181 As Button
    Friend WithEvents Button182 As Button
    Friend WithEvents Button183 As Button
    Friend WithEvents Button184 As Button
    Friend WithEvents Button185 As Button
    Friend WithEvents Button186 As Button
    Friend WithEvents Button187 As Button
    Friend WithEvents Button188 As Button
    Friend WithEvents Button189 As Button
    Friend WithEvents Button190 As Button
    Friend WithEvents Button191 As Button
    Friend WithEvents Button192 As Button
    Friend WithEvents Button193 As Button
    Friend WithEvents Button194 As Button
    Friend WithEvents Button195 As Button
    Friend WithEvents Button196 As Button
    Friend WithEvents Button197 As Button
    Friend WithEvents Button198 As Button
    Friend WithEvents Button199 As Button
    Friend WithEvents Button200 As Button
    Friend WithEvents Button161 As Button
    Friend WithEvents Button162 As Button
    Friend WithEvents Button163 As Button
    Friend WithEvents Button164 As Button
    Friend WithEvents Button165 As Button
    Friend WithEvents Button166 As Button
    Friend WithEvents Button167 As Button
    Friend WithEvents Button168 As Button
    Friend WithEvents Button169 As Button
    Friend WithEvents Button170 As Button
    Friend WithEvents Button171 As Button
    Friend WithEvents Button172 As Button
    Friend WithEvents Button173 As Button
    Friend WithEvents Button174 As Button
    Friend WithEvents Button175 As Button
    Friend WithEvents Button176 As Button
    Friend WithEvents Button177 As Button
    Friend WithEvents Button178 As Button
    Friend WithEvents Button179 As Button
    Friend WithEvents Button180 As Button
    Friend WithEvents Button141 As Button
    Friend WithEvents Button142 As Button
    Friend WithEvents Button143 As Button
    Friend WithEvents Button144 As Button
    Friend WithEvents Button145 As Button
    Friend WithEvents Button146 As Button
    Friend WithEvents Button147 As Button
    Friend WithEvents Button148 As Button
    Friend WithEvents Button149 As Button
    Friend WithEvents Button150 As Button
    Friend WithEvents Button151 As Button
    Friend WithEvents Button152 As Button
    Friend WithEvents Button153 As Button
    Friend WithEvents Button154 As Button
    Friend WithEvents Button155 As Button
    Friend WithEvents Button156 As Button
    Friend WithEvents Button157 As Button
    Friend WithEvents Button158 As Button
    Friend WithEvents Button159 As Button
    Friend WithEvents Button160 As Button
    Friend WithEvents Button121 As Button
    Friend WithEvents Button122 As Button
    Friend WithEvents Button123 As Button
    Friend WithEvents Button124 As Button
    Friend WithEvents Button125 As Button
    Friend WithEvents Button126 As Button
    Friend WithEvents Button127 As Button
    Friend WithEvents Button128 As Button
    Friend WithEvents Button129 As Button
    Friend WithEvents Button130 As Button
    Friend WithEvents Button131 As Button
    Friend WithEvents Button132 As Button
    Friend WithEvents Button133 As Button
    Friend WithEvents Button134 As Button
    Friend WithEvents Button135 As Button
    Friend WithEvents Button136 As Button
    Friend WithEvents Button137 As Button
    Friend WithEvents Button138 As Button
    Friend WithEvents Button139 As Button
    Friend WithEvents Button140 As Button
    Friend WithEvents Button101 As Button
    Friend WithEvents Button102 As Button
    Friend WithEvents Button103 As Button
    Friend WithEvents Button104 As Button
    Friend WithEvents Button105 As Button
    Friend WithEvents Button106 As Button
    Friend WithEvents Button107 As Button
    Friend WithEvents Button108 As Button
    Friend WithEvents Button109 As Button
    Friend WithEvents Button110 As Button
    Friend WithEvents Button111 As Button
    Friend WithEvents Button112 As Button
    Friend WithEvents Button113 As Button
    Friend WithEvents Button114 As Button
    Friend WithEvents Button115 As Button
    Friend WithEvents Button116 As Button
    Friend WithEvents Button117 As Button
    Friend WithEvents Button118 As Button
    Friend WithEvents Button119 As Button
    Friend WithEvents Button120 As Button
    Friend WithEvents Button81 As Button
    Friend WithEvents Button82 As Button
    Friend WithEvents Button83 As Button
    Friend WithEvents Button84 As Button
    Friend WithEvents Button85 As Button
    Friend WithEvents Button86 As Button
    Friend WithEvents Button87 As Button
    Friend WithEvents Button88 As Button
    Friend WithEvents Button89 As Button
    Friend WithEvents Button90 As Button
    Friend WithEvents Button91 As Button
    Friend WithEvents Button92 As Button
    Friend WithEvents Button93 As Button
    Friend WithEvents Button94 As Button
    Friend WithEvents Button95 As Button
    Friend WithEvents Button96 As Button
    Friend WithEvents Button97 As Button
    Friend WithEvents Button98 As Button
    Friend WithEvents Button99 As Button
    Friend WithEvents Button100 As Button
    Friend WithEvents Button61 As Button
    Friend WithEvents Button62 As Button
    Friend WithEvents Button63 As Button
    Friend WithEvents Button64 As Button
    Friend WithEvents Button65 As Button
    Friend WithEvents Button66 As Button
    Friend WithEvents Button67 As Button
    Friend WithEvents Button68 As Button
    Friend WithEvents Button69 As Button
    Friend WithEvents Button70 As Button
    Friend WithEvents Button71 As Button
    Friend WithEvents Button72 As Button
    Friend WithEvents Button73 As Button
    Friend WithEvents Button74 As Button
    Friend WithEvents Button75 As Button
    Friend WithEvents Button76 As Button
    Friend WithEvents Button77 As Button
    Friend WithEvents Button78 As Button
    Friend WithEvents Button79 As Button
    Friend WithEvents Button80 As Button
    Friend WithEvents Button41 As Button
    Friend WithEvents Button42 As Button
    Friend WithEvents Button43 As Button
    Friend WithEvents Button44 As Button
    Friend WithEvents Button45 As Button
    Friend WithEvents Button46 As Button
    Friend WithEvents Button47 As Button
    Friend WithEvents Button48 As Button
    Friend WithEvents Button49 As Button
    Friend WithEvents Button50 As Button
    Friend WithEvents Button51 As Button
    Friend WithEvents Button52 As Button
    Friend WithEvents Button53 As Button
    Friend WithEvents Button54 As Button
    Friend WithEvents Button55 As Button
    Friend WithEvents Button56 As Button
    Friend WithEvents Button57 As Button
    Friend WithEvents Button58 As Button
    Friend WithEvents Button59 As Button
    Friend WithEvents Button60 As Button
    Friend WithEvents Button21 As Button
    Friend WithEvents Button22 As Button
    Friend WithEvents Button23 As Button
    Friend WithEvents Button24 As Button
    Friend WithEvents Button25 As Button
    Friend WithEvents Button26 As Button
    Friend WithEvents Button27 As Button
    Friend WithEvents Button28 As Button
    Friend WithEvents Button29 As Button
    Friend WithEvents Button30 As Button
    Friend WithEvents Button31 As Button
    Friend WithEvents Button32 As Button
    Friend WithEvents Button33 As Button
    Friend WithEvents Button34 As Button
    Friend WithEvents Button35 As Button
    Friend WithEvents Button36 As Button
    Friend WithEvents Button37 As Button
    Friend WithEvents Button38 As Button
    Friend WithEvents Button39 As Button
    Friend WithEvents Button40 As Button
    Friend WithEvents Button13 As Button
    Friend WithEvents Button14 As Button
    Friend WithEvents Button15 As Button
    Friend WithEvents Button16 As Button
    Friend WithEvents Button17 As Button
    Friend WithEvents Button18 As Button
    Friend WithEvents Button19 As Button
    Friend WithEvents Button20 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents Button12 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Label14 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents Label15 As Label
    Friend WithEvents Tekityu6 As Label
    Friend WithEvents Tekityu7 As Label
    Friend WithEvents Tekityu8 As Label
    Friend WithEvents Tekityu9 As Label
    Friend WithEvents Tekityu10 As Label
    Friend WithEvents Tekityu5 As Label
    Friend WithEvents Tekityu4 As Label
    Friend WithEvents Tekityu3 As Label
    Friend WithEvents Tekityu2 As Label
    Friend WithEvents Tekityu1 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents DataHiraku As Button
    Friend WithEvents Label17 As Label
    Friend WithEvents TClear As Button
End Class
